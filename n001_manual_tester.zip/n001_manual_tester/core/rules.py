from __future__ import annotations

from core.constants import DANGEROUS_COMMANDS, MANUAL_UNKNOWN


def is_dangerous_command(command: str) -> bool:
    normalized = command.strip().lower()
    for token in DANGEROUS_COMMANDS:
        if normalized.startswith(token):
            return True
    return False


def normalize_manual_value(value: str | None) -> str:
    if value is None or not value.strip():
        return MANUAL_UNKNOWN
    return value.strip()
