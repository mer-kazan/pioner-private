class ManualDataError(ValueError):
    """Raised when the manual content is incomplete or contradictory."""


class DeviceConnectionError(RuntimeError):
    """Raised when a device cannot be reached."""


class DangerousActionRejected(RuntimeError):
    """Raised when a risky command is blocked by policy."""


class TestCaseValidationError(ValueError):
    """Raised when a test case cannot be validated."""
