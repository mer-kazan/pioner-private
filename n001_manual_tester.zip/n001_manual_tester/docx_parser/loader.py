"""Defensive DOCX/OOXML validation and ordered content extraction."""

from __future__ import annotations

import hashlib
import posixpath
import re
import zipfile
from dataclasses import dataclass
from datetime import UTC, datetime
from io import BytesIO
from pathlib import Path
from urllib.parse import unquote, urlsplit
from uuid import UUID

import lxml.etree as etree
from docx import Document
from docx.oxml.ns import nsmap, qn
from docx.text.paragraph import Paragraph

from docx_parser.models import (
    CellParagraph,
    CellUnsupported,
    IgnoredExternalRelationship,
    ImportedManual,
    ParagraphBlock,
    SourceRef,
    SourceRevision,
    TableBlock,
    TableCell,
    UnsupportedBlock,
    UnsupportedFragment,
)

_WORD_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
_CONTENT_TYPES_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
_DOCX_MAIN_CONTENT_TYPE = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"
)
_MAX_COMPRESSED_BYTES = 32 * 1024 * 1024
_MAX_UNCOMPRESSED_BYTES = 128 * 1024 * 1024
_MAX_ARCHIVE_ENTRIES = 2048
_MAX_MEMBER_BYTES = 32 * 1024 * 1024
_MAX_COMPRESSION_RATIO = 100
_REQUIRED_PARTS = {"[Content_Types].xml", "_rels/.rels", "word/document.xml"}
_MACRO_CONTENT_TYPE = re.compile(r"macroenabled|vbaProject", re.IGNORECASE)
_UNSUPPORTED_PARAGRAPH_TAGS = {
    qn(tag)
    for tag in (
        "w:drawing",
        "w:object",
        "w:pict",
        "w:altChunk",
        "w:subDoc",
        "w:contentPart",
        "w:fldSimple",
        "w:ins",
        "w:del",
        "w:moveFrom",
        "w:moveTo",
        "w:sdt",
        "w:customXml",
    )
}


class DocxImportError(ValueError):
    """Raised when a selected file is not a supported, safe DOCX input."""


@dataclass(frozen=True)
class ImportLimits:
    """Resource limits enforced before any document content is parsed."""

    max_compressed_bytes: int = _MAX_COMPRESSED_BYTES
    max_uncompressed_bytes: int = _MAX_UNCOMPRESSED_BYTES
    max_entries: int = _MAX_ARCHIVE_ENTRIES
    max_member_bytes: int = _MAX_MEMBER_BYTES
    max_compression_ratio: int = _MAX_COMPRESSION_RATIO


class ManualLoader:
    """Load one selected ``.docx`` file into immutable source-grounded models."""

    def __init__(self, file_path: str | Path, limits: ImportLimits | None = None) -> None:
        self.file_path = Path(file_path)
        self.limits = limits or ImportLimits()

    def load(self) -> ImportedManual:
        """Validate and import the selected DOCX without extracting it to disk."""
        if not self.file_path.exists():
            raise FileNotFoundError(f"Файл не найден: {self.file_path}")
        if not self.file_path.is_file():
            raise DocxImportError("DOCX source must be a regular file")
        if self.file_path.suffix.lower() != ".docx":
            raise DocxImportError("Only files with the .docx extension are supported")

        try:
            size = self.file_path.stat().st_size
            if size > self.limits.max_compressed_bytes:
                raise DocxImportError("Compressed DOCX file exceeds the size limit")
            source_bytes = self.file_path.read_bytes()
        except OSError:
            raise

        if len(source_bytes) > self.limits.max_compressed_bytes:
            raise DocxImportError("Compressed DOCX file exceeds the size limit")
        external_relationships = _validate_package(source_bytes, self.limits)
        try:
            document = Document(BytesIO(source_bytes))
        except Exception as exc:
            raise DocxImportError("DOCX document content could not be parsed") from exc

        revision = SourceRevision(
            sha256=hashlib.sha256(source_bytes).hexdigest(),
            imported_at=datetime.now(UTC),
        )
        blocks = _extract_blocks(document)
        return ImportedManual(
            revision=revision,
            blocks=tuple(blocks),
            ignored_external_relationships=tuple(external_relationships),
        )


def _validate_package(
    source_bytes: bytes,
    limits: ImportLimits,
) -> list[IgnoredExternalRelationship]:
    if not zipfile.is_zipfile(BytesIO(source_bytes)):
        raise DocxImportError("Selected file is not a valid ZIP-based DOCX package")

    try:
        with zipfile.ZipFile(BytesIO(source_bytes)) as archive:
            entries = archive.infolist()
            names = [entry.filename for entry in entries]
            _validate_entries(entries, limits)
            name_set = set(names)
            missing = _REQUIRED_PARTS - name_set
            if missing:
                raise DocxImportError(
                    f"DOCX package is missing required OOXML parts: {', '.join(sorted(missing))}"
                )

            if any(
                "vbaproject" in name.lower() or _MACRO_CONTENT_TYPE.search(name) for name in names
            ):
                raise DocxImportError("Macro-enabled DOCX packages are not supported")

            xml_parts: dict[str, bytes] = {}
            actual_total = 0
            for entry in entries:
                actual_size = 0
                is_xml_part = entry.filename.lower().endswith((".xml", ".rels"))
                xml_chunks: list[bytes] = []
                with archive.open(entry) as member:
                    while chunk := member.read(64 * 1024):
                        actual_size += len(chunk)
                        actual_total += len(chunk)
                        if actual_size > entry.file_size:
                            raise DocxImportError(
                                "DOCX ZIP entry expands beyond its declared uncompressed size"
                            )
                        if actual_total > limits.max_uncompressed_bytes:
                            raise DocxImportError(
                                "DOCX package exceeds the total uncompressed-size limit"
                            )
                        if is_xml_part:
                            xml_chunks.append(chunk)
                if actual_size != entry.file_size:
                    raise DocxImportError(
                        "DOCX ZIP entry does not match its declared uncompressed size"
                    )
                if is_xml_part:
                    contents = b"".join(xml_chunks)
                    if b"<!doctype" in contents.lower() or b"<!entity" in contents.lower():
                        raise DocxImportError("DOCX XML declarations are not permitted")
                    _parse_xml(contents, entry.filename)
                    xml_parts[entry.filename] = contents
    except DocxImportError:
        raise
    except (OSError, RuntimeError, zipfile.BadZipFile, zipfile.LargeZipFile, ValueError) as exc:
        raise DocxImportError("DOCX ZIP package is damaged or unsupported") from exc

    content_types = _parse_xml(xml_parts["[Content_Types].xml"], "[Content_Types].xml")
    main_type = content_types.find(
        f"{{{_CONTENT_TYPES_NS}}}Override[@PartName='/word/document.xml']"
    )
    if any(
        _MACRO_CONTENT_TYPE.search(attribute_value)
        for element in content_types
        for attribute_value in element.attrib.values()
    ):
        raise DocxImportError("Macro-enabled DOCX packages are not supported")
    if main_type is None or main_type.get("ContentType") != _DOCX_MAIN_CONTENT_TYPE:
        raise DocxImportError("Package does not declare a standard DOCX main document")

    root_relationships = _parse_xml(xml_parts["_rels/.rels"], "_rels/.rels")
    document_relationship = next(
        (
            relationship
            for relationship in root_relationships.findall(f"{{{_REL_NS}}}Relationship")
            if relationship.get("Type", "").endswith("/officeDocument")
        ),
        None,
    )
    if document_relationship is None or document_relationship.get("TargetMode") == "External":
        raise DocxImportError("DOCX package has no internal main-document relationship")
    if _resolve_internal_target("", document_relationship.get("Target", "")) != "word/document.xml":
        raise DocxImportError("DOCX main-document relationship points to an unexpected part")

    external_relationships: list[IgnoredExternalRelationship] = []
    for rels_name, contents in xml_parts.items():
        if not rels_name.endswith(".rels"):
            continue
        source_part_uri = _relationship_source_part(rels_name)
        root = _parse_xml(contents, rels_name)
        for relationship in root.findall(f"{{{_REL_NS}}}Relationship"):
            target = relationship.get("Target", "")
            if relationship.get("TargetMode") == "External":
                external_relationships.append(
                    IgnoredExternalRelationship(
                        source_part_uri=source_part_uri,
                        relationship_id=relationship.get("Id", ""),
                        relationship_type=relationship.get("Type", ""),
                    )
                )
                continue
            resolved = _resolve_internal_target(source_part_uri, target)
            if resolved not in name_set:
                raise DocxImportError(
                    f"Internal relationship in {rels_name} targets a missing package part"
                )
    return external_relationships


def _validate_entries(entries: list[zipfile.ZipInfo], limits: ImportLimits) -> None:
    if len(entries) > limits.max_entries:
        raise DocxImportError("DOCX package contains too many ZIP entries")

    names: set[str] = set()
    total_uncompressed = 0
    total_compressed = 0
    for entry in entries:
        name = entry.filename
        if (
            not name
            or "\x00" in name
            or "\\" in name
            or name.startswith("/")
            or any(part in {"", ".", ".."} for part in name.rstrip("/").split("/"))
            or any(not part for part in name.split("/")[:-1])
            or any(":" in part for part in name.split("/"))
        ):
            raise DocxImportError("DOCX package contains an unsafe ZIP entry path")
        if name in names:
            raise DocxImportError(f"DOCX package contains a duplicate ZIP entry: {name}")
        names.add(name)

        if entry.flag_bits & 0x1:
            raise DocxImportError("Encrypted DOCX ZIP entries are not supported")
        if entry.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}:
            raise DocxImportError("DOCX package uses an unsupported ZIP compression method")
        if entry.file_size > limits.max_member_bytes:
            raise DocxImportError("DOCX package contains an oversized ZIP entry")

        unix_mode = entry.external_attr >> 16
        if unix_mode and (unix_mode & 0o170000) == 0o120000:
            raise DocxImportError("DOCX package contains a symbolic-link ZIP entry")

        if entry.file_size > 0 and entry.compress_size == 0:
            raise DocxImportError("DOCX package contains an invalid compression ratio")
        if (
            entry.compress_size
            and entry.file_size / entry.compress_size > limits.max_compression_ratio
        ):
            raise DocxImportError("DOCX package exceeds the compression-ratio limit")
        total_uncompressed += entry.file_size
        total_compressed += entry.compress_size

    if total_uncompressed > limits.max_uncompressed_bytes:
        raise DocxImportError("DOCX package exceeds the total uncompressed-size limit")
    if total_compressed and total_uncompressed / total_compressed > limits.max_compression_ratio:
        raise DocxImportError("DOCX package exceeds the total compression-ratio limit")


def _parse_xml(contents: bytes, part_name: str) -> etree._Element:
    parser = etree.XMLParser(
        resolve_entities=False,
        no_network=True,
        load_dtd=False,
        huge_tree=False,
        recover=False,
    )
    try:
        root = etree.fromstring(contents, parser=parser)
    except etree.XMLSyntaxError as exc:
        raise DocxImportError(f"Malformed OOXML part: {part_name}") from exc
    if root.getroottree().docinfo.doctype:
        raise DocxImportError("DOCX XML document types are not permitted")
    return root


def _resolve_internal_target(source_part_uri: str, target: str) -> str:
    split_target = urlsplit(target)
    if split_target.scheme or split_target.netloc or split_target.query:
        raise DocxImportError("Internal OOXML relationship has a non-package target")
    decoded_target = unquote(split_target.path)
    if "\\" in decoded_target or "\x00" in decoded_target:
        raise DocxImportError("Internal OOXML relationship has an unsafe target")
    if decoded_target.startswith("/"):
        resolved = posixpath.normpath(decoded_target.lstrip("/"))
    else:
        resolved = posixpath.normpath(
            posixpath.join(posixpath.dirname(source_part_uri), decoded_target)
        )
    if resolved in {"", ".", ".."} or resolved.startswith("../"):
        raise DocxImportError("Internal OOXML relationship escapes the package")
    return resolved


def _relationship_source_part(rels_name: str) -> str:
    if rels_name == "_rels/.rels":
        return ""
    directory, filename = rels_name.rsplit("/_rels/", maxsplit=1)
    if not filename.endswith(".rels"):
        raise DocxImportError("Malformed OOXML relationship part path")
    return posixpath.join(directory, filename[:-5])


def _extract_blocks(document: object) -> list[ParagraphBlock | TableBlock | UnsupportedBlock]:
    body = document.element.body  # type: ignore[attr-defined]
    content_iterator = iter(document.iter_inner_content())  # type: ignore[attr-defined]
    heading_stack: list[ParagraphBlock] = []
    blocks: list[ParagraphBlock | TableBlock | UnsupportedBlock] = []
    paragraph_index = 0
    table_index = 0

    for block_index, element in enumerate(body):
        if element.tag == qn("w:p"):
            paragraph = next(content_iterator)
            if not isinstance(paragraph, Paragraph):
                raise DocxImportError("Unexpected paragraph order in DOCX body")
            style_name = paragraph.style.name if paragraph.style is not None else None
            heading_level = _heading_level(
                style_name, paragraph.style.style_id if paragraph.style else ""
            )
            if heading_level is not None:
                while (
                    heading_stack
                    and heading_stack[-1].heading_level is not None
                    and heading_stack[-1].heading_level >= heading_level
                ):
                    heading_stack.pop()
            parent_id = heading_stack[-1].id if heading_stack else None
            source = _source_ref(
                element,
                block_index=block_index,
                paragraph_index=paragraph_index,
                quoted_text=_element_text(element),
            )
            item = ParagraphBlock(
                source=source,
                parent_heading_id=parent_id,
                text=_element_text(element),
                style_name=style_name,
                heading_level=heading_level,
                unsupported=tuple(_paragraph_unsupported(element, source)),
            )
            blocks.append(item)
            if heading_level is not None:
                heading_stack.append(item)
            paragraph_index += 1
        elif element.tag == qn("w:tbl"):
            next(content_iterator)
            source = _source_ref(
                element,
                block_index=block_index,
                table_index=table_index,
                quoted_text=_element_text(element),
            )
            blocks.append(
                _extract_table(
                    element,
                    source,
                    heading_stack[-1].id if heading_stack else None,
                )
            )
            table_index += 1
        else:
            parent_id = heading_stack[-1].id if heading_stack else None
            blocks.append(
                UnsupportedBlock(
                    source=_source_ref(element, block_index=block_index),
                    parent_heading_id=parent_id,
                    tag=_qualified_tag(element),
                    text=_element_text(element),
                    raw_xml=etree.tostring(element, encoding="unicode"),
                )
            )

    return blocks


def _extract_table(
    element: etree._Element,
    source: SourceRef,
    parent_heading_id: UUID | None,
) -> TableBlock:
    rows: list[tuple[TableCell, ...]] = []
    for row_index, row in enumerate(element.findall("w:tr", namespaces=nsmap)):
        cells: list[TableCell] = []
        for cell_index, cell in enumerate(row.findall("w:tc", namespaces=nsmap)):
            content: list[CellParagraph | CellUnsupported] = []
            paragraph_index = 0
            for child in cell:
                if child.tag == qn("w:tcPr"):
                    continue
                if child.tag == qn("w:p"):
                    cell_source = _source_ref(
                        child,
                        block_index=source.block_index,
                        table_index=source.table_index,
                        row_index=row_index,
                        cell_index=cell_index,
                        paragraph_index=paragraph_index,
                        quoted_text=_element_text(child),
                    )
                    style_id = child.find("w:pPr/w:pStyle", namespaces=nsmap)
                    style_name = style_id.get(qn("w:val")) if style_id is not None else None
                    content.append(
                        CellParagraph(
                            source=cell_source,
                            text=_element_text(child),
                            style_id=style_name,
                            unsupported=tuple(_paragraph_unsupported(child, cell_source)),
                        )
                    )
                    paragraph_index += 1
                else:
                    content.append(
                        CellUnsupported(
                            source=_source_ref(
                                child,
                                block_index=source.block_index,
                                table_index=source.table_index,
                                row_index=row_index,
                                cell_index=cell_index,
                            ),
                            tag=_qualified_tag(child),
                            text=_element_text(child),
                            raw_xml=etree.tostring(child, encoding="unicode"),
                        )
                    )
            cells.append(TableCell(content=tuple(content)))
        rows.append(tuple(cells))
    return TableBlock(
        source=source,
        parent_heading_id=parent_heading_id,
        rows=tuple(rows),
    )


def _heading_level(style_name: str | None, style_id: str) -> int | None:
    for candidate in (style_name or "", style_id):
        match = re.fullmatch(r"Heading\s*([1-9])", candidate, re.IGNORECASE)
        if match:
            return int(match.group(1))
    return None


def _paragraph_unsupported(
    paragraph: etree._Element,
    source: SourceRef,
) -> list[UnsupportedFragment]:
    fragments: list[UnsupportedFragment] = []
    for element in paragraph.iter():
        if element is paragraph or (
            isinstance(element.tag, str) and element.tag not in _UNSUPPORTED_PARAGRAPH_TAGS
        ):
            continue
        fragments.append(
            UnsupportedFragment(
                source=_source_ref(
                    element,
                    block_index=source.block_index,
                    paragraph_index=source.paragraph_index,
                    table_index=source.table_index,
                    row_index=source.row_index,
                    cell_index=source.cell_index,
                ),
                tag=_qualified_tag(element),
                text=_element_text(element),
                raw_xml=etree.tostring(element, encoding="unicode"),
            )
        )
    return fragments


def _source_ref(
    element: etree._Element,
    *,
    block_index: int | None = None,
    paragraph_index: int | None = None,
    table_index: int | None = None,
    row_index: int | None = None,
    cell_index: int | None = None,
    quoted_text: str | None = None,
) -> SourceRef:
    return SourceRef(
        part_uri="word/document.xml",
        xpath=_element_xpath(element),
        block_index=block_index,
        paragraph_index=paragraph_index,
        table_index=table_index,
        row_index=row_index,
        cell_index=cell_index,
        quoted_text=quoted_text,
        quoted_text_sha256=hashlib.sha256(quoted_text.encode("utf-8")).hexdigest()
        if quoted_text is not None
        else None,
    )


def _element_xpath(element: etree._Element) -> str:
    ancestry = [*element.iterancestors()][::-1] + [element]
    steps: list[str] = []
    for node in ancestry:
        if not isinstance(node.tag, str):
            index = 1
            sibling = node.getprevious()
            while sibling is not None:
                if not isinstance(sibling.tag, str):
                    index += 1
                sibling = sibling.getprevious()
            steps.append(f"comment()[{index}]")
            continue
        namespace, local_name = _split_tag(node.tag)
        if namespace == _WORD_NS:
            test = f"w:{local_name}"
        elif namespace:
            test = f"*[local-name()='{local_name}' and namespace-uri()='{namespace}']"
        else:
            test = local_name
        index = 1
        sibling = node.getprevious()
        while sibling is not None:
            if sibling.tag == node.tag:
                index += 1
            sibling = sibling.getprevious()
        steps.append(f"{test}[{index}]")
    return "/" + "/".join(steps)


def _element_text(element: etree._Element) -> str:
    pieces: list[str] = []
    for node in element.iter():
        if not isinstance(node.tag, str):
            continue
        if node.tag in {qn("w:t"), qn("w:delText"), qn("w:instrText")}:
            pieces.append(node.text or "")
        elif node.tag == qn("w:tab"):
            pieces.append("\t")
        elif node.tag in {qn("w:br"), qn("w:cr")}:
            pieces.append("\n")
    return "".join(pieces)


def _qualified_tag(element: etree._Element) -> str:
    if not isinstance(element.tag, str):
        return "xml:comment"
    namespace, local_name = _split_tag(element.tag)
    if namespace == _WORD_NS:
        return f"w:{local_name}"
    if namespace:
        return f"{{{namespace}}}{local_name}"
    return local_name


def _split_tag(tag: str) -> tuple[str, str]:
    if tag.startswith("{"):
        namespace, local_name = tag[1:].split("}", maxsplit=1)
        return namespace, local_name
    return "", tag
