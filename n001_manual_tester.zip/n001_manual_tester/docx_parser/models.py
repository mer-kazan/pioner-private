"""Immutable, source-grounded models produced by the DOCX importer."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import Annotated, Literal
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class _ImmutableModel(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")


class SourceRevision(_ImmutableModel):
    """Identity and integrity metadata for one imported DOCX byte sequence."""

    id: UUID = Field(default_factory=uuid4)
    format: Literal["docx"] = "docx"
    sha256: str
    imported_at: datetime

    @field_validator("id")
    @classmethod
    def require_uuid4(cls, value: UUID) -> UUID:
        if value.version != 4:
            raise ValueError("Source revision IDs must be UUIDv4")
        return value

    @field_validator("sha256")
    @classmethod
    def require_sha256(cls, value: str) -> str:
        if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
            raise ValueError("sha256 must be a lowercase hexadecimal SHA-256 digest")
        return value

    @field_validator("imported_at")
    @classmethod
    def require_utc_timestamp(cls, value: datetime) -> datetime:
        if value.tzinfo is None or value.utcoffset() != UTC.utcoffset(value):
            raise ValueError("imported_at must be timezone-aware UTC")
        return value


class SourceRef(_ImmutableModel):
    """An OOXML part and XPath, with optional typed document coordinates."""

    part_uri: str
    xpath: str
    block_index: int | None = Field(default=None, ge=0)
    paragraph_index: int | None = Field(default=None, ge=0)
    table_index: int | None = Field(default=None, ge=0)
    row_index: int | None = Field(default=None, ge=0)
    cell_index: int | None = Field(default=None, ge=0)
    quoted_text: str | None = None
    quoted_text_sha256: str | None = None

    @model_validator(mode="after")
    def validate_quote_digest(self) -> SourceRef:
        if (self.quoted_text is None) != (self.quoted_text_sha256 is None):
            raise ValueError("quoted_text and quoted_text_sha256 must be provided together")
        if (
            self.quoted_text is not None
            and self.quoted_text_sha256
            != hashlib.sha256(self.quoted_text.encode("utf-8")).hexdigest()
        ):
            raise ValueError("quoted_text_sha256 does not match quoted_text")
        return self


class UnsupportedFragment(_ImmutableModel):
    """An OOXML construct retained without assigning it semantic meaning."""

    source: SourceRef
    tag: str
    text: str
    raw_xml: str


class _ContentBlock(_ImmutableModel):
    id: UUID = Field(default_factory=uuid4)
    source: SourceRef
    parent_heading_id: UUID | None = None


class ParagraphBlock(_ContentBlock):
    kind: Literal["paragraph"] = "paragraph"
    text: str
    style_name: str | None = None
    heading_level: int | None = Field(default=None, ge=1, le=9)
    unsupported: tuple[UnsupportedFragment, ...] = ()


class CellParagraph(_ImmutableModel):
    kind: Literal["paragraph"] = "paragraph"
    source: SourceRef
    text: str
    style_id: str | None = None
    unsupported: tuple[UnsupportedFragment, ...] = ()


class CellUnsupported(_ImmutableModel):
    kind: Literal["unsupported"] = "unsupported"
    source: SourceRef
    tag: str
    text: str
    raw_xml: str


CellContent = Annotated[
    CellParagraph | CellUnsupported,
    Field(discriminator="kind"),
]


class TableCell(_ImmutableModel):
    content: tuple[CellContent, ...]


class TableBlock(_ContentBlock):
    kind: Literal["table"] = "table"
    rows: tuple[tuple[TableCell, ...], ...]


class UnsupportedBlock(_ContentBlock):
    kind: Literal["unsupported"] = "unsupported"
    tag: str
    text: str
    raw_xml: str


DocumentBlock = Annotated[
    ParagraphBlock | TableBlock | UnsupportedBlock,
    Field(discriminator="kind"),
]


class IgnoredExternalRelationship(_ImmutableModel):
    """External relationship metadata; the relationship target is never followed."""

    source_part_uri: str
    relationship_id: str
    relationship_type: str


class ImportedManual(_ImmutableModel):
    """Ordered extracted content and its immutable original-source identity."""

    revision: SourceRevision
    blocks: tuple[DocumentBlock, ...]
    ignored_external_relationships: tuple[IgnoredExternalRelationship, ...] = ()
