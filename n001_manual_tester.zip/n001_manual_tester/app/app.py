from __future__ import annotations

from typing import cast

from PySide6.QtWidgets import QApplication

from app.i18n import LanguageManager
from app.ui.main_window import MainWindow


class App:
    def __init__(self) -> None:
        self.app = cast(QApplication | None, QApplication.instance()) or QApplication([])
        self.app.setOrganizationName("ManualTestPlatform")
        self.app.setApplicationName("ManualTestPlatform")
        self.language_manager = LanguageManager(self.app)
        self.window = MainWindow(self.language_manager)

    def run(self) -> None:
        storage = self.window.select_workspace()
        if storage is None:
            return
        self.window.set_workspace(storage)
        self.window.show()
        self.app.exec()


def create_app() -> App:
    return App()
