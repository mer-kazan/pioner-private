"""UI package for desktop interaction."""
