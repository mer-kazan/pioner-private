from __future__ import annotations

from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QTreeWidget, QTreeWidgetItem, QWidget


class NavigationPanel(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)

        self.tree = QTreeWidget(self)
        self.tree.setHeaderHidden(True)
        self.tree.setAlternatingRowColors(True)

        self._sections: list[tuple[str, list[str], QTreeWidgetItem, list[QTreeWidgetItem]]] = []
        self._add_section("Project", ["Dashboard", "Manual", "Test cases", "Reports"])
        self._add_section("Devices", ["N001", "Connections", "Security"])
        self._add_section("Execution", ["Run", "Logs", "Results"])

        self.tree.expandAll()

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.LanguageChange:
            self.retranslate_ui()

    def retranslate_ui(self) -> None:
        for section_key, item_keys, root, children in self._sections:
            root.setText(0, self.tr(section_key))
            for item_key, child in zip(item_keys, children, strict=True):
                child.setText(0, self.tr(item_key))

    def _add_section(self, title: str, items: list[str]) -> None:
        root = QTreeWidgetItem()
        children = [QTreeWidgetItem() for _ in items]
        for child in children:
            root.addChild(child)
        self._sections.append((title, items, root, children))
        self.tree.addTopLevelItem(root)
        self.retranslate_ui()
