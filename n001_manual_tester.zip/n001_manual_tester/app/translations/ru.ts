<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
  <context>
    <name>MainWindow</name>
    <message>
      <source>Manual Test Platform</source>
      <translation>Платформа ручного тестирования</translation>
    </message>
    <message>
      <source>Language</source>
      <translation>Язык</translation>
    </message>
    <message>
      <source>Project scaffold is ready.</source>
      <translation>Каркас проекта создан.</translation>
    </message>
    <message>
      <source>Next: profiles, document adapters, and manual testing workflow.</source>
      <translation>Следующий этап: профили, адаптеры документов и ручной тестовый процесс.</translation>
    </message>
    <message>
      <source>Ready</source>
      <translation>Готово</translation>
    </message>
    <message>
      <source>Language preference was not saved</source>
      <translation>Не удалось сохранить выбор языка</translation>
    </message>
    <message>
      <source>Workspace</source>
      <translation>Рабочая область</translation>
    </message>
    <message>
      <source>Open or create workspace...</source>
      <translation>Открыть или создать рабочую область...</translation>
    </message>
    <message>
      <source>Manual</source>
      <translation>Руководство</translation>
    </message>
    <message>
      <source>Import DOCX...</source>
      <translation>Импортировать DOCX...</translation>
    </message>
    <message>
      <source>Recheck latest import...</source>
      <translation>Повторно проверить последний импорт...</translation>
    </message>
    <message>
      <source>Workspace ready</source>
      <translation>Рабочая область готова</translation>
    </message>
    <message>
      <source>Select workspace</source>
      <translation>Выбор рабочей области</translation>
    </message>
    <message>
      <source>Open an existing workspace or create a new one.</source>
      <translation>Откройте существующую рабочую область или создайте новую.</translation>
    </message>
    <message>
      <source>Open workspace</source>
      <translation>Открыть рабочую область</translation>
    </message>
    <message>
      <source>Create workspace</source>
      <translation>Создать рабочую область</translation>
    </message>
    <message>
      <source>Choose where to create the workspace</source>
      <translation>Выберите место для рабочей области</translation>
    </message>
    <message>
      <source>Workspace folder name:</source>
      <translation>Имя папки рабочей области:</translation>
    </message>
    <message>
      <source>Not a workspace</source>
      <translation>Это не рабочая область</translation>
    </message>
    <message>
      <source>The selected folder does not contain a workspace database.</source>
      <translation>В выбранной папке нет базы данных рабочей области.</translation>
    </message>
    <message>
      <source>Invalid workspace name</source>
      <translation>Недопустимое имя рабочей области</translation>
    </message>
    <message>
      <source>Enter a single folder name without path separators.</source>
      <translation>Введите имя одной папки без разделителей пути.</translation>
    </message>
    <message>
      <source>Workspace already exists</source>
      <translation>Рабочая область уже существует</translation>
    </message>
    <message>
      <source>Choose a name that does not already exist in this folder.</source>
      <translation>Выберите имя, которого ещё нет в этой папке.</translation>
    </message>
    <message>
      <source>Could not create workspace</source>
      <translation>Не удалось создать рабочую область</translation>
    </message>
    <message>
      <source>Could not open workspace</source>
      <translation>Не удалось открыть рабочую область</translation>
    </message>
    <message>
      <source>Previous import unavailable</source>
      <translation>Предыдущий импорт недоступен</translation>
    </message>
    <message>
      <source>Import DOCX manual</source>
      <translation>Импорт руководства DOCX</translation>
    </message>
    <message>
      <source>Word documents (*.docx)</source>
      <translation>Документы Word (*.docx)</translation>
    </message>
    <message>
      <source>DOCX import failed</source>
      <translation>Не удалось импортировать DOCX</translation>
    </message>
    <message>
      <source>DOCX import completed</source>
      <translation>Импорт DOCX завершён</translation>
    </message>
    <message>
      <source>Select or create a workspace to begin.</source>
      <translation>Выберите или создайте рабочую область, чтобы начать.</translation>
    </message>
    <message>
      <source>Workspace: {path}</source>
      <translation>Рабочая область: {path}</translation>
    </message>
    <message>
      <source>Imported document: {name}</source>
      <translation>Импортированный документ: {name}</translation>
    </message>
    <message>
      <source>Source SHA-256: {sha256}</source>
      <translation>SHA-256 источника: {sha256}</translation>
    </message>
    <message>
      <source>Manual items: {count}</source>
      <translation>Пунктов руководства: {count}</translation>
    </message>
    <message>
      <source>Untitled item</source>
      <translation>Пункт без названия</translation>
    </message>
  </context>
  <context>
    <name>NavigationPanel</name>
    <message>
      <source>Project</source>
      <translation>Проект</translation>
    </message>
    <message>
      <source>Dashboard</source>
      <translation>Обзор</translation>
    </message>
    <message>
      <source>Manual</source>
      <translation>Руководство</translation>
    </message>
    <message>
      <source>Test cases</source>
      <translation>Тест-кейсы</translation>
    </message>
    <message>
      <source>Reports</source>
      <translation>Отчёты</translation>
    </message>
    <message>
      <source>Devices</source>
      <translation>Устройства</translation>
    </message>
    <message>
      <source>N001</source>
      <translation>N001</translation>
    </message>
    <message>
      <source>Connections</source>
      <translation>Подключения</translation>
    </message>
    <message>
      <source>Security</source>
      <translation>Безопасность</translation>
    </message>
    <message>
      <source>Execution</source>
      <translation>Выполнение</translation>
    </message>
    <message>
      <source>Run</source>
      <translation>Запуск</translation>
    </message>
    <message>
      <source>Logs</source>
      <translation>Журналы</translation>
    </message>
    <message>
      <source>Results</source>
      <translation>Результаты</translation>
    </message>
  </context>
</TS>
