from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MANUAL_TEST_", env_file=".env", extra="ignore")

    app_name: str = "Manual Test Platform"
    app_version: str = "0.1.0"
    default_manual_path: str = ""
    data_dir: str = "data"
    logs_dir: str = "logs"
    local_llm_enabled: bool = False
    local_llm_url: str = "http://127.0.0.1:11434"

    max_log_lines: int = 5000
    default_timeout_seconds: int = 30


SETTINGS = AppSettings()
