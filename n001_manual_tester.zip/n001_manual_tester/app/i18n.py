from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import QLocale, QSettings, QTranslator
from PySide6.QtWidgets import QApplication

SUPPORTED_LANGUAGES = {
    "en": "English",
    "ru": "Русский",
}
DEFAULT_LANGUAGE = "ru"


def language_from_system_locale(locale_name: str) -> str:
    language = locale_name.replace("-", "_").split("_", maxsplit=1)[0].lower()
    return language if language in SUPPORTED_LANGUAGES else DEFAULT_LANGUAGE


class LanguageManager:
    def __init__(self, application: QApplication) -> None:
        self._application = application
        self._settings = QSettings()
        self._translator: QTranslator | None = None

        configured_language = self._settings.value("ui_language")
        if isinstance(configured_language, str) and configured_language in SUPPORTED_LANGUAGES:
            language = configured_language
        else:
            if configured_language is not None:
                logging.getLogger(__name__).warning(
                    "Unsupported saved UI language %r; selecting from the system locale",
                    configured_language,
                )
            language = language_from_system_locale(QLocale.system().name())

        self._language = language
        self._install_language(language)
        self._save_language(language)

    @property
    def language(self) -> str:
        return self._language

    def set_language(self, language: str) -> None:
        if language not in SUPPORTED_LANGUAGES:
            raise ValueError(f"Unsupported UI language: {language}")
        if language == self._language:
            return

        self._install_language(language)
        self._save_language(language)

    def _install_language(self, language: str) -> None:
        translator: QTranslator | None = None
        if language != "en":
            catalog = Path(__file__).with_name("translations") / f"{language}.qm"
            candidate = QTranslator(self._application)
            if not candidate.load(str(catalog)):
                raise FileNotFoundError(f"Cannot load translation catalog: {catalog}")
            translator = candidate

        previous_translator = self._translator
        previous_language = self._language
        self._language = language
        if translator is not None:
            if not self._application.installTranslator(translator):
                self._language = previous_language
                raise RuntimeError(f"Could not install translation catalog for {language}")
        if previous_translator is not None:
            self._application.removeTranslator(previous_translator)
            previous_translator.deleteLater()
        self._translator = translator

    def _save_language(self, language: str) -> None:
        self._settings.setValue("ui_language", language)
        self._settings.sync()
        if self._settings.status() != QSettings.Status.NoError:
            raise OSError("Could not persist the UI language preference")
