from __future__ import annotations

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from manual_test_platform.app.i18n import LanguageManager, language_from_system_locale
from manual_test_platform.app.ui.main_window import MainWindow


@pytest.fixture
def application(tmp_path, monkeypatch: pytest.MonkeyPatch) -> QApplication:
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat, QSettings.Scope.UserScope, str(tmp_path))
    app = QApplication.instance()
    if not isinstance(app, QApplication):
        app = QApplication([])
    app.setOrganizationName("ManualTestPlatformTests")
    app.setApplicationName("ManualTestPlatformTests")
    QSettings().clear()
    return app


@pytest.mark.parametrize(
    ("locale_name", "expected"),
    [
        ("ru_RU", "ru"),
        ("ru-RU", "ru"),
        ("en_US", "en"),
        ("en-GB", "en"),
        ("de_DE", "ru"),
    ],
)
def test_language_from_system_locale(locale_name: str, expected: str) -> None:
    assert language_from_system_locale(locale_name) == expected


def test_language_switch_retranslates_ui_and_persists_preference(
    application: QApplication,
) -> None:
    settings = QSettings()
    settings.setValue("ui_language", "en")
    settings.sync()

    manager = LanguageManager(application)
    window = MainWindow(manager)
    window.show()
    application.processEvents()
    root_item = window.navigation.tree.topLevelItem(0)
    assert root_item is not None
    selected_item = root_item.child(1)
    assert selected_item is not None
    window.navigation.tree.setCurrentItem(selected_item)

    assert window.windowTitle() == "Manual Test Platform"
    assert root_item.text(0) == "Project"

    manager.set_language("ru")
    application.processEvents()

    assert window.windowTitle() == "Платформа ручного тестирования"
    assert root_item.text(0) == "Проект"
    assert window.navigation.tree.currentItem() is selected_item
    assert settings.value("ui_language") == "ru"

    manager.set_language("en")
    application.processEvents()

    assert window.windowTitle() == "Manual Test Platform"
    assert root_item.text(0) == "Project"
    assert settings.value("ui_language") == "en"
    window.close()


def test_unsupported_language_is_rejected(application: QApplication) -> None:
    settings = QSettings()
    settings.setValue("ui_language", "en")
    settings.sync()

    manager = LanguageManager(application)

    with pytest.raises(ValueError, match="Unsupported UI language"):
        manager.set_language("fr")
