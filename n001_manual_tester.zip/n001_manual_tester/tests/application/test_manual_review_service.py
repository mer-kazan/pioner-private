from __future__ import annotations

import shutil
import uuid
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from pathlib import Path

import pytest
from pydantic import ValidationError

from manual_test_platform.application.services.manual_review import (
    MANUAL_APPROVAL_TTL,
    ManualReviewRejectedError,
    ManualReviewService,
)
from manual_test_platform.manual_model.contracts import (
    ExpectedResult,
    ExpectedResultStatus,
    ProductProfileRef,
    RiskLevel,
    SourceEvidence,
    StepReadiness,
)
from manual_test_platform.manual_model.contracts import (
    TestCasePreparationStatus as PreparationStatus,
)
from manual_test_platform.manual_model.contracts import TestCaseReviewEvent as CaseEvent
from manual_test_platform.manual_model.contracts import (
    TestCaseReviewHistory as CaseHistory,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseRevision as CaseRevision,
)
from manual_test_platform.manual_model.contracts import (
    TestStep as CaseStep,
)
from manual_test_platform.manual_model.ports import (
    ManualHandoffApproval,
    ManualStepHandoff,
    OperatorObservation,
    OperatorOutcome,
)
from manual_test_platform.storage.case_repository import TestCaseRepository
from manual_test_platform.storage.manual_review_repository import (
    DuplicateOperatorObservationError,
    ManualReviewRepository,
    UnknownManualHandoffError,
)
from manual_test_platform.storage.sqlite_workspace import WorkspaceStorage


class RecordingManualAdapter:
    def __init__(self) -> None:
        self.presented: list[ManualStepHandoff] = []
        self.observations: list[OperatorObservation] = []

    def present(self, handoff: ManualStepHandoff) -> None:
        self.presented.append(handoff)

    def record_observation(self, observation: OperatorObservation) -> None:
        self.observations.append(observation)


def _preparation_events(
    revision_id: uuid.UUID,
    statuses: tuple[PreparationStatus, ...],
) -> tuple[CaseEvent, ...]:
    started_at = datetime.now(UTC)
    return tuple(
        CaseEvent(
            revision_id=revision_id,
            status=status,
            author_display_name="Reviewer",
            occurred_at=started_at + timedelta(seconds=position),
        )
        for position, status in enumerate(statuses)
    )


def _persisted_revision(storage: WorkspaceStorage) -> CaseRevision:
    manual_import_id = uuid.uuid4()
    source_revision_id = uuid.uuid4()
    manual_index_id = uuid.uuid4()
    manual_item_id = uuid.uuid4()
    source_text = "Check the displayed system status."
    source_ref = SourceEvidence(
        source_revision_id=source_revision_id,
        part_uri="word/document.xml",
        xpath="/document/body/p[1]",
        paragraph_index=0,
        quoted_text=source_text,
        quoted_text_sha256=sha256(source_text.encode("utf-8")).hexdigest(),
    )
    connection = storage.connect()
    try:
        connection.execute(
            """
            INSERT INTO source_revisions (
                id, format, original_name, relative_path, sha256, imported_at
            ) VALUES (?, 'docx', 'manual.docx', ?, ?, ?)
            """,
            (
                str(source_revision_id),
                f"source_documents/{uuid.uuid4().hex}.docx",
                sha256(uuid.uuid4().bytes).hexdigest(),
                datetime.now(UTC).isoformat(),
            ),
        )
        connection.execute(
            """
            INSERT INTO manual_imports (
                id, source_revision_id, created_at, status, error_code, error_message
            ) VALUES (?, ?, ?, 'IMPORTED', NULL, NULL)
            """,
            (str(manual_import_id), str(source_revision_id), datetime.now(UTC).isoformat()),
        )
        connection.execute(
            "INSERT INTO manual_indexes (id, manual_import_id, schema_version) VALUES (?, ?, 1)",
            (str(manual_index_id), str(manual_import_id)),
        )
        connection.execute(
            """
            INSERT INTO manual_items (
                id, manual_index_id, position, content_path, content_sha256,
                quality_flags_json
            ) VALUES (?, ?, 0, ?, ?, '[]')
            """,
            (
                str(manual_item_id),
                str(manual_index_id),
                f"manual_content/{manual_index_id}/{manual_item_id}.json",
                sha256(b"source content").hexdigest(),
            ),
        )
        connection.execute(
            """
            INSERT INTO source_refs (
                id, source_revision_id, part_uri, xpath, paragraph_index,
                quoted_text, quoted_text_sha256
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(source_ref.id),
                str(source_revision_id),
                source_ref.part_uri,
                source_ref.xpath,
                source_ref.paragraph_index,
                source_ref.quoted_text,
                source_ref.quoted_text_sha256,
            ),
        )
        connection.execute(
            """
            INSERT INTO item_content_source_refs (manual_item_id, content_pointer, source_ref_id)
            VALUES (?, '/blocks/0', ?)
            """,
            (str(manual_item_id), str(source_ref.id)),
        )
    finally:
        connection.close()

    step = CaseStep(
        position=0,
        instruction="Check the displayed system status.",
        source_ref_ids=(source_ref.id,),
        expected_result=ExpectedResult(
            status=ExpectedResultStatus.DOCUMENTED,
            text="The system status is displayed.",
            source_ref_ids=(source_ref.id,),
            observable_checks=("The status is visible.",),
        ),
        risk=RiskLevel.READ_ONLY,
        readiness=StepReadiness.READY,
    )
    revision = CaseRevision(
        test_case_id=uuid.uuid4(),
        revision_number=1,
        manual_import_id=manual_import_id,
        source_revision_id=source_revision_id,
        profile=ProductProfileRef(profile_id="n001", version="1"),
        title="Read system status",
        steps=(step,),
        source_refs=(source_ref,),
    )
    TestCaseRepository(storage).save_history(
        CaseHistory(
            revision=revision,
            events=_preparation_events(
                revision.id,
                (
                    PreparationStatus.DRAFT,
                    PreparationStatus.NEEDS_REVIEW,
                    PreparationStatus.READY,
                ),
            ),
        )
    )
    return revision


def _approved_handoff(
    revision: CaseRevision,
    *,
    step: CaseStep | None = None,
    source_refs: tuple[SourceEvidence, ...] | None = None,
    approved_at: datetime | None = None,
) -> ManualStepHandoff:
    step = step or revision.steps[0]
    source_refs = source_refs or (revision.source_refs[0],)
    target_id = "approved-lab-target"
    snapshot_sha256 = ManualStepHandoff.calculate_snapshot_sha256(
        test_case_revision_id=revision.id,
        profile=revision.profile,
        target_id=target_id,
        step=step,
        source_refs=source_refs,
    )
    return ManualStepHandoff(
        test_case_revision_id=revision.id,
        profile=revision.profile,
        target_id=target_id,
        step=step,
        source_refs=source_refs,
        approval=ManualHandoffApproval(
            target_id=target_id,
            snapshot_sha256=snapshot_sha256,
            approved_by_display_name="Operator",
            approved_at=approved_at or datetime.now(UTC),
        ),
    )


def _save_following_revision(
    storage: WorkspaceStorage,
    revision: CaseRevision,
    statuses: tuple[PreparationStatus, ...],
) -> CaseRevision:
    next_revision = CaseRevision.model_validate(
        revision.model_dump(
            mode="python",
            exclude={"id", "revision_number"},
        )
        | {"revision_number": revision.revision_number + 1}
    )
    TestCaseRepository(storage).save_history(
        CaseHistory(
            revision=next_revision,
            events=_preparation_events(next_revision.id, statuses),
        )
    )
    return next_revision


@pytest.fixture
def manual_review(
    tmp_path: Path,
) -> Iterator[
    tuple[
        CaseRevision,
        ManualReviewService,
        ManualReviewRepository,
        RecordingManualAdapter,
        WorkspaceStorage,
    ]
]:
    workspace_path = tmp_path / "workspace"
    workspace_path.mkdir()
    storage = WorkspaceStorage(workspace_path)
    storage.initialize()
    revision = _persisted_revision(storage)
    adapter = RecordingManualAdapter()
    repository = ManualReviewRepository(storage)
    service = ManualReviewService(TestCaseRepository(storage), repository, adapter)
    try:
        yield revision, service, repository, adapter, storage
    finally:
        shutil.rmtree(workspace_path, ignore_errors=True)


def test_manual_handoff_and_explicit_observation_are_persisted(manual_review) -> None:
    revision, service, repository, adapter, _ = manual_review
    handoff = _approved_handoff(revision)

    presented = service.present(handoff)

    assert presented == handoff
    assert adapter.presented == [handoff]
    assert repository.get_handoff(handoff.id) == handoff

    observation = OperatorObservation(
        handoff_id=handoff.id,
        outcome=OperatorOutcome.PASS,
        observation="The status was visible as documented.",
        author_display_name="Operator",
        occurred_at=datetime.now(UTC),
    )
    recorded = service.record_observation(observation)

    assert recorded == observation
    assert adapter.observations == [observation]
    assert repository.get_observation(handoff.id) == observation


def test_manual_service_rejects_expired_approval(manual_review) -> None:
    revision, _, repository, adapter, storage = manual_review
    now = datetime.now(UTC)
    service = ManualReviewService(
        TestCaseRepository(storage),
        repository,
        adapter,
        now_utc=lambda: now,
    )
    handoff = _approved_handoff(
        revision,
        approved_at=now - MANUAL_APPROVAL_TTL - timedelta(microseconds=1),
    )

    with pytest.raises(ManualReviewRejectedError, match="approval has expired"):
        service.present(handoff)

    assert adapter.presented == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(handoff.id)


def test_manual_service_accepts_approval_at_exact_ttl_boundary(manual_review) -> None:
    revision, _, repository, adapter, storage = manual_review
    now = datetime.now(UTC)
    service = ManualReviewService(
        TestCaseRepository(storage),
        repository,
        adapter,
        now_utc=lambda: now,
    )
    handoff = _approved_handoff(revision, approved_at=now - MANUAL_APPROVAL_TTL)

    assert service.present(handoff) == handoff
    assert adapter.presented == [handoff]
    assert repository.get_handoff(handoff.id) == handoff


def test_manual_service_rejects_future_dated_approval(manual_review) -> None:
    revision, _, repository, adapter, storage = manual_review
    now = datetime.now(UTC)
    service = ManualReviewService(
        TestCaseRepository(storage),
        repository,
        adapter,
        now_utc=lambda: now,
    )
    handoff = _approved_handoff(
        revision,
        approved_at=now + timedelta(microseconds=1),
    )

    with pytest.raises(ManualReviewRejectedError, match="future-dated"):
        service.present(handoff)

    assert adapter.presented == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(handoff.id)


def test_manual_service_rejects_revision_without_ready_preparation_history(manual_review) -> None:
    revision, service, repository, adapter, storage = manual_review
    pending_revision = _save_following_revision(
        storage,
        revision,
        (PreparationStatus.DRAFT, PreparationStatus.NEEDS_REVIEW),
    )

    with pytest.raises(ManualReviewRejectedError, match="requires READY"):
        service.present(_approved_handoff(pending_revision))

    assert adapter.presented == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(_approved_handoff(pending_revision).id)


def test_manual_service_rejects_handoff_for_superseded_revision(manual_review) -> None:
    revision, service, repository, adapter, storage = manual_review
    _save_following_revision(
        storage,
        revision,
        (
            PreparationStatus.DRAFT,
            PreparationStatus.NEEDS_REVIEW,
            PreparationStatus.READY,
        ),
    )

    with pytest.raises(ManualReviewRejectedError, match="superseded"):
        service.present(_approved_handoff(revision))

    assert adapter.presented == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(_approved_handoff(revision).id)


def test_manual_service_rejects_handoff_that_mismatches_stored_step(manual_review) -> None:
    revision, service, repository, adapter, _ = manual_review
    handoff = _approved_handoff(revision)
    changed_step = handoff.step.model_copy(update={"instruction": "Different instruction."})
    mismatched = handoff.model_copy(
        update={
            "step": changed_step,
            "approval": handoff.approval.model_copy(
                update={
                    "snapshot_sha256": ManualStepHandoff.calculate_snapshot_sha256(
                        test_case_revision_id=handoff.test_case_revision_id,
                        profile=handoff.profile,
                        target_id=handoff.target_id,
                        step=changed_step,
                        source_refs=handoff.source_refs,
                    )
                }
            ),
        }
    )

    with pytest.raises(ManualReviewRejectedError, match="does not match its stored revision"):
        service.present(mismatched)

    assert adapter.presented == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(handoff.id)


def test_manual_service_rejects_source_ref_not_in_stored_revision(manual_review) -> None:
    revision, service, repository, adapter, _ = manual_review
    altered_quote = "A different quoted source excerpt."
    foreign_ref = revision.source_refs[0].model_copy(
        update={
            "quoted_text": altered_quote,
            "quoted_text_sha256": sha256(altered_quote.encode("utf-8")).hexdigest(),
        }
    )
    handoff = _approved_handoff(revision, source_refs=(foreign_ref,))

    with pytest.raises(ManualReviewRejectedError, match="sources do not match"):
        service.present(handoff)

    assert adapter.presented == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(handoff.id)


def test_manual_service_rejects_invalid_snapshot_and_unknown_handoff(manual_review) -> None:
    revision, service, repository, adapter, _ = manual_review
    handoff = _approved_handoff(revision)
    invalid_approval = handoff.model_copy(
        update={"approval": handoff.approval.model_copy(update={"snapshot_sha256": "0" * 64})}
    )

    with pytest.raises(ValidationError, match="exact step snapshot"):
        service.present(invalid_approval)

    invalid_target = handoff.model_copy(
        update={"approval": handoff.approval.model_copy(update={"target_id": "different-target"})}
    )
    with pytest.raises(ValidationError, match="target the presented target"):
        service.present(invalid_target)

    observation = OperatorObservation(
        handoff_id=uuid.uuid4(),
        outcome=OperatorOutcome.UNKNOWN,
        observation="No explicit status could be recorded.",
        author_display_name="Operator",
        occurred_at=datetime.now(UTC),
    )
    with pytest.raises(UnknownManualHandoffError):
        service.record_observation(observation)

    assert adapter.presented == []
    assert adapter.observations == []
    with pytest.raises(UnknownManualHandoffError):
        repository.get_handoff(handoff.id)


def test_manual_service_rejects_duplicate_observation(manual_review) -> None:
    revision, service, repository, adapter, _ = manual_review
    handoff = service.present(_approved_handoff(revision))
    observation = OperatorObservation(
        handoff_id=handoff.id,
        outcome=OperatorOutcome.FAIL,
        observation="The status was not visible.",
        author_display_name="Operator",
        occurred_at=datetime.now(UTC),
    )

    service.record_observation(observation)
    with pytest.raises(DuplicateOperatorObservationError):
        service.record_observation(observation)

    assert repository.get_observation(handoff.id) == observation
    assert adapter.observations == [observation]
