from __future__ import annotations

from datetime import UTC, datetime, timedelta
from uuid import UUID

import pytest

from manual_test_platform.application.ports.manual_item_review import (
    ManualItemReviewPersistenceError,
)
from manual_test_platform.application.services.manual_item_review import (
    ManualItemReviewRejectedError,
    ManualItemReviewService,
)
from manual_test_platform.manual_model.contracts import ItemReviewCycle, ManualItem, ReviewStatus


class FakeManualItemReviewStore:
    def __init__(self, item: ManualItem) -> None:
        self.items = {item.id: item}
        self.cycles: dict[UUID, ItemReviewCycle] = {}
        self.fail_saves = False

    def get_item(self, item_id: UUID) -> ManualItem:
        return self.items[item_id]

    def get_cycle(self, cycle_id: UUID) -> ItemReviewCycle:
        return self.cycles[cycle_id]

    def save_cycle(self, cycle: ItemReviewCycle) -> ItemReviewCycle:
        if self.fail_saves:
            raise ManualItemReviewPersistenceError("The item review could not be saved")
        existing = self.cycles.get(cycle.id)
        if existing is not None and cycle.events[: len(existing.events)] != existing.events:
            raise ManualItemReviewPersistenceError("Review history must keep its stored prefix")
        self.cycles[cycle.id] = cycle
        item = self.items[cycle.manual_item_id]
        self.items[item.id] = item.model_copy(update={"active_review_cycle_id": cycle.id})
        return cycle


def _item() -> ManualItem:
    return ManualItem(
        position=0,
        heading="Setup",
        heading_level=1,
        content_path="manual_items/setup.json",
        content_sha256="a" * 64,
    )


def test_item_review_opens_confirms_and_reopens_with_pinned_content_hash() -> None:
    store = FakeManualItemReviewStore(_item())
    service = ManualItemReviewService(store)
    now = datetime.now(UTC)

    opened = service.start_review(_item_id(store), author_display_name="Reviewer", occurred_at=now)
    confirmed = service.confirm_review(
        opened.id,
        author_display_name="Reviewer",
        occurred_at=now + timedelta(seconds=1),
    )
    reopened = service.start_review(
        _item_id(store),
        author_display_name="Reviewer 2",
        occurred_at=now + timedelta(seconds=2),
    )

    assert opened.sequence == 1
    assert opened.events[0].status is ReviewStatus.IN_REVIEW
    assert confirmed.status is ReviewStatus.CONFIRMED
    assert confirmed.events[1].content_sha256 == "a" * 64
    assert reopened.sequence == 2
    assert reopened.events[0].content_sha256 == "a" * 64


def test_item_review_rejects_duplicate_active_cycle_and_terminal_confirmation() -> None:
    store = FakeManualItemReviewStore(_item())
    service = ManualItemReviewService(store)
    now = datetime.now(UTC)
    opened = service.start_review(_item_id(store), author_display_name="Reviewer", occurred_at=now)

    with pytest.raises(ManualItemReviewRejectedError, match="already has an active"):
        service.start_review(_item_id(store), author_display_name="Other", occurred_at=now)

    service.confirm_review(
        opened.id,
        author_display_name="Reviewer",
        occurred_at=now + timedelta(seconds=1),
    )
    with pytest.raises(ManualItemReviewRejectedError, match="Only an active"):
        service.confirm_review(
            opened.id,
            author_display_name="Reviewer",
            occurred_at=now + timedelta(seconds=2),
        )


def test_item_review_translates_store_failure() -> None:
    store = FakeManualItemReviewStore(_item())
    store.fail_saves = True

    with pytest.raises(ManualItemReviewRejectedError, match="could not be saved"):
        ManualItemReviewService(store).start_review(
            _item_id(store), author_display_name="Reviewer", occurred_at=datetime.now(UTC)
        )


def _item_id(store: FakeManualItemReviewStore) -> UUID:
    return next(iter(store.items))
