from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from manual_test_platform.application.ports.manual_import import ManualImportRecord
from manual_test_platform.application.services.manual_import import ManualImportService


class FakeManualImportStore:
    def __init__(self, result: ManualImportRecord | None) -> None:
        self.result = result
        self.import_calls: list[tuple[Path, str | None]] = []

    def import_docx(
        self,
        source_path: Path,
        *,
        recheck_of_import_id: str | None = None,
    ) -> ManualImportRecord:
        self.import_calls.append((source_path, recheck_of_import_id))
        assert self.result is not None
        return self.result

    def get_latest_import(self) -> ManualImportRecord | None:
        return self.result


def _record() -> ManualImportRecord:
    return ManualImportRecord(
        id="3df7cbd9-7b89-49ce-a8eb-9488742f4c6a",
        created_at=datetime(2026, 10, 19, tzinfo=UTC),
        status="IMPORTED",
        source_revision_id="70e1ccd0-f43e-452f-b945-7bb9be8e9812",
        manual_index_id="4a2dd02e-d378-463f-ba5a-068941d05e15",
        recheck_of_import_id=None,
        source_name="manual.docx",
        source_sha256="a" * 64,
        source_path=Path("workspace/source_documents/manual.docx"),
        items=(),
        error_code=None,
        error_message=None,
    )


def test_import_service_forwards_the_source_and_recheck_reference() -> None:
    store = FakeManualImportStore(_record())
    source_path = Path("manual.docx")

    result = ManualImportService(store).import_docx(
        source_path,
        recheck_of_import_id="7ea59c8a-6469-4cd5-96a5-3fe13c81106f",
    )

    assert str(result.manual_import.id) == _record().id
    assert store.import_calls == [
        (source_path, "7ea59c8a-6469-4cd5-96a5-3fe13c81106f"),
    ]


def test_import_service_reads_the_latest_import_through_its_port() -> None:
    record = _record()

    result = ManualImportService(FakeManualImportStore(record)).get_latest_import()

    assert result is not None
    assert str(result.manual_import.id) == record.id
