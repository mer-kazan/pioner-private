from __future__ import annotations

from datetime import UTC, datetime, timedelta
from hashlib import sha256
from uuid import UUID, uuid4

import pytest

from manual_test_platform.application.ports.test_case_preparation import (
    TestCasePreparationPersistenceError as PreparationPersistenceError,
)
from manual_test_platform.application.services.test_case_preparation import (
    TestCasePreparationRejectedError as PreparationRejectedError,
)
from manual_test_platform.application.services.test_case_preparation import (
    TestCasePreparationService as PreparationService,
)
from manual_test_platform.manual_model.contracts import (
    ExpectedResult,
    ExpectedResultStatus,
    ProductProfileRef,
    RiskLevel,
    SourceEvidence,
    StepReadiness,
)
from manual_test_platform.manual_model.contracts import (
    TestCasePreparationStatus as PreparationStatus,
)
from manual_test_platform.manual_model.contracts import TestCaseReviewHistory as ReviewHistory
from manual_test_platform.manual_model.contracts import TestCaseRevision as CaseRevision
from manual_test_platform.manual_model.contracts import TestStep as CaseStep


class FakeTestCasePreparationStore:
    def __init__(self) -> None:
        self.histories: dict[UUID, ReviewHistory] = {}
        self.fail_saves = False

    def get_history(self, revision_id: UUID) -> ReviewHistory:
        return self.histories[revision_id]

    def save_history(self, history: ReviewHistory) -> ReviewHistory:
        if self.fail_saves:
            raise PreparationPersistenceError("The preparation history could not be saved")
        self.histories[history.revision.id] = history
        return history


def test_preparation_moves_draft_to_review_then_ready() -> None:
    store = FakeTestCasePreparationStore()
    service = PreparationService(store)
    revision = _revision(readiness=StepReadiness.READY)
    now = datetime.now(UTC)

    draft = service.create_draft(revision, author_display_name="Author", occurred_at=now)
    reviewed = service.request_review(
        revision.id, author_display_name="Reviewer", occurred_at=now + timedelta(seconds=1)
    )
    ready = service.mark_ready(
        revision.id, author_display_name="Reviewer", occurred_at=now + timedelta(seconds=2)
    )

    assert draft.status is PreparationStatus.DRAFT
    assert reviewed.status is PreparationStatus.NEEDS_REVIEW
    assert ready.status is PreparationStatus.READY
    assert [event.status for event in ready.events] == [
        PreparationStatus.DRAFT,
        PreparationStatus.NEEDS_REVIEW,
        PreparationStatus.READY,
    ]


def test_preparation_rejects_invalid_transition_and_not_ready_steps() -> None:
    store = FakeTestCasePreparationStore()
    service = PreparationService(store)
    revision = _revision(readiness=StepReadiness.NEEDS_REVIEW)
    now = datetime.now(UTC)
    service.create_draft(revision, author_display_name="Author", occurred_at=now)

    with pytest.raises(PreparationRejectedError, match="Expected preparation status"):
        service.mark_ready(revision.id, author_display_name="Reviewer", occurred_at=now)

    service.request_review(revision.id, author_display_name="Reviewer", occurred_at=now)
    with pytest.raises(PreparationRejectedError, match="while any step needs review"):
        service.mark_ready(revision.id, author_display_name="Reviewer", occurred_at=now)


def test_preparation_translates_store_failure() -> None:
    store = FakeTestCasePreparationStore()
    store.fail_saves = True

    with pytest.raises(PreparationRejectedError, match="could not be saved"):
        PreparationService(store).create_draft(
            _revision(readiness=StepReadiness.READY),
            author_display_name="Author",
            occurred_at=datetime.now(UTC),
        )


def _revision(*, readiness: StepReadiness) -> CaseRevision:
    source_revision_id = uuid4()
    quote = "Documented result"
    evidence = SourceEvidence(
        source_revision_id=source_revision_id,
        part_uri="/word/document.xml",
        xpath="/w:document/w:body/w:p[1]",
        quoted_text=quote,
        quoted_text_sha256=sha256(quote.encode()).hexdigest(),
    )
    expected = ExpectedResult(
        status=ExpectedResultStatus.DOCUMENTED,
        text="The status is visible.",
        source_ref_ids=(evidence.id,),
        observable_checks=("Status is visible",),
    )
    return CaseRevision(
        test_case_id=uuid4(),
        revision_number=1,
        manual_import_id=uuid4(),
        source_revision_id=source_revision_id,
        profile=ProductProfileRef(profile_id="n001", version="1"),
        title="Check status",
        source_refs=(evidence,),
        steps=(
            CaseStep(
                position=0,
                instruction="Inspect the status.",
                source_ref_ids=(evidence.id,),
                expected_result=expected,
                risk=RiskLevel.READ_ONLY,
                readiness=readiness,
            ),
        ),
    )
