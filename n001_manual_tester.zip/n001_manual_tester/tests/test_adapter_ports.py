from __future__ import annotations

from datetime import UTC, datetime
from hashlib import sha256
from uuid import uuid4

import pytest
from pydantic import ValidationError

from manual_test_platform.manual_model.contracts import (
    CommandSpec,
    CommandVerificationStatus,
    ExecutionMode,
    ExpectedResult,
    ExpectedResultStatus,
    ProductProfileRef,
    RiskLevel,
    SourceEvidence,
    StepReadiness,
)
from manual_test_platform.manual_model.contracts import (
    TestStep as DomainTestStep,
)
from manual_test_platform.manual_model.ports import (
    CommandReviewAdvice,
    CommandReviewRequest,
    ManualHandoffApproval,
    ManualStepHandoff,
    OperatorObservation,
    OperatorOutcome,
)


def _source_evidence(source_revision_id, source_ref_id=None) -> SourceEvidence:
    text = "show bgp l2vpn evpn summary"
    return SourceEvidence(
        id=source_ref_id or uuid4(),
        source_revision_id=source_revision_id,
        part_uri="word/document.xml",
        xpath="/w:document/w:body/w:p[1]",
        block_index=0,
        paragraph_index=0,
        quoted_text=text,
        quoted_text_sha256=sha256(text.encode("utf-8")).hexdigest(),
    )


def _manual_step(source_ref_id) -> DomainTestStep:
    return DomainTestStep(
        position=0,
        instruction="Run the documented status command.",
        source_ref_ids=(source_ref_id,),
        command=CommandSpec(
            exact_text="show bgp l2vpn evpn summary",
            source_ref_ids=(source_ref_id,),
            verification_status=CommandVerificationStatus.VERIFIED,
        ),
        expected_result=ExpectedResult(
            status=ExpectedResultStatus.DOCUMENTED,
            text="A brief BGP neighbor summary is displayed.",
            source_ref_ids=(source_ref_id,),
            observable_checks=("The summary output is present.",),
        ),
        risk=RiskLevel.READ_ONLY,
        readiness=StepReadiness.READY,
    )


def _manual_handoff(source_refs, step=None, target_id="test-target") -> ManualStepHandoff:
    revision_id = uuid4()
    profile = ProductProfileRef(profile_id="n001", version="1")
    step = step or _manual_step(source_refs[0].id)
    snapshot_sha256 = ManualStepHandoff.calculate_snapshot_sha256(
        test_case_revision_id=revision_id,
        profile=profile,
        target_id=target_id,
        step=step,
        source_refs=tuple(source_refs),
    )
    return ManualStepHandoff(
        test_case_revision_id=revision_id,
        profile=profile,
        target_id=target_id,
        step=step,
        source_refs=tuple(source_refs),
        approval=ManualHandoffApproval(
            target_id=target_id,
            snapshot_sha256=snapshot_sha256,
            approved_by_display_name="Operator",
            approved_at=datetime.now(UTC),
        ),
    )


def test_manual_handoff_requires_all_step_sources() -> None:
    source_revision_id = uuid4()
    source_ref = _source_evidence(source_revision_id)
    step = _manual_step(source_ref.id)

    handoff = _manual_handoff((source_ref,), step)
    assert handoff.step.id == step.id

    with pytest.raises(ValidationError, match="match the step references"):
        _manual_handoff((), step)


def test_manual_handoff_rejects_steps_not_ready_for_manual_execution() -> None:
    source_ref = _source_evidence(uuid4())
    step = _manual_step(source_ref.id)

    with pytest.raises(ValidationError, match="Only manual-only steps"):
        _manual_handoff(
            (source_ref,),
            step.model_copy(update={"execution_mode": ExecutionMode.ADAPTER}),
        )

    with pytest.raises(ValidationError, match="Only READY steps"):
        _manual_handoff(
            (source_ref,),
            step.model_copy(update={"readiness": StepReadiness.NEEDS_REVIEW}),
        )


def test_manual_handoff_approval_is_bound_to_target_and_step_snapshot() -> None:
    source_ref = _source_evidence(uuid4())
    handoff = _manual_handoff((source_ref,))
    data = handoff.model_dump()

    with pytest.raises(ValidationError, match="target the presented target"):
        ManualStepHandoff(**{**data, "target_id": "different-target"})

    changed_step = handoff.step.model_copy(update={"instruction": "Run a different command."})
    with pytest.raises(ValidationError, match="exact step snapshot"):
        ManualStepHandoff(**{**data, "step": changed_step})


def test_operator_observation_requires_explicit_utc_timestamp() -> None:
    observation = OperatorObservation(
        handoff_id=uuid4(),
        outcome=OperatorOutcome.UNKNOWN,
        observation="Output could not be determined.",
        author_display_name="Operator",
        occurred_at=datetime.now(UTC),
    )
    assert observation.outcome is OperatorOutcome.UNKNOWN

    with pytest.raises(ValidationError, match="timezone-aware UTC"):
        OperatorObservation(
            handoff_id=uuid4(),
            outcome=OperatorOutcome.PASS,
            observation="Status displayed.",
            author_display_name="Operator",
            occurred_at=datetime.now(),
        )


def test_command_review_advice_must_correlate_and_cite_request_sources() -> None:
    source_revision_id = uuid4()
    source_ref = _source_evidence(source_revision_id)
    command = CommandSpec(
        exact_text="show bgp l2vpn evpn summary",
        source_ref_ids=(source_ref.id,),
    )
    request = CommandReviewRequest(
        profile=ProductProfileRef(profile_id="n001", version="1"),
        command=command,
        source_context=(source_ref,),
    )
    advice = CommandReviewAdvice(
        request_id=request.id,
        purpose="Display a BGP neighbor summary.",
        cited_source_ref_ids=(source_ref.id,),
    )

    assert request.validate_advice(advice) is advice
    with pytest.raises(ValueError, match="does not match its request"):
        request.validate_advice(
            CommandReviewAdvice(
                request_id=uuid4(),
                purpose="Display a BGP neighbor summary.",
                cited_source_ref_ids=(source_ref.id,),
            )
        )
    with pytest.raises(ValueError, match="outside its request context"):
        request.validate_advice(
            CommandReviewAdvice(
                request_id=request.id,
                purpose="Display a BGP neighbor summary.",
                cited_source_ref_ids=(uuid4(),),
            )
        )


def test_command_review_request_rejects_unrelated_source_revision() -> None:
    source = _source_evidence(uuid4())
    other_source = _source_evidence(uuid4())

    with pytest.raises(ValidationError, match="one source revision"):
        CommandReviewRequest(
            profile=ProductProfileRef(profile_id="n001", version="1"),
            command=CommandSpec(exact_text="show status", source_ref_ids=(source.id,)),
            source_context=(source, other_source),
        )
