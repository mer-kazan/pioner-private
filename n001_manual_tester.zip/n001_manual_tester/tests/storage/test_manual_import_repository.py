from __future__ import annotations

import hashlib
import json
import shutil
from collections.abc import Iterator, Mapping
from pathlib import Path
from typing import Any
from uuid import uuid4

import pytest
from docx import Document

from manual_test_platform.docx_parser import DocxImportError
from manual_test_platform.storage.manual_import_repository import ManualImportRepository
from manual_test_platform.storage.sqlite_workspace import WorkspaceStorage, WorkspaceStorageError

_TEST_WORKSPACES = Path(__file__).parent / ".test-workspaces"


@pytest.fixture
def workspace_path() -> Iterator[Path]:
    path = _TEST_WORKSPACES / uuid4().hex
    path.mkdir(parents=True)
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)
        if _TEST_WORKSPACES.exists() and not any(_TEST_WORKSPACES.iterdir()):
            _TEST_WORKSPACES.rmdir()


@pytest.fixture
def storage(workspace_path: Path) -> WorkspaceStorage:
    storage = WorkspaceStorage(workspace_path)
    storage.initialize()
    return storage


def _create_manual(path: Path, *, instruction: str = "Step one") -> None:
    document = Document()
    document.add_heading("Manual title", level=1)
    document.add_heading("Installation", level=2)
    document.add_paragraph(instruction)
    table = document.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "Action"
    table.cell(0, 1).text = "Observed result"
    document.add_heading("Troubleshooting", level=1)
    document.add_paragraph("Check the indicator")
    document.save(str(path))


def _read_item_content(workspace_path: Path, item: Any) -> Any:
    content_path = Path(item.content_path)
    if not content_path.is_absolute():
        content_path = workspace_path / content_path

    content_bytes = content_path.read_bytes()
    assert item.content_sha256 == hashlib.sha256(content_bytes).hexdigest()

    return json.loads(content_bytes)


def _text_values(value: Any) -> list[str]:
    texts: list[str] = []
    if isinstance(value, Mapping):
        for key, child in value.items():
            if key == "text" and isinstance(child, str):
                texts.append(child)
            else:
                texts.extend(_text_values(child))
    elif isinstance(value, list):
        for child in value:
            texts.extend(_text_values(child))
    return texts


def _block_text_values(content: Mapping[str, Any]) -> list[str]:
    blocks = content["blocks"]
    return [
        text
        for block in blocks
        if block.get("heading_level") is None
        for text in _text_values(block)
    ]


def _source_refs_for_item(storage: WorkspaceStorage, item_id: str) -> list[Mapping[str, Any]]:
    connection = storage.connect()
    try:
        rows = connection.execute(
            """
            SELECT
                item_content_source_refs.content_pointer,
                source_refs.id,
                source_refs.source_revision_id,
                source_refs.part_uri,
                source_refs.block_index,
                source_refs.paragraph_index,
                source_refs.table_index,
                source_refs.row_index,
                source_refs.cell_index,
                source_refs.quoted_text
            FROM item_content_source_refs
            JOIN source_refs
                ON source_refs.id = item_content_source_refs.source_ref_id
            WHERE item_content_source_refs.manual_item_id = ?
            """,
            (item_id,),
        ).fetchall()
    finally:
        connection.close()
    return rows


def _resolve_workspace_path(workspace_path: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else workspace_path / path


def test_import_persists_and_reopens_with_source_and_content_hashes(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    source_path = workspace_path / "manual.docx"
    _create_manual(source_path)
    source_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
    repository = ManualImportRepository(storage)

    imported = repository.import_docx(source_path)

    assert imported.status == "IMPORTED"
    assert imported.source_sha256 == source_hash
    assert imported.source_revision_id
    assert imported.manual_index_id
    assert imported.recheck_of_import_id is None
    assert imported.source_name == "manual.docx"
    assert isinstance(imported.items, tuple)
    assert imported.source_path is not None
    assert (
        hashlib.sha256(
            _resolve_workspace_path(workspace_path, imported.source_path).read_bytes()
        ).hexdigest()
        == imported.source_sha256
    )
    for item in imported.items:
        _read_item_content(workspace_path, item)

    reopened_storage = WorkspaceStorage(workspace_path)
    reopened_storage.initialize()
    reopened = ManualImportRepository(reopened_storage).get_import(imported.id)

    assert reopened == imported
    assert ManualImportRepository(reopened_storage).get_latest_import() == imported
    assert reopened.source_sha256 == source_hash
    for item in reopened.items:
        _read_item_content(workspace_path, item)


def test_import_items_preserve_heading_tree_ordered_content_and_provenance(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    source_path = workspace_path / "manual.docx"
    _create_manual(source_path)
    imported = ManualImportRepository(storage).import_docx(source_path)

    title = next(item for item in imported.items if item.heading == "Manual title")
    installation = next(item for item in imported.items if item.heading == "Installation")
    troubleshooting = next(item for item in imported.items if item.heading == "Troubleshooting")

    assert title.heading_level == 1
    assert title.parent_item_id is None
    assert installation.heading_level == 2
    assert installation.parent_item_id == title.id
    assert troubleshooting.heading_level == 1
    assert troubleshooting.parent_item_id is None

    root_items = sorted(
        (item for item in imported.items if item.parent_item_id is None),
        key=lambda item: item.position,
    )
    assert [item.heading for item in root_items] == ["Manual title", "Troubleshooting"]
    assert title.position < troubleshooting.position

    installation_content = _read_item_content(workspace_path, installation)
    assert _block_text_values(installation_content) == [
        "Step one",
        "Action",
        "Observed result",
    ]

    source_refs = _source_refs_for_item(storage, str(installation.id))
    paragraph_refs = [ref for ref in source_refs if ref["quoted_text"] == "Step one"]
    table_cell_refs = [ref for ref in source_refs if ref["quoted_text"] == "Observed result"]
    assert {
        (str(ref.evidence.id), ref.content_pointer, str(ref.evidence.source_revision_id))
        for ref in installation.source_refs
    } == {(ref["id"], ref["content_pointer"], ref["source_revision_id"]) for ref in source_refs}
    assert any(
        ref["part_uri"] == "word/document.xml"
        and ref["block_index"] == 2
        and ref["paragraph_index"] == 2
        for ref in paragraph_refs
    )
    assert any(
        ref["part_uri"] == "word/document.xml"
        and ref["block_index"] == 3
        and ref["table_index"] == 0
        and ref["row_index"] == 0
        and ref["cell_index"] == 1
        and ref["content_pointer"] == "/blocks/2/rows/0/1/content/0/source"
        for ref in table_cell_refs
    )


def test_unheaded_content_is_retained_with_boundary_review_flag(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    source_path = workspace_path / "unheaded.docx"
    document = Document()
    document.add_paragraph("Preface one")
    document.add_paragraph("Preface two")
    document.add_heading("First section", level=1)
    document.save(str(source_path))

    imported = ManualImportRepository(storage).import_docx(source_path)
    unheaded = next(item for item in imported.items if item.heading == "Unheaded content")

    assert unheaded.parent_item_id is None
    assert "UNHEADED_BOUNDARY_REVIEW" in unheaded.quality_flags
    assert _block_text_values(_read_item_content(workspace_path, unheaded)) == [
        "Preface one",
        "Preface two",
    ]


def test_recheck_with_identical_bytes_creates_fresh_import_and_items(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    source_path = workspace_path / "manual.docx"
    _create_manual(source_path)
    repository = ManualImportRepository(storage)

    original = repository.import_docx(source_path)
    original_snapshot = tuple(original.items)
    recheck = repository.import_docx(source_path, recheck_of_import_id=original.id)

    assert recheck.id != original.id
    assert recheck.recheck_of_import_id == original.id
    assert recheck.manual_index_id != original.manual_index_id
    assert recheck.source_revision_id == original.source_revision_id
    assert recheck.source_sha256 == original.source_sha256
    assert recheck.source_path == original.source_path
    assert {item.id for item in recheck.items}.isdisjoint({item.id for item in original.items})
    original_source_ref_ids = {
        ref.evidence.id for item in original.items for ref in item.source_refs
    }
    recheck_source_ref_ids = {ref.evidence.id for item in recheck.items for ref in item.source_refs}
    assert original_source_ref_ids.isdisjoint(recheck_source_ref_ids)
    assert original_source_ref_ids
    assert recheck_source_ref_ids
    assert tuple(repository.get_import(original.id).items) == original_snapshot
    assert repository.get_import(original.id) == original
    assert repository.get_latest_import() == recheck


def test_modified_bytes_with_recheck_create_a_new_source_revision(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    source_path = workspace_path / "manual.docx"
    _create_manual(source_path)
    repository = ManualImportRepository(storage)
    original = repository.import_docx(source_path)

    _create_manual(source_path, instruction="Step one, revised")
    revised_hash = hashlib.sha256(source_path.read_bytes()).hexdigest()
    recheck = repository.import_docx(source_path, recheck_of_import_id=original.id)

    assert recheck.status == "IMPORTED"
    assert recheck.recheck_of_import_id == original.id
    assert recheck.source_revision_id != original.source_revision_id
    assert recheck.source_sha256 == revised_hash
    assert recheck.source_sha256 != original.source_sha256


def test_invalid_docx_persists_failed_import_and_raises(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    invalid_path = workspace_path / "invalid.docx"
    invalid_path.write_bytes(b"not a DOCX file")
    repository = ManualImportRepository(storage)

    with pytest.raises(DocxImportError):
        repository.import_docx(invalid_path)

    connection = storage.connect()
    try:
        failed_imports = connection.execute(
            "SELECT id FROM manual_imports WHERE status = 'FAILED'"
        ).fetchall()
    finally:
        connection.close()

    assert len(failed_imports) == 1
    failed = repository.get_import(failed_imports[0]["id"])
    assert failed.status == "FAILED"


def test_missing_source_persists_failed_import_and_reraises_file_error(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    repository = ManualImportRepository(storage)
    missing_path = workspace_path / "missing.docx"

    with pytest.raises(FileNotFoundError):
        repository.import_docx(missing_path)

    connection = storage.connect()
    try:
        row = connection.execute(
            """
            SELECT id, error_code
            FROM manual_imports
            WHERE status = 'FAILED'
            """
        ).fetchone()
    finally:
        connection.close()

    assert row is not None
    assert row["error_code"] == "SOURCE_READ_ERROR"
    failed = repository.get_import(row["id"])
    assert failed.status == "FAILED"
    assert failed.source_revision_id is None
    assert failed.manual_index_id is None


def test_get_import_rejects_a_modified_stored_original(
    workspace_path: Path,
    storage: WorkspaceStorage,
) -> None:
    source_path = workspace_path / "manual.docx"
    _create_manual(source_path)
    repository = ManualImportRepository(storage)
    imported = repository.import_docx(source_path)
    assert imported.source_path is not None

    imported.source_path.write_bytes(b"tampered source")

    with pytest.raises(WorkspaceStorageError, match="integrity check failed"):
        repository.get_import(imported.id)
