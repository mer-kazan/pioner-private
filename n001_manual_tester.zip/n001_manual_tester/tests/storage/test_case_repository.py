from __future__ import annotations

import shutil
import sqlite3
import uuid
from collections.abc import Iterator
from contextlib import closing
from datetime import UTC, datetime, timedelta
from hashlib import sha256
from pathlib import Path

import pytest
from pydantic import ValidationError

from manual_test_platform.manual_model.contracts import (
    CommandSpec,
    CommandVerificationStatus,
    ExpectedResult,
    ExpectedResultStatus,
    ProductProfileRef,
    RiskLevel,
    SourceEvidence,
    StepReadiness,
)
from manual_test_platform.manual_model.contracts import (
    TestCasePreparationStatus as PreparationStatus,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseReviewEvent as PreparationEvent,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseReviewHistory as PreparationHistory,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseRevision as CaseRevision,
)
from manual_test_platform.manual_model.contracts import (
    TestPrecondition as Precondition,
)
from manual_test_platform.manual_model.contracts import (
    TestStep as Step,
)
from manual_test_platform.storage.case_repository import (
    AppendOnlyError,
    CaseOwnershipError,
    CaseRepositoryError,
    SourceReferenceError,
)
from manual_test_platform.storage.case_repository import (
    TestCaseRepository as CaseRepository,
)
from manual_test_platform.storage.sqlite_workspace import (
    CURRENT_SCHEMA_VERSION,
    WorkspaceStorage,
    _create_manual_import_schema,
    _create_workspace_metadata,
)

_TEST_WORKSPACES = Path(__file__).parent / ".test-workspaces"


@pytest.fixture
def storage(tmp_path: Path) -> Iterator[WorkspaceStorage]:
    path = _TEST_WORKSPACES / uuid.uuid4().hex
    path.mkdir(parents=True)
    workspace = WorkspaceStorage(path)
    workspace.initialize()
    try:
        yield workspace
    finally:
        shutil.rmtree(path, ignore_errors=True)
        if _TEST_WORKSPACES.exists() and not any(_TEST_WORKSPACES.iterdir()):
            _TEST_WORKSPACES.rmdir()


def _insert_import(
    storage: WorkspaceStorage,
    *,
    import_id: uuid.UUID | None = None,
    source_revision_id: uuid.UUID | None = None,
) -> tuple[uuid.UUID, uuid.UUID]:
    manual_import_id = import_id or uuid.uuid4()
    source_revision = source_revision_id or uuid.uuid4()
    manual_index_id = uuid.uuid4()
    item_ids = (uuid.uuid4(), uuid.uuid4())
    connection = storage.connect()
    try:
        source_exists = connection.execute(
            "SELECT 1 FROM source_revisions WHERE id = ?", (str(source_revision),)
        ).fetchone()
        if source_exists is None:
            connection.execute(
                """
                INSERT INTO source_revisions (
                    id, format, original_name, relative_path, sha256, imported_at
                ) VALUES (?, 'docx', 'manual.docx', ?, ?, ?)
                """,
                (
                    str(source_revision),
                    f"source_documents/{uuid.uuid4().hex}.docx",
                    uuid.uuid4().hex + uuid.uuid4().hex,
                    datetime.now(UTC).isoformat(),
                ),
            )
        connection.execute(
            """
            INSERT INTO manual_imports (
                id, source_revision_id, created_at, status, error_code, error_message
            ) VALUES (?, ?, ?, 'IMPORTED', NULL, NULL)
            """,
            (str(manual_import_id), str(source_revision), datetime.now(UTC).isoformat()),
        )
        connection.execute(
            """
            INSERT INTO manual_indexes (id, manual_import_id, schema_version)
            VALUES (?, ?, 1)
            """,
            (str(manual_index_id), str(manual_import_id)),
        )
        for position, item_id in enumerate(item_ids):
            connection.execute(
                """
                INSERT INTO manual_items (
                    id, manual_index_id, position, content_path, content_sha256,
                    quality_flags_json
                ) VALUES (?, ?, ?, ?, ?, '[]')
                """,
                (
                    str(item_id),
                    str(manual_index_id),
                    position,
                    f"manual_content/{manual_index_id}/{item_id}.json",
                    sha256(str(item_id).encode("utf-8")).hexdigest(),
                ),
            )
    finally:
        connection.close()
    return manual_import_id, source_revision


def _insert_source_evidence(
    storage: WorkspaceStorage,
    manual_import_id: uuid.UUID,
    source_revision_id: uuid.UUID,
) -> tuple[SourceEvidence, SourceEvidence]:
    evidence_items = (
        SourceEvidence(
            source_revision_id=source_revision_id,
            part_uri="word/document.xml",
            xpath="/document/body/p[1]",
            paragraph_index=0,
            quoted_text="Open the terminal.",
            quoted_text_sha256=sha256(b"Open the terminal.").hexdigest(),
        ),
        SourceEvidence(
            source_revision_id=source_revision_id,
            part_uri="word/document.xml",
            xpath="/document/body/p[2]",
            paragraph_index=1,
            quoted_text="Check the response.",
            quoted_text_sha256=sha256(b"Check the response.").hexdigest(),
        ),
    )
    connection = storage.connect()
    try:
        for evidence_position, evidence in enumerate(evidence_items):
            connection.execute(
                """
                INSERT INTO source_refs (
                    id, source_revision_id, part_uri, xpath, block_index, paragraph_index,
                    table_index, row_index, cell_index, quoted_text, quoted_text_sha256
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(evidence.id),
                    str(evidence.source_revision_id),
                    evidence.part_uri,
                    evidence.xpath,
                    evidence.block_index,
                    evidence.paragraph_index,
                    evidence.table_index,
                    evidence.row_index,
                    evidence.cell_index,
                    evidence.quoted_text,
                    evidence.quoted_text_sha256,
                ),
            )
            item_row = connection.execute(
                """
                SELECT items.id
                FROM manual_items AS items
                JOIN manual_indexes AS indexes ON indexes.id = items.manual_index_id
                WHERE indexes.manual_import_id = ?
                ORDER BY items.position
                LIMIT 1 OFFSET ?
                """,
                (str(manual_import_id), evidence_position),
            ).fetchone()
            assert item_row is not None
            connection.execute(
                """
                INSERT INTO item_content_source_refs (
                    manual_item_id, content_pointer, source_ref_id
                ) VALUES (?, ?, ?)
                """,
                (item_row["id"], "/blocks/0/source", str(evidence.id)),
            )
    finally:
        connection.close()
    return evidence_items


def _revision(
    manual_import_id: uuid.UUID,
    source_revision_id: uuid.UUID,
    evidence: tuple[SourceEvidence, SourceEvidence],
    *,
    test_case_id: uuid.UUID | None = None,
    revision_number: int = 1,
    revision_id: uuid.UUID | None = None,
) -> CaseRevision:
    instruction_ref, result_ref = evidence
    step = Step(
        position=0,
        instruction="Run the documented command.",
        source_ref_ids=(instruction_ref.id, result_ref.id),
        command=CommandSpec(
            exact_text="show status",
            source_ref_ids=(instruction_ref.id,),
            verification_status=CommandVerificationStatus.VERIFIED,
        ),
        expected_result=ExpectedResult(
            status=ExpectedResultStatus.DOCUMENTED,
            text="The status is displayed.",
            source_ref_ids=(result_ref.id,),
            observable_checks=("Status output is visible.",),
        ),
        risk=RiskLevel.READ_ONLY,
        readiness=StepReadiness.NEEDS_REVIEW,
    )
    return CaseRevision(
        id=revision_id or uuid.uuid4(),
        test_case_id=test_case_id or uuid.uuid4(),
        revision_number=revision_number,
        manual_import_id=manual_import_id,
        source_revision_id=source_revision_id,
        profile=ProductProfileRef(profile_id="device-x", version="1"),
        title="Check device status",
        preconditions=(
            Precondition(text="Device is online.", source_ref_ids=(instruction_ref.id,)),
        ),
        steps=(step,),
        source_refs=evidence,
    )


def _event(
    revision_id: uuid.UUID,
    status: PreparationStatus,
    position: int = 0,
) -> PreparationEvent:
    return PreparationEvent(
        revision_id=revision_id,
        status=status,
        author_display_name="Reviewer",
        occurred_at=datetime(2026, 1, 1, tzinfo=UTC) + timedelta(minutes=position),
    )


def test_schema_two_workspace_migrates_to_case_storage(tmp_path: Path) -> None:
    storage = WorkspaceStorage(tmp_path)
    legacy_import_id = uuid.uuid4()
    legacy_source_id = uuid.uuid4()
    connection = sqlite3.connect(storage.database_path)
    try:
        connection.execute("BEGIN EXCLUSIVE")
        _create_workspace_metadata(connection, str(uuid.uuid4()))
        connection.execute(
            """
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY CHECK (version >= 1),
                applied_at TEXT NOT NULL
            )
            """
        )
        _create_manual_import_schema(connection, "")
        connection.execute(
            """
            INSERT INTO source_revisions (
                id, format, original_name, relative_path, sha256, imported_at
            ) VALUES (?, 'docx', 'legacy.docx', 'source_documents/legacy.docx', ?, ?)
            """,
            (str(legacy_source_id), "b" * 64, datetime.now(UTC).isoformat()),
        )
        connection.execute(
            """
            INSERT INTO manual_imports (
                id, source_revision_id, created_at, status, error_code, error_message
            ) VALUES (?, ?, ?, 'IMPORTED', NULL, NULL)
            """,
            (str(legacy_import_id), str(legacy_source_id), datetime.now(UTC).isoformat()),
        )
        connection.executemany(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)",
            ((1, "legacy"), (2, "legacy")),
        )
        connection.execute("UPDATE workspace_meta SET schema_version = 2 WHERE id = 1")
        connection.execute("PRAGMA user_version = 2")
        connection.commit()
    finally:
        connection.close()

    migrated = WorkspaceStorage(tmp_path)
    migrated.initialize()
    assert migrated.schema_version == CURRENT_SCHEMA_VERSION
    with closing(migrated.connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM test_cases").fetchone()[0] == 0
        assert connection.execute(
            "SELECT source_revision_id FROM manual_imports WHERE id = ?",
            (str(legacy_import_id),),
        ).fetchone()[0] == str(legacy_source_id)
        assert [
            row[0]
            for row in connection.execute("SELECT version FROM schema_migrations ORDER BY version")
        ] == list(range(1, CURRENT_SCHEMA_VERSION + 1))


def test_revision_and_preparation_history_round_trip(storage: WorkspaceStorage) -> None:
    manual_import_id, source_revision_id = _insert_import(storage)
    evidence = _insert_source_evidence(storage, manual_import_id, source_revision_id)
    revision = _revision(manual_import_id, source_revision_id, evidence)
    repository = CaseRepository(storage)
    first_event = _event(revision.id, PreparationStatus.DRAFT)
    repository.save_history(PreparationHistory(revision=revision, events=(first_event,)))
    second_event = _event(revision.id, PreparationStatus.NEEDS_REVIEW, 1)
    saved = repository.save_history(
        PreparationHistory(revision=revision, events=(first_event, second_event))
    )

    assert saved == repository.get_history(revision.id)
    assert saved.revision == revision
    assert saved.events == (first_event, second_event)
    assert repository.get_case(revision.test_case_id).current_revision_id == revision.id
    with closing(storage.connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM test_steps").fetchone()[0] == 1
        assert connection.execute("SELECT COUNT(*) FROM test_step_source_refs").fetchone()[0] == 4
        command = connection.execute(
            "SELECT content_json FROM test_steps WHERE revision_id = ?",
            (str(revision.id),),
        ).fetchone()[0]
        assert '"exact_text":"show status"' in command


def test_save_rejects_unknown_source_reference_without_writing_case(
    storage: WorkspaceStorage,
) -> None:
    manual_import_id, source_revision_id = _insert_import(storage)
    evidence = _insert_source_evidence(storage, manual_import_id, source_revision_id)
    revision = _revision(manual_import_id, source_revision_id, evidence)
    unknown = uuid.uuid4()
    malformed_evidence = (
        evidence[0],
        evidence[1].model_copy(update={"id": unknown}),
    )
    bad_step = revision.steps[0].model_copy(
        update={
            "source_ref_ids": (evidence[0].id, unknown),
            "expected_result": revision.steps[0].expected_result.model_copy(
                update={"source_ref_ids": (unknown,)}
            ),
        }
    )
    bad_revision = revision.model_copy(
        update={"source_refs": malformed_evidence, "steps": (bad_step,)}
    )

    with pytest.raises(SourceReferenceError, match="does not exist in source_refs"):
        CaseRepository(storage).save_history(PreparationHistory(revision=bad_revision))

    with closing(storage.connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM test_cases").fetchone()[0] == 0
        assert connection.execute("SELECT COUNT(*) FROM test_case_revisions").fetchone()[0] == 0


def test_save_rejects_forged_source_locator_or_quote(storage: WorkspaceStorage) -> None:
    manual_import_id, source_revision_id = _insert_import(storage)
    evidence = _insert_source_evidence(storage, manual_import_id, source_revision_id)
    revision = _revision(manual_import_id, source_revision_id, evidence)
    forged_ref = evidence[0].model_copy(
        update={
            "xpath": "/document/body/p[999]",
            "quoted_text": "Altered quote",
            "quoted_text_sha256": sha256(b"Altered quote").hexdigest(),
        }
    )
    forged_revision = revision.model_copy(update={"source_refs": (forged_ref, *evidence[1:])})

    with pytest.raises(SourceReferenceError, match="does not match its persisted"):
        CaseRepository(storage).save_history(PreparationHistory(revision=forged_revision))

    with closing(storage.connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM test_cases").fetchone()[0] == 0


def test_load_rejects_evidence_missing_from_source_refs(storage: WorkspaceStorage) -> None:
    manual_import_id, source_revision_id = _insert_import(storage)
    evidence = _insert_source_evidence(storage, manual_import_id, source_revision_id)
    revision = _revision(manual_import_id, source_revision_id, evidence)
    repository = CaseRepository(storage)
    repository.save_history(PreparationHistory(revision=revision))

    connection = sqlite3.connect(storage.database_path)
    try:
        connection.execute("PRAGMA foreign_keys = OFF")
        connection.execute("DELETE FROM source_refs WHERE id = ?", (str(evidence[0].id),))
        connection.commit()
    finally:
        connection.close()

    with pytest.raises(SourceReferenceError, match="does not exist in source_refs"):
        repository.get_history(revision.id)


def test_save_rejects_cross_import_and_cross_source_revision(
    storage: WorkspaceStorage,
) -> None:
    first_import, first_source = _insert_import(storage)
    second_import, second_source = _insert_import(storage)
    first_evidence = _insert_source_evidence(storage, first_import, first_source)
    second_evidence = _insert_source_evidence(storage, second_import, second_source)
    first_revision = _revision(first_import, first_source, first_evidence)
    repository = CaseRepository(storage)
    repository.save_history(PreparationHistory(revision=first_revision))

    cross_import = _revision(
        second_import,
        second_source,
        second_evidence,
        test_case_id=first_revision.test_case_id,
        revision_number=2,
    )
    with pytest.raises(CaseOwnershipError, match="belongs to another manual import"):
        repository.save_history(PreparationHistory(revision=cross_import))

    wrong_source = _revision(first_import, second_source, second_evidence)
    with pytest.raises(SourceReferenceError, match="does not match manual import"):
        repository.save_history(PreparationHistory(revision=wrong_source))


def test_save_rejects_ref_from_another_import_of_same_source(storage: WorkspaceStorage) -> None:
    first_import, source_revision_id = _insert_import(storage)
    second_import, _ = _insert_import(storage, source_revision_id=source_revision_id)
    _insert_source_evidence(storage, first_import, source_revision_id)
    other_import_evidence = _insert_source_evidence(storage, second_import, source_revision_id)
    revision = _revision(first_import, source_revision_id, other_import_evidence)

    with pytest.raises(SourceReferenceError, match="not linked to manual import"):
        CaseRepository(storage).save_history(PreparationHistory(revision=revision))


def test_failed_history_insert_rolls_back_revision_and_case(
    storage: WorkspaceStorage,
) -> None:
    manual_import_id, source_revision_id = _insert_import(storage)
    evidence = _insert_source_evidence(storage, manual_import_id, source_revision_id)
    revision = _revision(manual_import_id, source_revision_id, evidence)
    event = _event(revision.id, PreparationStatus.DRAFT)
    connection = storage.connect()
    try:
        connection.execute(
            """
            CREATE TRIGGER fail_review_event
            BEFORE INSERT ON test_case_review_events
            BEGIN
                SELECT RAISE(ABORT, 'injected event insert failure');
            END
            """
        )
    finally:
        connection.close()

    with pytest.raises(CaseRepositoryError, match="Could not persist"):
        CaseRepository(storage).save_history(PreparationHistory(revision=revision, events=(event,)))

    with closing(storage.connect()) as connection:
        assert connection.execute("SELECT COUNT(*) FROM test_cases").fetchone()[0] == 0
        assert connection.execute("SELECT COUNT(*) FROM test_case_revisions").fetchone()[0] == 0
        assert connection.execute("SELECT COUNT(*) FROM test_case_review_events").fetchone()[0] == 0


def test_revision_content_and_events_are_append_only(storage: WorkspaceStorage) -> None:
    manual_import_id, source_revision_id = _insert_import(storage)
    evidence = _insert_source_evidence(storage, manual_import_id, source_revision_id)
    revision = _revision(manual_import_id, source_revision_id, evidence)
    event = _event(revision.id, PreparationStatus.DRAFT)
    repository = CaseRepository(storage)
    repository.save_history(PreparationHistory(revision=revision, events=(event,)))

    altered = revision.model_copy(update={"title": "Changed title"})
    with pytest.raises(AppendOnlyError, match="immutable"):
        repository.save_history(PreparationHistory(revision=altered, events=(event,)))

    with closing(storage.connect()) as connection, pytest.raises(sqlite3.IntegrityError):
        connection.execute(
            "DELETE FROM test_case_review_events WHERE id = ?",
            (str(event.id),),
        )


def test_ready_history_is_rejected_when_a_step_is_not_ready() -> None:
    revision_id = uuid.uuid4()
    source_revision_id = uuid.uuid4()
    evidence = SourceEvidence(
        source_revision_id=source_revision_id,
        part_uri="word/document.xml",
        xpath="/document/body/p[1]",
    )
    revision = CaseRevision.model_construct(
        id=revision_id,
        test_case_id=uuid.uuid4(),
        revision_number=1,
        manual_import_id=uuid.uuid4(),
        source_revision_id=source_revision_id,
        profile=ProductProfileRef(profile_id="device-x", version="1"),
        title="Check device status",
        preconditions=(),
        steps=(
            Step(
                position=0,
                instruction="Review this step.",
                source_ref_ids=(evidence.id,),
                readiness=StepReadiness.NEEDS_REVIEW,
            ),
        ),
        source_refs=(evidence,),
    )
    events = (
        _event(revision_id, PreparationStatus.DRAFT),
        _event(revision_id, PreparationStatus.NEEDS_REVIEW, 1),
        _event(revision_id, PreparationStatus.READY, 2),
    )

    with pytest.raises(ValidationError, match="cannot be READY"):
        PreparationHistory(revision=revision, events=events)
