"""Integration tests for SQLite item-review repository."""

from __future__ import annotations

import hashlib
import shutil
import uuid
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path
from uuid import uuid4

import pytest

from manual_test_platform.manual_model.contracts import (
    ItemReviewCycle,
    ItemReviewEvent,
    ReviewStatus,
)
from manual_test_platform.storage.manual_item_review_repository import (
    SqliteManualItemReviewRepository,
)
from manual_test_platform.storage.sqlite_workspace import WorkspaceStorage

_TEST_WORKSPACES = Path(__file__).parent / ".test-workspaces"


@pytest.fixture
def storage(tmp_path: Path) -> Iterator[WorkspaceStorage]:
    path = _TEST_WORKSPACES / uuid.uuid4().hex
    path.mkdir(parents=True)
    workspace = WorkspaceStorage(path)
    workspace.initialize()
    try:
        yield workspace
    finally:
        shutil.rmtree(path, ignore_errors=True)
        if _TEST_WORKSPACES.exists() and not any(_TEST_WORKSPACES.iterdir()):
            _TEST_WORKSPACES.rmdir()


def _make_item(
    storage: WorkspaceStorage,
    *,
    item_id: uuid.UUID | None = None,
    content_sha256: str = "a" * 64,
    review_cycle_id: uuid.UUID | None = None,
) -> uuid.UUID:
    manual_item_id = item_id or uuid4()
    manual_index_id = uuid4()
    manual_import_id = uuid4()
    source_revision_id = uuid4()
    connection = storage.connect()
    try:
        connection.execute(
            """
            INSERT INTO source_revisions
                (id, format, original_name, relative_path, sha256, imported_at)
            VALUES (?, 'docx', 'manual.docx', ?, ?, ?)
            """,
            (
                str(source_revision_id),
                f"source_documents/{uuid.uuid4().hex}.docx",
                hashlib.sha256(b"manual").hexdigest(),
                datetime.now(UTC).isoformat(),
            ),
        )
        connection.execute(
            """
            INSERT INTO manual_imports
                (id, source_revision_id, created_at, status, error_code, error_message)
            VALUES (?, ?, ?, 'IMPORTED', NULL, NULL)
            """,
            (str(manual_import_id), str(source_revision_id), datetime.now(UTC).isoformat()),
        )
        connection.execute(
            """
            INSERT INTO manual_indexes (id, manual_import_id, schema_version)
            VALUES (?, ?, 1)
            """,
            (str(manual_index_id), str(manual_import_id)),
        )
        connection.execute(
            """
            INSERT INTO manual_items (id, manual_index_id, position, content_path, content_sha256,
                                      quality_flags_json, review_cycle_id)
            VALUES (?, ?, 0, ?, ?, '[]', ?)
            """,
            (
                str(manual_item_id),
                str(manual_index_id),
                f"manual_content/{manual_index_id}/{manual_item_id}.json",
                content_sha256,
                str(review_cycle_id) if review_cycle_id else None,
            ),
        )
    finally:
        connection.close()
    return manual_item_id


def test_review_cycle_open_confirm_and_reopen_with_pinned_hash(
    storage: WorkspaceStorage,
) -> None:
    repository = SqliteManualItemReviewRepository(storage)
    item_id = _make_item(storage)
    opened_item = repository.get_item(item_id)
    now = datetime.now(UTC)

    cycle_id = uuid4()
    cycle = ItemReviewCycle(
        id=cycle_id,
        manual_item_id=item_id,
        sequence=1,
        events=(
            ItemReviewEvent(
                cycle_id=cycle_id,
                status=ReviewStatus.IN_REVIEW,
                content_sha256=opened_item.content_sha256,
                author_display_name="Reviewer",
                occurred_at=now,
            ),
        ),
    )
    saved = repository.save_cycle(cycle)
    assert saved.events[0].status is ReviewStatus.IN_REVIEW
    assert saved.events[0].content_sha256 == "a" * 64

    confirmed_cycle = ItemReviewCycle(
        id=cycle_id,
        manual_item_id=item_id,
        sequence=1,
        events=(
            *saved.events,
            ItemReviewEvent(
                cycle_id=cycle_id,
                status=ReviewStatus.CONFIRMED,
                content_sha256=saved.events[0].content_sha256,
                author_display_name="Reviewer",
                occurred_at=now + timedelta(seconds=1),
            ),
        ),
    )
    saved_confirmed = repository.save_cycle(confirmed_cycle)
    assert saved_confirmed.events[1].status is ReviewStatus.CONFIRMED
    assert saved_confirmed.events[1].content_sha256 == "a" * 64

    item_after = repository.get_item(item_id)
    assert item_after.active_review_cycle_id == cycle_id

    reopened_id = uuid4()
    reopened_cycle = ItemReviewCycle(
        id=reopened_id,
        manual_item_id=item_id,
        sequence=2,
        events=(
            ItemReviewEvent(
                cycle_id=reopened_id,
                status=ReviewStatus.IN_REVIEW,
                content_sha256=opened_item.content_sha256,
                author_display_name="Reviewer 2",
                occurred_at=now + timedelta(seconds=2),
            ),
        ),
    )
    saved_reopened = repository.save_cycle(reopened_cycle)
    assert saved_reopened.sequence == 2
    assert saved_reopened.events[0].content_sha256 == "a" * 64

    item_final = repository.get_item(item_id)
    assert item_final.active_review_cycle_id == reopened_id


def test_get_cycle_returns_stored_events(
    storage: WorkspaceStorage,
) -> None:
    repository = SqliteManualItemReviewRepository(storage)
    item_id = _make_item(storage)
    cycle_id = uuid4()
    now = datetime.now(UTC)

    cycle = ItemReviewCycle(
        id=cycle_id,
        manual_item_id=item_id,
        sequence=1,
        events=(
            ItemReviewEvent(
                cycle_id=cycle_id,
                status=ReviewStatus.IN_REVIEW,
                content_sha256="a" * 64,
                author_display_name="Reviewer",
                occurred_at=now,
            ),
        ),
    )
    repository.save_cycle(cycle)

    loaded = repository.get_cycle(cycle_id)
    assert loaded.id == cycle_id
    assert loaded.sequence == 1
    assert len(loaded.events) == 1
    assert loaded.events[0].status is ReviewStatus.IN_REVIEW


def test_get_item_raises_key_error_when_missing(
    storage: WorkspaceStorage,
) -> None:
    repository = SqliteManualItemReviewRepository(storage)
    with pytest.raises(KeyError, match="not found"):
        repository.get_item(uuid4())


def test_get_cycle_raises_key_error_when_missing(
    storage: WorkspaceStorage,
) -> None:
    repository = SqliteManualItemReviewRepository(storage)
    with pytest.raises(KeyError, match="not found"):
        repository.get_cycle(uuid4())


def test_save_cycle_rejects_non_prefix_history(
    storage: WorkspaceStorage,
) -> None:
    repository = SqliteManualItemReviewRepository(storage)
    item_id = _make_item(storage)
    cycle_id = uuid4()
    now = datetime.now(UTC)

    cycle = ItemReviewCycle(
        id=cycle_id,
        manual_item_id=item_id,
        sequence=1,
        events=(
            ItemReviewEvent(
                cycle_id=cycle_id,
                status=ReviewStatus.IN_REVIEW,
                content_sha256="a" * 64,
                author_display_name="Reviewer",
                occurred_at=now,
            ),
        ),
    )
    repository.save_cycle(cycle)

    bad_cycle = ItemReviewCycle(
        id=cycle_id,
        manual_item_id=item_id,
        sequence=1,
        events=(
            ItemReviewEvent(
                cycle_id=cycle_id,
                status=ReviewStatus.IN_REVIEW,
                content_sha256="a" * 64,
                author_display_name="Someone Else",
                occurred_at=now,
            ),
        ),
    )
    with pytest.raises(Exception, match="Review history must keep its stored prefix"):
        repository.save_cycle(bad_cycle)
