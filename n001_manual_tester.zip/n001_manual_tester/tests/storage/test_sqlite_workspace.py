from __future__ import annotations

import shutil
import sqlite3
import uuid
from collections.abc import Iterator
from pathlib import Path

import pytest

import manual_test_platform.storage.sqlite_workspace as sqlite_workspace
from manual_test_platform.storage.sqlite_workspace import (
    CURRENT_SCHEMA_VERSION,
    Migration,
    MigrationError,
    UnsupportedSchemaError,
    WorkspaceStorage,
    WorkspaceStorageError,
    _create_manual_import_schema,
    _create_test_case_schema,
    _create_workspace_metadata,
)

_TEST_WORKSPACES = Path(__file__).parent / ".test-workspaces"


@pytest.fixture
def workspace_path() -> Iterator[Path]:
    path = _TEST_WORKSPACES / uuid.uuid4().hex
    path.mkdir(parents=True)
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)
        if _TEST_WORKSPACES.exists() and not any(_TEST_WORKSPACES.iterdir()):
            _TEST_WORKSPACES.rmdir()


def test_initialization_creates_workspace_and_manual_import_schema(
    workspace_path: Path,
) -> None:
    requested_id = uuid.uuid4()
    storage = WorkspaceStorage(workspace_path, workspace_id=requested_id)

    assert storage.initialize() == str(requested_id)
    assert storage.workspace_id == str(requested_id)
    assert storage.schema_version == CURRENT_SCHEMA_VERSION
    assert storage.database_path == workspace_path / "workspace.sqlite3"

    connection = storage.connect()
    try:
        tables = {
            row["name"]
            for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
        metadata = connection.execute(
            "SELECT workspace_id, schema_version FROM workspace_meta WHERE id = 1"
        ).fetchone()
        migrations = connection.execute(
            "SELECT version FROM schema_migrations ORDER BY version"
        ).fetchall()
    finally:
        connection.close()

    assert tables == {
        "workspace_meta",
        "schema_migrations",
        "source_revisions",
        "manual_imports",
        "manual_indexes",
        "manual_items",
        "source_refs",
        "item_content_source_refs",
        "test_cases",
        "test_case_revisions",
        "test_revision_source_refs",
        "test_preconditions",
        "test_precondition_source_refs",
        "test_steps",
        "test_step_source_refs",
        "test_case_review_events",
        "manual_step_handoffs",
        "operator_observations",
        "item_review_cycles",
        "item_review_events",
    }
    assert metadata["workspace_id"] == str(requested_id)
    assert metadata["schema_version"] == CURRENT_SCHEMA_VERSION
    assert [row["version"] for row in migrations] == list(range(1, CURRENT_SCHEMA_VERSION + 1))


def test_foreign_keys_are_enabled_and_restrict_history_deletion(workspace_path: Path) -> None:
    storage = WorkspaceStorage(workspace_path)
    storage.initialize()
    connection = storage.connect()
    try:
        assert connection.execute("PRAGMA foreign_keys").fetchone()[0] == 1
        connection.execute("CREATE TEMP TABLE fk_parent (id INTEGER PRIMARY KEY)")
        connection.execute(
            """
            CREATE TEMP TABLE fk_history (
                id INTEGER PRIMARY KEY,
                parent_id INTEGER NOT NULL REFERENCES fk_parent(id)
            )
            """
        )
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("INSERT INTO fk_history (id, parent_id) VALUES (1, 999)")

        connection.execute("INSERT INTO fk_parent (id) VALUES (1)")
        connection.execute("INSERT INTO fk_history (id, parent_id) VALUES (1, 1)")
        with pytest.raises(sqlite3.IntegrityError):
            connection.execute("DELETE FROM fk_parent WHERE id = 1")
    finally:
        connection.close()


def test_workspaces_have_separate_databases_and_uuids(workspace_path: Path) -> None:
    first = WorkspaceStorage(workspace_path / "first")
    second = WorkspaceStorage(workspace_path / "second")

    first_id = first.initialize()
    second_id = second.initialize()

    assert first.database_path != second.database_path
    assert first_id != second_id
    for storage, expected_id in ((first, first_id), (second, second_id)):
        connection = storage.connect()
        try:
            row = connection.execute(
                "SELECT workspace_id FROM workspace_meta WHERE id = 1"
            ).fetchone()
        finally:
            connection.close()
        assert row["workspace_id"] == expected_id


def test_version_one_workspace_is_backed_up_and_migrated(workspace_path: Path) -> None:
    workspace_id = str(uuid.uuid4())
    connection = sqlite3.connect(workspace_path / "workspace.sqlite3")
    try:
        connection.execute("BEGIN EXCLUSIVE")
        sqlite_workspace._create_workspace_metadata(connection, workspace_id)
        connection.execute(
            """
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY CHECK (version >= 1),
                applied_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (1, 'legacy')"
        )
        connection.execute("PRAGMA user_version = 1")
        connection.commit()
    finally:
        connection.close()

    storage = WorkspaceStorage(workspace_path)
    assert storage.initialize() == workspace_id
    assert storage.schema_version == CURRENT_SCHEMA_VERSION
    assert list(workspace_path.glob("workspace.sqlite3.backup-*"))

    connection = storage.connect()
    try:
        assert (
            connection.execute("SELECT schema_version FROM workspace_meta WHERE id = 1").fetchone()[
                0
            ]
            == CURRENT_SCHEMA_VERSION
        )
        assert connection.execute("SELECT COUNT(*) FROM source_revisions").fetchone()[0] == 0
        assert [
            row[0]
            for row in connection.execute("SELECT version FROM schema_migrations ORDER BY version")
        ] == list(range(1, CURRENT_SCHEMA_VERSION + 1))
    finally:
        connection.close()


def test_version_three_workspace_is_migrated_to_manual_review_schema(
    workspace_path: Path,
) -> None:
    workspace_id = str(uuid.uuid4())
    connection = sqlite3.connect(workspace_path / "workspace.sqlite3")
    try:
        connection.execute("BEGIN EXCLUSIVE")
        _create_workspace_metadata(connection, workspace_id)
        connection.execute(
            """
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY CHECK (version >= 1),
                applied_at TEXT NOT NULL
            )
            """
        )
        connection.execute(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (1, 'legacy')"
        )
        _create_manual_import_schema(connection, workspace_id)
        connection.execute("UPDATE workspace_meta SET schema_version = 2 WHERE id = 1")
        connection.execute(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (2, 'legacy')"
        )
        _create_test_case_schema(connection, workspace_id)
        connection.execute("UPDATE workspace_meta SET schema_version = 3 WHERE id = 1")
        connection.execute(
            "INSERT INTO schema_migrations (version, applied_at) VALUES (3, 'legacy')"
        )
        connection.execute("PRAGMA user_version = 3")
        connection.commit()
    finally:
        connection.close()

    storage = WorkspaceStorage(workspace_path)
    assert storage.initialize() == workspace_id
    assert storage.schema_version == CURRENT_SCHEMA_VERSION

    connection = storage.connect()
    try:
        tables = {
            row["name"]
            for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
        assert {"manual_step_handoffs", "operator_observations"} <= tables
        assert {"item_review_cycles", "item_review_events"} <= tables
        assert [
            row[0]
            for row in connection.execute("SELECT version FROM schema_migrations ORDER BY version")
        ] == list(range(1, CURRENT_SCHEMA_VERSION + 1))
    finally:
        connection.close()


def test_migration_backup_and_rollback_preserve_original_database(
    workspace_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    storage = WorkspaceStorage(workspace_path)
    original_id = storage.initialize()
    original_schema_version = CURRENT_SCHEMA_VERSION

    def failing_migration(connection: sqlite3.Connection, workspace_id: str) -> None:
        assert workspace_id == original_id
        connection.execute("UPDATE workspace_meta SET updated_at = 'partial-change' WHERE id = 1")
        raise RuntimeError("injected migration failure")

    monkeypatch.setattr(
        sqlite_workspace,
        "MIGRATIONS",
        (
            *sqlite_workspace.MIGRATIONS,
            Migration(version=original_schema_version + 1, apply=failing_migration),
        ),
    )
    monkeypatch.setattr(sqlite_workspace, "CURRENT_SCHEMA_VERSION", original_schema_version + 1)
    migrating_storage = WorkspaceStorage(workspace_path)

    with pytest.raises(MigrationError, match=f"migration {original_schema_version + 1} failed"):
        migrating_storage.initialize()

    backups = list(workspace_path.glob("workspace.sqlite3.backup-*"))
    assert len(backups) == 1

    for database_path in (storage.database_path, backups[0]):
        connection = sqlite3.connect(database_path)
        try:
            assert (
                connection.execute("PRAGMA user_version").fetchone()[0] == original_schema_version
            )
            row = connection.execute(
                "SELECT workspace_id, schema_version, updated_at FROM workspace_meta WHERE id = 1"
            ).fetchone()
        finally:
            connection.close()
        assert row[0] == original_id
        assert row[1] == original_schema_version
        assert row[2] != "partial-change"


@pytest.mark.parametrize("schema_version", [0, CURRENT_SCHEMA_VERSION + 1])
def test_unknown_or_newer_schema_fails_without_modifying_database(
    workspace_path: Path,
    schema_version: int,
) -> None:
    database_path = workspace_path / "workspace.sqlite3"
    connection = sqlite3.connect(database_path)
    try:
        connection.execute("CREATE TABLE unrecognized_data (value TEXT)")
        connection.execute(f"PRAGMA user_version = {schema_version}")
        connection.commit()
    finally:
        connection.close()
    original_bytes = database_path.read_bytes()

    with pytest.raises(UnsupportedSchemaError):
        WorkspaceStorage(workspace_path).initialize()

    assert database_path.read_bytes() == original_bytes
    assert not list(workspace_path.glob("workspace.sqlite3.backup-*"))


def test_requested_workspace_uuid_must_match_existing_database(workspace_path: Path) -> None:
    storage = WorkspaceStorage(workspace_path)
    original_id = storage.initialize()

    with pytest.raises(WorkspaceStorageError, match="does not match"):
        WorkspaceStorage(workspace_path, workspace_id=uuid.uuid4()).initialize()

    assert WorkspaceStorage(workspace_path).initialize() == original_id
