from __future__ import annotations

from datetime import UTC, datetime
from hashlib import sha256
from uuid import uuid4

import pytest
from pydantic import ValidationError

from manual_test_platform.manual_model.contracts import (
    AmendmentStatus,
    CommandSpec,
    CommandVerificationStatus,
    ExecutionMode,
    ExpectedResult,
    ExpectedResultStatus,
    ItemReviewCycle,
    ItemReviewEvent,
    ManualAmendment,
    ManualImport,
    ManualImportStatus,
    ManualIndex,
    ManualItem,
    ProductProfileRef,
    ReviewStatus,
    RiskLevel,
    SourceEvidence,
    StepReadiness,
)
from manual_test_platform.manual_model.contracts import TestCase as Case
from manual_test_platform.manual_model.contracts import (
    TestCasePreparationStatus as CasePreparationStatus,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseReviewEvent as CaseReviewEvent,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseReviewHistory as CaseReviewHistory,
)
from manual_test_platform.manual_model.contracts import (
    TestCaseRevision as CaseRevision,
)
from manual_test_platform.manual_model.contracts import (
    TestPrecondition as Precondition,
)
from manual_test_platform.manual_model.contracts import (
    TestStep as Step,
)

_NOW = datetime.now(UTC)
_HASH = "a" * 64


def _source_evidence(source_ref_id, source_revision_id) -> SourceEvidence:
    return SourceEvidence(
        id=source_ref_id,
        source_revision_id=source_revision_id,
        part_uri="word/document.xml",
        xpath="/w:document/w:body/w:p[1]",
        block_index=0,
        paragraph_index=0,
        quoted_text="Show EVPN BGP neighbor status.",
        quoted_text_sha256=sha256(b"Show EVPN BGP neighbor status.").hexdigest(),
    )


def _item(
    *,
    item_id=None,
    parent_item_id=None,
    position: int = 0,
) -> ManualItem:
    return ManualItem(
        id=item_id or uuid4(),
        parent_item_id=parent_item_id,
        position=position,
        heading="Installation",
        heading_level=1,
        content_path=f"manual_content/index/{uuid4()}.json",
        content_sha256=_HASH,
    )


def test_manual_import_requires_index_only_for_successful_import() -> None:
    imported = ManualImport(
        source_revision_id=uuid4(),
        manual_index_id=uuid4(),
        created_at=_NOW,
        status=ManualImportStatus.IMPORTED,
    )
    failed = ManualImport(
        source_revision_id=None,
        created_at=_NOW,
        status=ManualImportStatus.FAILED,
        error_code="DOCX_IMPORT_ERROR",
        error_message="The selected DOCX file could not be imported.",
    )

    assert imported.manual_index_id is not None
    assert failed.manual_index_id is None

    with pytest.raises(ValidationError, match="manual index"):
        ManualImport(
            source_revision_id=uuid4(),
            created_at=_NOW,
            status=ManualImportStatus.IMPORTED,
        )


def test_manual_index_validates_parentage_order_and_cycles() -> None:
    parent_id = uuid4()
    parent = _item(item_id=parent_id)
    child = _item(parent_item_id=parent_id)
    index = ManualIndex(
        manual_import_id=uuid4(),
        schema_version=1,
        items=(parent, child),
    )
    assert index.items == (parent, child)

    with pytest.raises(ValidationError, match="same index"):
        ManualIndex(
            manual_import_id=uuid4(),
            schema_version=1,
            items=(_item(parent_item_id=uuid4()),),
        )

    first_id, second_id = uuid4(), uuid4()
    with pytest.raises(ValidationError, match="cycles"):
        ManualIndex(
            manual_import_id=uuid4(),
            schema_version=1,
            items=(
                _item(item_id=first_id, parent_item_id=second_id),
                _item(item_id=second_id, parent_item_id=first_id, position=1),
            ),
        )


def test_review_confirmation_is_bound_to_content_and_terminal() -> None:
    cycle_id = uuid4()
    started = ItemReviewEvent(
        cycle_id=cycle_id,
        status=ReviewStatus.IN_REVIEW,
        content_sha256=_HASH,
        author_display_name="Operator",
        occurred_at=_NOW,
    )
    confirmed = ItemReviewEvent(
        cycle_id=cycle_id,
        status=ReviewStatus.CONFIRMED,
        content_sha256=_HASH,
        author_display_name="Operator",
        occurred_at=_NOW,
    )
    cycle = ItemReviewCycle(
        id=cycle_id,
        manual_item_id=uuid4(),
        sequence=1,
        events=(started, confirmed),
    )

    assert cycle.status is ReviewStatus.CONFIRMED
    with pytest.raises(ValidationError, match="begin with IN_REVIEW"):
        ItemReviewCycle(
            id=cycle_id,
            manual_item_id=uuid4(),
            sequence=1,
            events=(confirmed,),
        )

    changed_content = ItemReviewEvent(
        cycle_id=cycle_id,
        status=ReviewStatus.CONFIRMED,
        content_sha256="b" * 64,
        author_display_name="Operator",
        occurred_at=_NOW,
    )
    with pytest.raises(ValidationError, match="cannot change"):
        ItemReviewCycle(
            id=cycle_id,
            manual_item_id=uuid4(),
            sequence=1,
            events=(started, changed_content),
        )


def test_amendment_needs_explicit_terminal_decision() -> None:
    proposed = ManualAmendment(
        manual_item_id=uuid4(),
        content="Add a verified clarification.",
        status=AmendmentStatus.PROPOSED,
        author_display_name="Operator",
        created_at=_NOW,
    )
    confirmed = ManualAmendment(
        manual_item_id=uuid4(),
        content="Add a verified clarification.",
        status=AmendmentStatus.CONFIRMED,
        author_display_name="Operator",
        created_at=_NOW,
        decided_by_display_name="Reviewer",
        decided_at=_NOW,
    )

    assert proposed.decided_at is None
    assert confirmed.status is AmendmentStatus.CONFIRMED
    with pytest.raises(ValidationError, match="require a decision"):
        ManualAmendment(
            manual_item_id=uuid4(),
            content="Add a verified clarification.",
            status=AmendmentStatus.CONFIRMED,
            author_display_name="Operator",
            created_at=_NOW,
        )


def test_command_contract_preserves_source_literal_and_marks_parameters() -> None:
    source_ref_id = uuid4()
    extracted_template = CommandSpec(
        exact_text="clear bgp l2vpn evpn { as-num-dot { in | out }}",
        source_ref_ids=(source_ref_id,),
        unresolved_parameters=("as-num-dot", "in | out"),
    )

    assert extracted_template.exact_text.startswith("clear bgp")
    assert extracted_template.verification_status is CommandVerificationStatus.UNVERIFIED
    with pytest.raises(ValidationError, match="unresolved parameters"):
        CommandSpec(
            exact_text=extracted_template.exact_text,
            source_ref_ids=(source_ref_id,),
            verification_status=CommandVerificationStatus.VERIFIED,
            unresolved_parameters=extracted_template.unresolved_parameters,
        )


def test_source_evidence_verifies_quote_hash() -> None:
    source_revision_id = uuid4()
    source_ref_id = uuid4()
    source_ref = _source_evidence(source_ref_id, source_revision_id)
    assert source_ref.source_revision_id == source_revision_id

    with pytest.raises(ValidationError, match="does not match"):
        SourceEvidence(
            id=uuid4(),
            source_revision_id=source_revision_id,
            part_uri="word/document.xml",
            xpath="/w:document/w:body/w:p[1]",
            quoted_text="Quote with invalid digest.",
            quoted_text_sha256="0" * 64,
        )


def test_expected_result_must_be_source_grounded_or_explicitly_unknown() -> None:
    source_ref_id = uuid4()
    documented = ExpectedResult(
        status=ExpectedResultStatus.DOCUMENTED,
        text="Brief information about BGP neighbor status is displayed.",
        source_ref_ids=(source_ref_id,),
        observable_checks=("BGP neighbor status information is present.",),
    )
    unspecified = ExpectedResult(
        status=ExpectedResultStatus.NOT_SPECIFIED,
        text="НЕ УКАЗАНО В МАНУАЛЕ",
    )

    assert documented.observable_checks
    assert unspecified.status is ExpectedResultStatus.NOT_SPECIFIED
    with pytest.raises(ValidationError, match="source references"):
        ExpectedResult(
            status=ExpectedResultStatus.DOCUMENTED,
            text="Some result",
            observable_checks=("A result is visible.",),
        )


def test_ready_steps_require_provenance_result_and_verified_command() -> None:
    source_ref_id = uuid4()
    verified_show_command = CommandSpec(
        exact_text="show bgp l2vpn evpn summary",
        source_ref_ids=(source_ref_id,),
        verification_status=CommandVerificationStatus.VERIFIED,
    )
    documented_result = ExpectedResult(
        status=ExpectedResultStatus.DOCUMENTED,
        text="Brief information about BGP neighbor status is displayed.",
        source_ref_ids=(source_ref_id,),
        observable_checks=("BGP neighbor status information is present.",),
    )
    ready_read_only_step = Step(
        position=0,
        instruction="Display the EVPN BGP neighbor summary.",
        source_ref_ids=(source_ref_id,),
        command=verified_show_command,
        expected_result=documented_result,
        risk=RiskLevel.READ_ONLY,
        execution_mode=ExecutionMode.ADAPTER,
        readiness=StepReadiness.READY,
    )

    assert ready_read_only_step.readiness is StepReadiness.READY
    with pytest.raises(ValidationError, match="Unverified commands"):
        Step(
            position=0,
            instruction="Display the EVPN BGP neighbor summary.",
            source_ref_ids=(source_ref_id,),
            command=CommandSpec(
                exact_text=verified_show_command.exact_text,
                source_ref_ids=(source_ref_id,),
            ),
            expected_result=documented_result,
            risk=RiskLevel.READ_ONLY,
            execution_mode=ExecutionMode.ADAPTER,
            readiness=StepReadiness.READY,
        )
    with pytest.raises(ValidationError, match="documented expected result"):
        Step(
            position=0,
            instruction="Display the EVPN BGP neighbor summary.",
            source_ref_ids=(source_ref_id,),
            command=verified_show_command,
            risk=RiskLevel.READ_ONLY,
            execution_mode=ExecutionMode.ADAPTER,
            readiness=StepReadiness.READY,
        )


def test_disruptive_steps_remain_manual_even_when_result_is_documented() -> None:
    source_ref_id = uuid4()
    command = CommandSpec(
        exact_text="ztp run",
        source_ref_ids=(source_ref_id,),
        verification_status=CommandVerificationStatus.VERIFIED,
    )
    expected_result = ExpectedResult(
        status=ExpectedResultStatus.DOCUMENTED,
        text="ZTP Service is Active Discovery.",
        source_ref_ids=(source_ref_id,),
        observable_checks=("Output contains 'ZTP Service: Active Discovery'.",),
    )

    manual_step = Step(
        position=0,
        instruction="Start the ZTP process once, after explicit operator approval.",
        source_ref_ids=(source_ref_id,),
        command=command,
        expected_result=expected_result,
        risk=RiskLevel.DISRUPTIVE,
        execution_mode=ExecutionMode.MANUAL_ONLY,
        readiness=StepReadiness.READY,
    )
    assert manual_step.readiness is StepReadiness.READY

    with pytest.raises(ValidationError, match="manual-only"):
        Step(
            position=0,
            instruction="Start the ZTP process once.",
            source_ref_ids=(source_ref_id,),
            command=command,
            expected_result=expected_result,
            risk=RiskLevel.DISRUPTIVE,
            execution_mode=ExecutionMode.ADAPTER,
            readiness=StepReadiness.READY,
        )


def test_test_case_revision_and_review_history_are_revision_pinned() -> None:
    source_ref_id = uuid4()
    revision_id = uuid4()
    test_case_id = uuid4()
    manual_import_id = uuid4()
    source_revision_id = uuid4()
    profile = ProductProfileRef(profile_id="n001", version="1")

    precondition = Precondition(
        text="BGP is configured for autonomous system 100.",
        source_ref_ids=(source_ref_id,),
    )
    ready_step = Step(
        position=0,
        instruction="Display the EVPN BGP neighbor summary.",
        source_ref_ids=(source_ref_id,),
        command=CommandSpec(
            exact_text="show bgp l2vpn evpn summary",
            source_ref_ids=(source_ref_id,),
            verification_status=CommandVerificationStatus.VERIFIED,
        ),
        expected_result=ExpectedResult(
            status=ExpectedResultStatus.DOCUMENTED,
            text="Brief information about BGP neighbor status is displayed.",
            source_ref_ids=(source_ref_id,),
            observable_checks=("BGP neighbor status information is present.",),
        ),
        risk=RiskLevel.READ_ONLY,
        execution_mode=ExecutionMode.ADAPTER,
        readiness=StepReadiness.READY,
    )
    revision = CaseRevision(
        id=revision_id,
        test_case_id=test_case_id,
        revision_number=1,
        manual_import_id=manual_import_id,
        source_revision_id=source_revision_id,
        profile=profile,
        title="Inspect EVPN BGP neighbor summary",
        preconditions=(precondition,),
        steps=(ready_step,),
        source_refs=(_source_evidence(source_ref_id, source_revision_id),),
    )
    case = Case(id=test_case_id, current_revision_id=revision.id)
    assert case.current_revision_id == revision.id
    events = (
        CaseReviewEvent(
            revision_id=revision_id,
            status=CasePreparationStatus.DRAFT,
            author_display_name="Operator",
            occurred_at=_NOW,
        ),
        CaseReviewEvent(
            revision_id=revision_id,
            status=CasePreparationStatus.NEEDS_REVIEW,
            author_display_name="Operator",
            occurred_at=_NOW,
        ),
        CaseReviewEvent(
            revision_id=revision_id,
            status=CasePreparationStatus.READY,
            author_display_name="Reviewer",
            occurred_at=_NOW,
        ),
    )
    history = CaseReviewHistory(revision=revision, events=events)

    assert history.status is CasePreparationStatus.READY

    unready_revision = CaseRevision(
        id=revision_id,
        test_case_id=test_case_id,
        revision_number=1,
        manual_import_id=manual_import_id,
        source_revision_id=source_revision_id,
        profile=profile,
        title="Inspect EVPN BGP neighbor summary",
        preconditions=(precondition,),
        steps=(
            Step(
                position=0,
                instruction="Display the EVPN BGP neighbor summary.",
                source_ref_ids=(source_ref_id,),
                command=ready_step.command,
                expected_result=ready_step.expected_result,
                risk=RiskLevel.READ_ONLY,
                readiness=StepReadiness.NEEDS_REVIEW,
            ),
        ),
        source_refs=(_source_evidence(source_ref_id, source_revision_id),),
    )
    with pytest.raises(ValidationError, match="any step needs review"):
        CaseReviewHistory(revision=unready_revision, events=events)


def test_revision_rejects_unresolved_or_cross_revision_source_refs() -> None:
    source_ref_id = uuid4()
    source_revision_id = uuid4()
    step = Step(
        position=0,
        instruction="Inspect EVPN BGP neighbor summary.",
        source_ref_ids=(source_ref_id,),
    )
    common = {
        "test_case_id": uuid4(),
        "revision_number": 1,
        "manual_import_id": uuid4(),
        "source_revision_id": source_revision_id,
        "profile": ProductProfileRef(profile_id="n001", version="1"),
        "title": "Inspect EVPN",
        "steps": (step,),
    }

    with pytest.raises(ValidationError, match="resolve within the revision"):
        CaseRevision(**common)
    with pytest.raises(ValidationError, match="belong to the revision source"):
        CaseRevision(
            **common,
            source_refs=(_source_evidence(source_ref_id, uuid4()),),
        )
