from __future__ import annotations

import hashlib
import shutil
import zipfile
from collections.abc import Iterator
from pathlib import Path
from uuid import UUID

import lxml.etree as etree
import pytest
from docx import Document

from manual_test_platform.docx_parser import (
    DocxImportError,
    ImportLimits,
    ManualLoader,
    ParagraphBlock,
    TableBlock,
    UnsupportedBlock,
)

WORK_DIR = Path(__file__).parent / ".docx-import-work"


@pytest.fixture
def work_dir() -> Iterator[Path]:
    shutil.rmtree(WORK_DIR, ignore_errors=True)
    WORK_DIR.mkdir(parents=True)
    try:
        yield WORK_DIR
    finally:
        shutil.rmtree(WORK_DIR, ignore_errors=True)


def _create_manual(path: Path) -> None:
    document = Document()
    document.add_heading("Manual title", level=1)
    document.add_paragraph("Unclassified introduction")
    document.add_heading("Installation", level=2)
    document.add_paragraph("Step one")
    table = document.add_table(rows=1, cols=2)
    table.cell(0, 0).text = "Action"
    table.cell(0, 1).text = "Observed result"
    document.add_heading("Troubleshooting", level=1)
    document.add_paragraph("Check the indicator")
    document.save(str(path))


def _rewrite_package(source: Path, target: Path, updates: dict[str, bytes]) -> None:
    with zipfile.ZipFile(source) as original, zipfile.ZipFile(target, "w") as rewritten:
        for entry in original.infolist():
            rewritten.writestr(entry, updates.pop(entry.filename, original.read(entry.filename)))
        for name, contents in updates.items():
            rewritten.writestr(name, contents)


def test_import_preserves_order_heading_hierarchy_and_precise_provenance(
    work_dir: Path,
) -> None:
    source_path = work_dir / "manual.docx"
    _create_manual(source_path)
    source_bytes = source_path.read_bytes()

    result = ManualLoader(source_path).load()

    assert result.revision.format == "docx"
    assert result.revision.sha256 == hashlib.sha256(source_bytes).hexdigest()
    assert isinstance(result.revision.id, UUID)
    assert result.revision.id.version == 4
    assert result.revision.imported_at.tzinfo is not None
    assert [block.kind for block in result.blocks] == [
        "paragraph",
        "paragraph",
        "paragraph",
        "paragraph",
        "table",
        "paragraph",
        "paragraph",
        "unsupported",
    ]

    (
        title,
        introduction,
        section,
        instruction,
        table,
        last_heading,
        body_text,
        section_properties,
    ) = result.blocks
    assert isinstance(title, ParagraphBlock) and title.heading_level == 1
    assert isinstance(section, ParagraphBlock) and section.heading_level == 2
    assert isinstance(last_heading, ParagraphBlock) and last_heading.heading_level == 1
    assert introduction.parent_heading_id == title.id
    assert instruction.parent_heading_id == section.id
    assert isinstance(table, TableBlock) and table.parent_heading_id == section.id
    assert isinstance(body_text, ParagraphBlock) and body_text.text == "Check the indicator"
    assert isinstance(section_properties, UnsupportedBlock)

    assert title.source.part_uri == "word/document.xml"
    assert title.source.block_index == 0
    assert title.source.paragraph_index == 0
    assert title.source.xpath.endswith("/w:p[1]")
    assert title.source.quoted_text == "Manual title"
    assert title.source.quoted_text_sha256 == hashlib.sha256(b"Manual title").hexdigest()
    assert table.source.table_index == 0
    assert table.rows[0][1].content[0].source.row_index == 0
    assert table.rows[0][1].content[0].source.cell_index == 1
    assert table.rows[0][1].content[0].text == "Observed result"
    with pytest.raises(ValueError):
        result.revision.sha256 = "0" * 64  # type: ignore[misc]


def test_import_retains_unsupported_body_elements_and_external_link_metadata(
    work_dir: Path,
) -> None:
    source_path = work_dir / "source.docx"
    _create_manual(source_path)
    with zipfile.ZipFile(source_path) as archive:
        document_root = etree.fromstring(archive.read("word/document.xml"))
        relationships_root = etree.fromstring(archive.read("word/_rels/document.xml.rels"))

    body = document_root.find("w:body", namespaces=document_root.nsmap)
    assert body is not None
    unsupported = etree.Element(
        "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}altChunk"
    )
    unsupported.set(
        "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id", "rIdAlt"
    )
    body.insert(len(body) - 1, unsupported)
    relationships_root.append(
        etree.Element(
            "{http://schemas.openxmlformats.org/package/2006/relationships}Relationship",
            Id="rIdExternal",
            Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
            Target="https://example.invalid/untrusted",
            TargetMode="External",
        )
    )
    target_path = work_dir / "with-unsupported.docx"
    _rewrite_package(
        source_path,
        target_path,
        {
            "word/document.xml": etree.tostring(document_root),
            "word/_rels/document.xml.rels": etree.tostring(relationships_root),
        },
    )

    result = ManualLoader(target_path).load()

    assert isinstance(result.blocks[-2], UnsupportedBlock)
    assert result.blocks[-2].tag == "w:altChunk"
    assert result.blocks[-2].source.xpath.endswith("/w:altChunk[1]")
    assert result.ignored_external_relationships[0].relationship_id == "rIdExternal"
    assert result.ignored_external_relationships[0].source_part_uri == "word/document.xml"
    assert "example.invalid" not in repr(result.ignored_external_relationships)


@pytest.mark.parametrize(
    ("filename", "contents", "message"),
    [
        ("manual.txt", b"not a document", "Only files with the .docx extension"),
        ("manual.docx", b"not a zip", "not a valid ZIP-based DOCX"),
    ],
)
def test_rejects_wrong_extension_and_non_zip_input(
    work_dir: Path,
    filename: str,
    contents: bytes,
    message: str,
) -> None:
    path = work_dir / filename
    path.write_bytes(contents)

    with pytest.raises(DocxImportError, match=message):
        ManualLoader(path).load()


def test_rejects_zip_traversal_and_duplicate_parts(work_dir: Path) -> None:
    original = work_dir / "manual.docx"
    _create_manual(original)
    traversal = work_dir / "traversal.docx"
    _rewrite_package(original, traversal, {"../outside.xml": b"<x/>"})
    duplicate = work_dir / "duplicate.docx"
    with zipfile.ZipFile(original) as archive, zipfile.ZipFile(duplicate, "w") as output:
        for entry in archive.infolist():
            output.writestr(entry, archive.read(entry.filename))
        with pytest.warns(UserWarning, match="Duplicate name"):
            output.writestr("word/document.xml", b"<duplicate/>")

    with pytest.raises(DocxImportError, match="unsafe ZIP entry path"):
        ManualLoader(traversal).load()
    with pytest.raises(DocxImportError, match="duplicate ZIP entry"):
        ManualLoader(duplicate).load()


def test_rejects_oversized_entries_and_macro_enabled_packages(work_dir: Path) -> None:
    source = work_dir / "manual.docx"
    _create_manual(source)
    with pytest.raises(DocxImportError, match="oversized ZIP entry"):
        ManualLoader(source, ImportLimits(max_member_bytes=16)).load()
    with pytest.raises(DocxImportError, match="total uncompressed-size"):
        ManualLoader(source, ImportLimits(max_uncompressed_bytes=16)).load()
    with pytest.raises(DocxImportError, match="compression-ratio"):
        ManualLoader(source, ImportLimits(max_compression_ratio=1)).load()

    with zipfile.ZipFile(source) as archive:
        content_types = archive.read("[Content_Types].xml").replace(
            b"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
            b"application/vnd.ms-word.document.macroEnabled.main+xml",
        )
    macro = work_dir / "macro.docx"
    _rewrite_package(source, macro, {"[Content_Types].xml": content_types})
    with pytest.raises(DocxImportError, match="Macro-enabled"):
        ManualLoader(macro).load()


def test_rejects_unsafe_xml_declarations_and_internal_relationship_traversal(
    work_dir: Path,
) -> None:
    source = work_dir / "manual.docx"
    _create_manual(source)
    with zipfile.ZipFile(source) as archive:
        document_xml = archive.read("word/document.xml")
        root_rels = archive.read("_rels/.rels")
    document_text = document_xml.decode("utf-8")
    xml_declaration, document_content = document_text.split("?>", maxsplit=1)
    utf16_document = (
        f"{xml_declaration}?>\n"
        "<!DOCTYPE w:document [<!ENTITY x SYSTEM 'file:///secret'>]>"
        f"{document_content}"
    ).encode("utf-16")
    unsafe_xml = work_dir / "unsafe-xml.docx"
    _rewrite_package(
        source,
        unsafe_xml,
        {
            "word/document.xml": b"<!DOCTYPE document [<!ENTITY x SYSTEM 'file:///secret'>]>"
            + document_xml
        },
    )
    encoded_unsafe_xml = work_dir / "encoded-unsafe-xml.docx"
    _rewrite_package(
        source,
        encoded_unsafe_xml,
        {"word/document.xml": utf16_document},
    )
    traversal = work_dir / "relationship-traversal.docx"
    altered_rels = root_rels.replace(
        b'Target="word/document.xml"',
        b'Target="../../outside.xml"',
    )
    _rewrite_package(source, traversal, {"_rels/.rels": altered_rels})

    with pytest.raises(DocxImportError, match="XML declarations"):
        ManualLoader(unsafe_xml).load()
    with pytest.raises(DocxImportError, match="document types"):
        ManualLoader(encoded_unsafe_xml).load()
    with pytest.raises(DocxImportError, match="escapes the package"):
        ManualLoader(traversal).load()


def test_file_not_found_behavior_is_preserved(work_dir: Path) -> None:
    with pytest.raises(FileNotFoundError, match="Файл не найден"):
        ManualLoader(work_dir / "missing.docx").load()
