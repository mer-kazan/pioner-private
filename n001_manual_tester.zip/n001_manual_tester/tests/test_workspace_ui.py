from __future__ import annotations

from collections.abc import Iterator

import pytest
from docx import Document
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication, QFileDialog, QInputDialog, QMessageBox

from manual_test_platform.app.i18n import LanguageManager
from manual_test_platform.app.ui.main_window import MainWindow
from manual_test_platform.storage.sqlite_workspace import CURRENT_SCHEMA_VERSION, WorkspaceStorage


@pytest.fixture
def main_window(tmp_path, monkeypatch: pytest.MonkeyPatch) -> Iterator[MainWindow]:
    monkeypatch.setenv("QT_QPA_PLATFORM", "offscreen")
    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat, QSettings.Scope.UserScope, str(tmp_path))
    application = QApplication.instance()
    if not isinstance(application, QApplication):
        application = QApplication([])
    application.setOrganizationName("ManualTestPlatformUITests")
    application.setApplicationName("ManualTestPlatformUITests")
    settings = QSettings()
    settings.clear()
    settings.setValue("ui_language", "en")
    settings.sync()
    window = MainWindow(LanguageManager(application))
    yield window
    window._language_manager.set_language("en")
    window.close()
    application.processEvents()


def _create_manual(path) -> None:
    document = Document()
    document.add_heading("Manual title", level=1)
    document.add_paragraph("Instruction")
    document.save(str(path))


def test_create_workspace_initializes_storage(
    main_window: MainWindow,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        QFileDialog,
        "getExistingDirectory",
        lambda *args, **kwargs: str(tmp_path),
    )
    monkeypatch.setattr(
        QInputDialog,
        "getText",
        lambda *args, **kwargs: ("N001 workspace", True),
    )

    storage = main_window._create_workspace()

    assert storage is not None
    assert storage.workspace_path == (tmp_path / "N001 workspace").resolve()
    assert storage.database_path.is_file()
    assert storage.schema_version == CURRENT_SCHEMA_VERSION


def test_create_workspace_rejects_invalid_windows_folder_name(
    main_window: MainWindow,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        QFileDialog,
        "getExistingDirectory",
        lambda *args, **kwargs: str(tmp_path),
    )
    monkeypatch.setattr(
        QInputDialog,
        "getText",
        lambda *args, **kwargs: ("manual:workspace", True),
    )
    warnings: list[str] = []
    monkeypatch.setattr(
        QMessageBox,
        "warning",
        lambda parent, title, message: warnings.append(title),
    )

    storage = main_window._create_workspace()

    assert storage is None
    assert warnings == [main_window.tr("Invalid workspace name")]
    assert not (tmp_path / "manual:workspace").exists()


def test_open_workspace_initializes_existing_database(
    main_window: MainWindow,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace_path = tmp_path / "existing"
    workspace_path.mkdir()
    expected_id = WorkspaceStorage(workspace_path).initialize()
    monkeypatch.setattr(
        QFileDialog,
        "getExistingDirectory",
        lambda *args, **kwargs: str(workspace_path),
    )

    storage = main_window._open_workspace()

    assert storage is not None
    assert storage.workspace_id == expected_id


def test_import_action_persists_docx_and_updates_preview(
    main_window: MainWindow,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = WorkspaceStorage(tmp_path / "workspace")
    workspace.initialize()
    main_window.set_workspace(workspace)
    source_path = tmp_path / "manual.docx"
    _create_manual(source_path)
    monkeypatch.setattr(
        QFileDialog,
        "getOpenFileName",
        lambda *args, **kwargs: (str(source_path), "Word documents (*.docx)"),
    )

    main_window.import_docx_action.trigger()

    assert "Imported document: manual.docx" in main_window.preview.toPlainText()
    assert "Manual title" in main_window.preview.toPlainText()
    main_window._language_manager.set_language("ru")
    application = QApplication.instance()
    assert application is not None
    application.processEvents()
    assert "Рабочая область:" in main_window.preview.toPlainText()
    assert "Manual title" in main_window.preview.toPlainText()
    assert main_window._last_import is not None
    original_import_id = str(main_window._last_import.manual_import.id)
    main_window.recheck_import_action.trigger()
    connection = workspace.connect()
    try:
        imports = connection.execute(
            "SELECT id, recheck_of_import_id FROM manual_imports ORDER BY created_at"
        ).fetchall()
    finally:
        connection.close()
    assert len(imports) == 2
    assert imports[1]["recheck_of_import_id"] == original_import_id


def test_import_failure_is_reported_in_ui(
    main_window: MainWindow,
    tmp_path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    workspace = WorkspaceStorage(tmp_path / "workspace")
    workspace.initialize()
    main_window.set_workspace(workspace)
    invalid_path = tmp_path / "invalid.docx"
    invalid_path.write_bytes(b"not a DOCX")
    reported: list[tuple[str, str]] = []
    monkeypatch.setattr(
        QFileDialog,
        "getOpenFileName",
        lambda *args, **kwargs: (str(invalid_path), "Word documents (*.docx)"),
    )
    monkeypatch.setattr(
        QMessageBox,
        "critical",
        lambda parent, title, message: reported.append((title, message)),
    )

    main_window.import_docx_action.trigger()

    assert reported and reported[0][0] == main_window.tr("DOCX import failed")
    connection = workspace.connect()
    try:
        assert (
            connection.execute(
                "SELECT COUNT(*) FROM manual_imports WHERE status = 'FAILED'"
            ).fetchone()[0]
            == 1
        )
    finally:
        connection.close()
