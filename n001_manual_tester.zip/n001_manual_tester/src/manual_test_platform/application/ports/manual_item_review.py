"""Storage boundary for review cycles of normalized manual items."""

from __future__ import annotations

from typing import Protocol
from uuid import UUID

from manual_test_platform.manual_model.contracts import ItemReviewCycle, ManualItem


class ManualItemReviewStore(Protocol):
    """Load an indexed item and atomically append its review-cycle history."""

    def get_item(self, item_id: UUID) -> ManualItem: ...

    def get_cycle(self, cycle_id: UUID) -> ItemReviewCycle: ...

    def save_cycle(self, cycle: ItemReviewCycle) -> ItemReviewCycle: ...


class ManualItemReviewPortError(Exception):
    """Base error raised by an item-review storage adapter."""


class ManualItemReviewPersistenceError(ManualItemReviewPortError):
    """The cycle cannot be saved as an append-only item-review history."""


__all__ = [
    "ManualItemReviewPersistenceError",
    "ManualItemReviewPortError",
    "ManualItemReviewStore",
]
