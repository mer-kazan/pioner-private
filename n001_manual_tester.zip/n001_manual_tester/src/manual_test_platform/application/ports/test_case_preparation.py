"""Storage boundary for immutable test-case preparation histories."""

from __future__ import annotations

from typing import Protocol
from uuid import UUID

from manual_test_platform.manual_model.contracts import TestCaseReviewHistory


class TestCasePreparationStore(Protocol):
    """Load and append preparation events for a test-case revision."""

    def get_history(self, revision_id: UUID) -> TestCaseReviewHistory: ...

    def save_history(self, history: TestCaseReviewHistory) -> TestCaseReviewHistory: ...


class TestCasePreparationPortError(Exception):
    """Base error raised by a test-case preparation storage adapter."""


class TestCasePreparationPersistenceError(TestCasePreparationPortError):
    """The history cannot be persisted as an append-only record."""


__all__ = [
    "TestCasePreparationPersistenceError",
    "TestCasePreparationPortError",
    "TestCasePreparationStore",
]
