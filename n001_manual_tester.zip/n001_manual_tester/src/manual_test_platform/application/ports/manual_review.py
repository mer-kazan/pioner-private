"""Storage boundaries required by the manual-review use case."""

from __future__ import annotations

from typing import Protocol
from uuid import UUID

from manual_test_platform.manual_model.contracts import (
    TestCase,
    TestCaseReviewHistory,
    TestCaseRevision,
)
from manual_test_platform.manual_model.ports import ManualStepHandoff, OperatorObservation


class TestCaseReviewStore(Protocol):
    """Read the current identity and preparation history of a test case."""

    def get_history(self, revision_id: UUID) -> TestCaseReviewHistory: ...

    def get_case(self, test_case_id: UUID) -> TestCase: ...


class ManualReviewStore(Protocol):
    """Persist exact manual handoffs and explicit operator observations."""

    def save_handoff(
        self,
        handoff: ManualStepHandoff,
        revision: TestCaseRevision,
    ) -> ManualStepHandoff: ...

    def save_observation(self, observation: OperatorObservation) -> OperatorObservation: ...


class ManualReviewPortError(Exception):
    """Base for storage rejections that the manual-review service translates."""


class ManualReviewRevisionError(ManualReviewPortError):
    """The requested revision cannot accept the handoff."""


class ManualReviewStepMismatchError(ManualReviewPortError):
    """The submitted step or its sources differ from the persisted snapshot."""


class ManualReviewPersistenceError(ManualReviewPortError):
    """A required manual-review record could not be persisted."""


__all__ = [
    "ManualReviewPersistenceError",
    "ManualReviewPortError",
    "ManualReviewRevisionError",
    "ManualReviewStepMismatchError",
    "ManualReviewStore",
    "TestCaseReviewStore",
]
