UNKNOWN = "UNKNOWN"
PASS = "PASS"
FAIL = "FAIL"
BLOCKED = "BLOCKED"
WARNING = "WARNING"

DANGEROUS_COMMANDS = {
    "delete",
    "clear",
    "reset",
    "reload",
    "reboot",
    "format",
    "erase",
    "remove",
    "install",
    "upgrade",
}

SAFE_MODE_PREFIXES = {
    "configure terminal",
    "interface",
    "router",
    "vrf",
}

MANUAL_UNKNOWN = "НЕ УКАЗАНО В МАНУАЛЕ"
