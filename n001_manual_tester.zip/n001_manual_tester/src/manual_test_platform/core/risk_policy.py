"""Fail-closed policy for determining whether a step may reach an execution adapter."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from manual_test_platform.manual_model.contracts import (
    CommandVerificationStatus,
    ExecutionMode,
    ExpectedResultStatus,
    RiskLevel,
    StepReadiness,
    TestStep,
)


class PolicyDecisionCode(StrEnum):
    """Stable reason code for an adapter-execution policy decision."""

    ALLOWED = "ALLOWED"
    STEP_NOT_READY = "STEP_NOT_READY"
    MANUAL_ONLY = "MANUAL_ONLY"
    RISK_NOT_READ_ONLY = "RISK_NOT_READ_ONLY"
    COMMAND_MISSING = "COMMAND_MISSING"
    COMMAND_UNVERIFIED = "COMMAND_UNVERIFIED"
    COMMAND_PARAMETERS_UNRESOLVED = "COMMAND_PARAMETERS_UNRESOLVED"
    SOURCE_MISSING = "SOURCE_MISSING"
    EXPECTED_RESULT_UNDOCUMENTED = "EXPECTED_RESULT_UNDOCUMENTED"
    EXPECTED_RESULT_NOT_OBSERVABLE = "EXPECTED_RESULT_NOT_OBSERVABLE"


@dataclass(frozen=True, slots=True)
class PolicyDecision:
    """A versioned, auditable outcome; only ALLOWED may reach an adapter."""

    policy_version: str
    code: PolicyDecisionCode

    @property
    def allowed(self) -> bool:
        return self.code is PolicyDecisionCode.ALLOWED


class AdapterRiskPolicy:
    """MVP policy: permit only source-grounded, verified read-only adapter steps."""

    version = "adapter-risk-policy-v1"

    def evaluate(self, step: TestStep) -> PolicyDecision:
        """Return a deny-by-default decision without executing or changing the step."""
        code = self._decision_code(step)
        return PolicyDecision(policy_version=self.version, code=code)

    @staticmethod
    def _decision_code(step: TestStep) -> PolicyDecisionCode:
        if step.readiness is not StepReadiness.READY:
            return PolicyDecisionCode.STEP_NOT_READY
        if step.execution_mode is not ExecutionMode.ADAPTER:
            return PolicyDecisionCode.MANUAL_ONLY
        if step.risk is not RiskLevel.READ_ONLY:
            return PolicyDecisionCode.RISK_NOT_READ_ONLY
        if step.command is None:
            return PolicyDecisionCode.COMMAND_MISSING
        if step.command.verification_status is not CommandVerificationStatus.VERIFIED:
            return PolicyDecisionCode.COMMAND_UNVERIFIED
        if step.command.unresolved_parameters:
            return PolicyDecisionCode.COMMAND_PARAMETERS_UNRESOLVED
        if not step.source_ref_ids or not step.command.source_ref_ids:
            return PolicyDecisionCode.SOURCE_MISSING
        if step.expected_result.status is not ExpectedResultStatus.DOCUMENTED:
            return PolicyDecisionCode.EXPECTED_RESULT_UNDOCUMENTED
        if not step.expected_result.source_ref_ids:
            return PolicyDecisionCode.SOURCE_MISSING
        if not step.expected_result.observable_checks:
            return PolicyDecisionCode.EXPECTED_RESULT_NOT_OBSERVABLE
        return PolicyDecisionCode.ALLOWED


__all__ = ["AdapterRiskPolicy", "PolicyDecision", "PolicyDecisionCode"]
