"""SQLite initialization and migration support for isolated workspaces."""

from __future__ import annotations

import sqlite3
import uuid
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

CURRENT_SCHEMA_VERSION = 5
WORKSPACE_DATABASE_NAME = "workspace.sqlite3"


class WorkspaceStorageError(RuntimeError):
    """Base error raised by workspace storage."""


class UnsupportedSchemaError(WorkspaceStorageError):
    """Raised when a workspace database is unknown or newer than this app supports."""


class MigrationError(WorkspaceStorageError):
    """Raised when a workspace migration cannot be completed."""


MigrationCallback = Callable[[sqlite3.Connection, str], None]


@dataclass(frozen=True)
class Migration:
    """One sequential schema migration."""

    version: int
    apply: MigrationCallback


def _create_workspace_metadata(connection: sqlite3.Connection, workspace_id: str) -> None:
    now = _utc_timestamp()
    connection.execute(
        """
        CREATE TABLE workspace_meta (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            workspace_id TEXT NOT NULL UNIQUE,
            schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    connection.execute(
        """
        INSERT INTO workspace_meta (
            id, workspace_id, schema_version, created_at, updated_at
        ) VALUES (1, ?, 1, ?, ?)
        """,
        (workspace_id, now, now),
    )


MIGRATIONS: tuple[Migration, ...] = (Migration(version=1, apply=_create_workspace_metadata),)


def _create_manual_import_schema(connection: sqlite3.Connection, workspace_id: str) -> None:
    del workspace_id
    connection.execute(
        """
        CREATE TABLE source_revisions (
            id TEXT PRIMARY KEY,
            format TEXT NOT NULL CHECK (format = 'docx'),
            original_name TEXT NOT NULL,
            relative_path TEXT NOT NULL UNIQUE,
            sha256 TEXT NOT NULL CHECK (
                length(sha256) = 64
                AND sha256 NOT GLOB '*[^0-9a-f]*'
            ),
            imported_at TEXT NOT NULL,
            UNIQUE (format, sha256)
        );
        """
    )

    connection.execute(
        """
        CREATE TABLE manual_imports (
            id TEXT PRIMARY KEY,
            source_revision_id TEXT REFERENCES source_revisions(id) ON DELETE RESTRICT,
            recheck_of_import_id TEXT REFERENCES manual_imports(id) ON DELETE RESTRICT,
            created_at TEXT NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('IMPORTED', 'FAILED')),
            error_code TEXT,
            error_message TEXT,
            CHECK (
                (status = 'IMPORTED' AND source_revision_id IS NOT NULL
                    AND error_code IS NULL AND error_message IS NULL)
                OR (status = 'FAILED' AND error_code IS NOT NULL
                    AND error_message IS NOT NULL)
            )
        );
        """
    )

    connection.execute(
        """
        CREATE TABLE manual_indexes (
            id TEXT PRIMARY KEY,
            manual_import_id TEXT NOT NULL UNIQUE REFERENCES manual_imports(id)
                ON DELETE RESTRICT,
            schema_version INTEGER NOT NULL CHECK (schema_version >= 1),
            current_compiled_version_id TEXT
        );
        """
    )

    connection.execute(
        """
        CREATE TABLE manual_items (
            id TEXT PRIMARY KEY,
            manual_index_id TEXT NOT NULL REFERENCES manual_indexes(id)
                ON DELETE RESTRICT,
            parent_item_id TEXT,
            position INTEGER NOT NULL CHECK (position >= 0),
            heading TEXT,
            heading_level INTEGER CHECK (heading_level BETWEEN 1 AND 9),
            content_path TEXT NOT NULL UNIQUE,
            content_format_version INTEGER NOT NULL DEFAULT 1
                CHECK (content_format_version >= 1),
            content_sha256 TEXT NOT NULL CHECK (
                length(content_sha256) = 64
                AND content_sha256 NOT GLOB '*[^0-9a-f]*'
            ),
            quality_flags_json TEXT NOT NULL CHECK (json_valid(quality_flags_json)),
            review_cycle_id TEXT,
            UNIQUE (id, manual_index_id),
            FOREIGN KEY (parent_item_id, manual_index_id)
                REFERENCES manual_items(id, manual_index_id) ON DELETE RESTRICT
        );
        """
    )

    connection.execute(
        """
        CREATE UNIQUE INDEX manual_items_root_order
            ON manual_items(manual_index_id, position)
            WHERE parent_item_id IS NULL;
        """
    )
    connection.execute(
        """
        CREATE UNIQUE INDEX manual_items_sibling_order
            ON manual_items(manual_index_id, parent_item_id, position)
            WHERE parent_item_id IS NOT NULL;
        """
    )

    connection.execute(
        """
        CREATE TABLE source_refs (
            id TEXT PRIMARY KEY,
            source_revision_id TEXT NOT NULL REFERENCES source_revisions(id)
                ON DELETE RESTRICT,
            part_uri TEXT NOT NULL,
            xpath TEXT NOT NULL,
            block_index INTEGER CHECK (block_index >= 0),
            paragraph_index INTEGER CHECK (paragraph_index >= 0),
            table_index INTEGER CHECK (table_index >= 0),
            row_index INTEGER CHECK (row_index >= 0),
            cell_index INTEGER CHECK (cell_index >= 0),
            quoted_text TEXT,
            quoted_text_sha256 TEXT,
            CHECK ((quoted_text IS NULL) = (quoted_text_sha256 IS NULL))
        );
        """
    )

    connection.execute(
        """
        CREATE TABLE item_content_source_refs (
            manual_item_id TEXT NOT NULL REFERENCES manual_items(id) ON DELETE RESTRICT,
            content_pointer TEXT NOT NULL,
            source_ref_id TEXT NOT NULL REFERENCES source_refs(id) ON DELETE RESTRICT,
            PRIMARY KEY (manual_item_id, content_pointer)
        );
        """
    )

    connection.execute(
        """
        CREATE INDEX manual_imports_source_revision
            ON manual_imports(source_revision_id, created_at);
        """
    )
    connection.execute(
        """
        CREATE INDEX manual_imports_recheck
            ON manual_imports(recheck_of_import_id);
        """
    )
    connection.execute(
        """
        CREATE INDEX manual_items_parent_order
            ON manual_items(manual_index_id, parent_item_id, position);
        """
    )
    connection.execute(
        """
        CREATE INDEX source_refs_revision
            ON source_refs(source_revision_id);
        """
    )


MIGRATIONS = (*MIGRATIONS, Migration(version=2, apply=_create_manual_import_schema))


def _create_test_case_schema(connection: sqlite3.Connection, workspace_id: str) -> None:
    del workspace_id
    connection.execute(
        "CREATE UNIQUE INDEX manual_imports_id_source_revision "
        "ON manual_imports(id, source_revision_id)"
    )
    connection.execute(
        """
        CREATE UNIQUE INDEX source_refs_id_revision
            ON source_refs(id, source_revision_id)
        """
    )
    connection.execute(
        """
        CREATE TABLE test_cases (
            id TEXT PRIMARY KEY,
            manual_import_id TEXT NOT NULL REFERENCES manual_imports(id)
                ON DELETE RESTRICT,
            current_revision_id TEXT,
            UNIQUE (id, manual_import_id),
            FOREIGN KEY (current_revision_id, id)
                REFERENCES test_case_revisions(id, test_case_id)
                DEFERRABLE INITIALLY DEFERRED
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_case_revisions (
            id TEXT PRIMARY KEY,
            test_case_id TEXT NOT NULL,
            revision_number INTEGER NOT NULL CHECK (revision_number >= 1),
            manual_import_id TEXT NOT NULL,
            source_revision_id TEXT NOT NULL,
            profile_json TEXT NOT NULL CHECK (json_valid(profile_json)),
            title TEXT NOT NULL CHECK (length(title) > 0),
            UNIQUE (test_case_id, revision_number),
            UNIQUE (id, test_case_id),
            UNIQUE (id, source_revision_id),
            FOREIGN KEY (test_case_id, manual_import_id)
                REFERENCES test_cases(id, manual_import_id) ON DELETE RESTRICT,
            FOREIGN KEY (manual_import_id, source_revision_id)
                REFERENCES manual_imports(id, source_revision_id) ON DELETE RESTRICT
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_revision_source_refs (
            revision_id TEXT NOT NULL,
            source_revision_id TEXT NOT NULL,
            source_ref_id TEXT NOT NULL,
            position INTEGER NOT NULL CHECK (position >= 0),
            PRIMARY KEY (revision_id, source_ref_id),
            UNIQUE (revision_id, position),
            FOREIGN KEY (revision_id, source_revision_id)
                REFERENCES test_case_revisions(id, source_revision_id) ON DELETE RESTRICT,
            FOREIGN KEY (source_ref_id, source_revision_id)
                REFERENCES source_refs(id, source_revision_id) ON DELETE RESTRICT
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_preconditions (
            revision_id TEXT NOT NULL REFERENCES test_case_revisions(id)
                ON DELETE RESTRICT,
            position INTEGER NOT NULL CHECK (position >= 0),
            text TEXT NOT NULL CHECK (length(text) > 0),
            PRIMARY KEY (revision_id, position)
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_precondition_source_refs (
            revision_id TEXT NOT NULL,
            precondition_position INTEGER NOT NULL,
            source_revision_id TEXT NOT NULL,
            source_ref_id TEXT NOT NULL,
            position INTEGER NOT NULL CHECK (position >= 0),
            PRIMARY KEY (revision_id, precondition_position, position),
            FOREIGN KEY (revision_id, precondition_position)
                REFERENCES test_preconditions(revision_id, position) ON DELETE RESTRICT,
            FOREIGN KEY (revision_id, source_revision_id)
                REFERENCES test_case_revisions(id, source_revision_id) ON DELETE RESTRICT,
            FOREIGN KEY (source_ref_id, source_revision_id)
                REFERENCES source_refs(id, source_revision_id) ON DELETE RESTRICT
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_steps (
            revision_id TEXT NOT NULL REFERENCES test_case_revisions(id)
                ON DELETE RESTRICT,
            step_id TEXT NOT NULL,
            position INTEGER NOT NULL CHECK (position >= 0),
            content_json TEXT NOT NULL CHECK (json_valid(content_json)),
            PRIMARY KEY (revision_id, step_id),
            UNIQUE (revision_id, position)
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_step_source_refs (
            revision_id TEXT NOT NULL,
            step_id TEXT NOT NULL,
            purpose TEXT NOT NULL CHECK (
                purpose IN ('INSTRUCTION', 'COMMAND', 'EXPECTED_RESULT')
            ),
            position INTEGER NOT NULL CHECK (position >= 0),
            source_revision_id TEXT NOT NULL,
            source_ref_id TEXT NOT NULL,
            PRIMARY KEY (revision_id, step_id, purpose, position),
            FOREIGN KEY (revision_id, step_id)
                REFERENCES test_steps(revision_id, step_id) ON DELETE RESTRICT,
            FOREIGN KEY (revision_id, source_revision_id)
                REFERENCES test_case_revisions(id, source_revision_id) ON DELETE RESTRICT,
            FOREIGN KEY (source_ref_id, source_revision_id)
                REFERENCES source_refs(id, source_revision_id) ON DELETE RESTRICT
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE test_case_review_events (
            id TEXT PRIMARY KEY,
            revision_id TEXT NOT NULL REFERENCES test_case_revisions(id)
                ON DELETE RESTRICT,
            position INTEGER NOT NULL CHECK (position >= 0),
            status TEXT NOT NULL CHECK (status IN ('DRAFT', 'NEEDS_REVIEW', 'READY')),
            author_display_name TEXT NOT NULL CHECK (length(author_display_name) > 0),
            occurred_at TEXT NOT NULL,
            UNIQUE (revision_id, position)
        )
        """
    )

    append_only_tables = (
        "test_case_revisions",
        "test_revision_source_refs",
        "test_preconditions",
        "test_precondition_source_refs",
        "test_steps",
        "test_step_source_refs",
        "test_case_review_events",
    )
    for table in append_only_tables:
        for operation in ("UPDATE", "DELETE"):
            trigger = f"{table}_no_{operation.lower()}"
            connection.execute(
                f"""
                CREATE TRIGGER {trigger}
                BEFORE {operation} ON {table}
                BEGIN
                    SELECT RAISE(ABORT, '{table} is append-only');
                END
                """
            )
    connection.execute(
        """
        CREATE TRIGGER test_cases_identity_immutable
        BEFORE UPDATE OF id, manual_import_id ON test_cases
        BEGIN
            SELECT RAISE(ABORT, 'test case identity is immutable');
        END
        """
    )


MIGRATIONS = (*MIGRATIONS, Migration(version=3, apply=_create_test_case_schema))


def _create_manual_review_schema(connection: sqlite3.Connection, workspace_id: str) -> None:
    del workspace_id
    connection.execute(
        """
        CREATE TABLE manual_step_handoffs (
            id TEXT PRIMARY KEY,
            revision_id TEXT NOT NULL REFERENCES test_case_revisions(id)
                ON DELETE RESTRICT,
            target_id TEXT NOT NULL CHECK (length(target_id) > 0),
            snapshot_sha256 TEXT NOT NULL CHECK (
                length(snapshot_sha256) = 64
                AND snapshot_sha256 NOT GLOB '*[^0-9a-f]*'
            ),
            content_json TEXT NOT NULL CHECK (json_valid(content_json))
        )
        """
    )
    connection.execute(
        """
        CREATE TABLE operator_observations (
            handoff_id TEXT PRIMARY KEY REFERENCES manual_step_handoffs(id)
                ON DELETE RESTRICT,
            outcome TEXT NOT NULL CHECK (outcome IN ('PASS', 'FAIL', 'UNKNOWN')),
            occurred_at TEXT NOT NULL,
            author_display_name TEXT NOT NULL CHECK (length(author_display_name) > 0),
            observation TEXT NOT NULL CHECK (length(observation) > 0),
            content_json TEXT NOT NULL CHECK (json_valid(content_json))
        )
        """
    )
    for table in ("manual_step_handoffs", "operator_observations"):
        for operation in ("UPDATE", "DELETE"):
            connection.execute(
                f"""
                CREATE TRIGGER {table}_no_{operation.lower()}
                BEFORE {operation} ON {table}
                BEGIN
                    SELECT RAISE(ABORT, '{table} is append-only');
                END
                """
            )


MIGRATIONS = (*MIGRATIONS, Migration(version=4, apply=_create_manual_review_schema))


def _create_item_review_schema(connection: sqlite3.Connection, workspace_id: str) -> None:
    del workspace_id
    connection.execute(
        """
        CREATE TABLE item_review_cycles (
            id TEXT PRIMARY KEY,
            manual_item_id TEXT NOT NULL REFERENCES manual_items(id)
                ON DELETE RESTRICT,
            sequence INTEGER NOT NULL CHECK (sequence >= 1),
            UNIQUE (manual_item_id, sequence)
        );
        """
    )
    connection.execute(
        """
        CREATE TABLE item_review_events (
            id TEXT PRIMARY KEY,
            cycle_id TEXT NOT NULL REFERENCES item_review_cycles(id)
                ON DELETE RESTRICT,
            position INTEGER NOT NULL CHECK (position >= 0),
            status TEXT NOT NULL CHECK (status IN ('IN_REVIEW', 'CONFIRMED')),
            content_sha256 TEXT NOT NULL CHECK (
                length(content_sha256) = 64
                AND content_sha256 NOT GLOB '*[^0-9a-f]*'
            ),
            author_display_name TEXT NOT NULL CHECK (length(author_display_name) > 0),
            occurred_at TEXT NOT NULL,
            UNIQUE (cycle_id, position)
        );
        """
    )
    append_only_tables = (
        "item_review_cycles",
        "item_review_events",
    )
    for table in append_only_tables:
        for operation in ("UPDATE", "DELETE"):
            trigger = f"{table}_no_{operation.lower()}"
            connection.execute(
                f"""
                CREATE TRIGGER {trigger}
                BEFORE {operation} ON {table}
                BEGIN
                    SELECT RAISE(ABORT, '{table} is append-only');
                END
                """
            )


MIGRATIONS = (*MIGRATIONS, Migration(version=5, apply=_create_item_review_schema))


def _utc_timestamp() -> str:
    return datetime.now(UTC).isoformat()


def _canonical_uuid(value: str | uuid.UUID) -> str:
    try:
        return str(uuid.UUID(str(value)))
    except (ValueError, AttributeError) as exc:
        raise ValueError("workspace_id must be a valid UUID") from exc


class WorkspaceStorage:
    """Manage one SQLite database located inside one workspace directory.

    Call :meth:`initialize` before opening a connection. Every connection enables
    and verifies SQLite foreign-key enforcement.
    """

    def __init__(
        self,
        workspace_path: str | Path,
        *,
        workspace_id: str | uuid.UUID | None = None,
    ) -> None:
        self.workspace_path = Path(workspace_path).resolve()
        self.database_path = self.workspace_path / WORKSPACE_DATABASE_NAME
        self._requested_workspace_id = (
            _canonical_uuid(workspace_id) if workspace_id is not None else None
        )
        self._workspace_id: str | None = None
        self._schema_version: int | None = None

    @property
    def workspace_id(self) -> str:
        """The UUID loaded or created by :meth:`initialize`."""
        if self._workspace_id is None:
            raise WorkspaceStorageError("Workspace storage has not been initialized")
        return self._workspace_id

    @property
    def schema_version(self) -> int:
        """The current on-disk schema version."""
        if self._schema_version is None:
            raise WorkspaceStorageError("Workspace storage has not been initialized")
        return self._schema_version

    def initialize(self) -> str:
        """Create or validate the workspace database and apply pending migrations.

        Existing, unversioned, unknown, or newer databases are rejected rather
        than reset. Pending migrations are backed up first and run in one
        transaction so a failure leaves the original database unchanged.
        """
        self.workspace_path.mkdir(parents=True, exist_ok=True)
        database_existed = self.database_path.exists()
        if database_existed and self.database_path.stat().st_size == 0:
            raise UnsupportedSchemaError("Existing workspace database is empty and unversioned")

        connection = self._open_connection()
        transaction_started = False
        try:
            if database_existed:
                version = self._read_schema_version(connection)
                workspace_id = self._validate_metadata(connection, version)
                if self._requested_workspace_id is not None:
                    if workspace_id != self._requested_workspace_id:
                        raise WorkspaceStorageError(
                            "Workspace UUID does not match the requested workspace"
                        )
            else:
                version = 0
                workspace_id = self._requested_workspace_id or str(uuid.uuid4())

            migrations = self._validated_migrations()
            if version > CURRENT_SCHEMA_VERSION:
                raise UnsupportedSchemaError(
                    f"Workspace schema version {version} is newer than supported version "
                    f"{CURRENT_SCHEMA_VERSION}"
                )

            if database_existed and version == CURRENT_SCHEMA_VERSION:
                self._workspace_id = workspace_id
                self._schema_version = version
                return workspace_id

            if database_existed:
                data_version = connection.execute("PRAGMA data_version").fetchone()[0]
                self._create_backup(connection)
                self._begin_exclusive(connection)
                transaction_started = True
                locked_version = self._read_schema_version(connection)
                locked_workspace_id = self._validate_metadata(connection, locked_version)
                current_data_version = connection.execute("PRAGMA data_version").fetchone()[0]
                if (
                    locked_version != version
                    or locked_workspace_id != workspace_id
                    or current_data_version != data_version
                ):
                    raise WorkspaceStorageError(
                        "Workspace database changed while its migration backup was created; "
                        "retry initialization"
                    )
            else:
                self._begin_exclusive(connection)
                transaction_started = True
                connection.execute(
                    """
                    CREATE TABLE schema_migrations (
                        version INTEGER PRIMARY KEY CHECK (version >= 1),
                        applied_at TEXT NOT NULL
                    )
                    """
                )

            for migration in migrations:
                if version < migration.version:
                    try:
                        migration.apply(connection, workspace_id)
                        if migration.version > 1:
                            connection.execute(
                                """
                                UPDATE workspace_meta
                                SET schema_version = ?, updated_at = ?
                                WHERE id = 1
                                """,
                                (migration.version, _utc_timestamp()),
                            )
                        connection.execute(
                            "INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)",
                            (migration.version, _utc_timestamp()),
                        )
                        connection.execute(f"PRAGMA user_version = {migration.version}")
                    except Exception as exc:
                        raise MigrationError(
                            f"Workspace migration {migration.version} failed"
                        ) from exc

            self._validate_metadata(connection, CURRENT_SCHEMA_VERSION)
            if connection.execute("PRAGMA foreign_key_check").fetchone() is not None:
                raise MigrationError("Workspace database contains foreign-key violations")
            if transaction_started:
                connection.commit()
        except (MigrationError, UnsupportedSchemaError, WorkspaceStorageError):
            if transaction_started:
                connection.rollback()
            raise
        except sqlite3.Error as exc:
            if transaction_started:
                connection.rollback()
            raise WorkspaceStorageError("Could not initialize workspace database") from exc
        finally:
            connection.close()

        self._workspace_id = workspace_id
        self._schema_version = CURRENT_SCHEMA_VERSION
        return workspace_id

    def connect(self) -> sqlite3.Connection:
        """Open a connection with foreign keys enabled and verified."""
        if self._workspace_id is None:
            raise WorkspaceStorageError("Call initialize() before opening a database connection")
        connection = self._open_connection()
        try:
            version = self._read_schema_version(connection)
            found_id = self._validate_metadata(connection, version)
            if found_id != self._workspace_id:
                raise WorkspaceStorageError("Workspace database UUID changed after initialization")
            return connection
        except Exception:
            connection.close()
            raise

    def _open_connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, isolation_level=None, timeout=30)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        enabled = connection.execute("PRAGMA foreign_keys").fetchone()
        if enabled is None or enabled[0] != 1:
            connection.close()
            raise WorkspaceStorageError("SQLite foreign-key enforcement could not be enabled")
        return connection

    @staticmethod
    def _begin_exclusive(connection: sqlite3.Connection) -> None:
        try:
            connection.execute("BEGIN EXCLUSIVE")
        except sqlite3.Error as exc:
            raise WorkspaceStorageError(
                "Could not lock workspace database for initialization"
            ) from exc

    @staticmethod
    def _read_schema_version(connection: sqlite3.Connection) -> int:
        try:
            row = connection.execute("PRAGMA user_version").fetchone()
        except sqlite3.Error as exc:
            raise UnsupportedSchemaError("Could not read workspace schema version") from exc
        if row is None:
            raise UnsupportedSchemaError("Workspace schema version is missing")
        version = int(row[0])
        if version < 1:
            raise UnsupportedSchemaError("Existing workspace database has no recognized schema")
        return version

    @staticmethod
    def _validate_metadata(connection: sqlite3.Connection, version: int) -> str:
        try:
            tables = {
                row["name"]
                for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
            }
            if not {"workspace_meta", "schema_migrations"}.issubset(tables):
                raise UnsupportedSchemaError("Workspace database is missing required metadata")

            metadata = connection.execute(
                """
                SELECT workspace_id, schema_version
                FROM workspace_meta
                WHERE id = 1
                """
            ).fetchone()
            applied = [
                row["version"]
                for row in connection.execute(
                    "SELECT version FROM schema_migrations ORDER BY version"
                )
            ]
        except sqlite3.Error as exc:
            raise UnsupportedSchemaError("Workspace metadata is unreadable") from exc

        if metadata is None:
            raise UnsupportedSchemaError("Workspace database has no workspace metadata row")
        if metadata["schema_version"] != version:
            raise UnsupportedSchemaError("Workspace schema metadata is inconsistent")
        if applied != list(range(1, version + 1)):
            raise UnsupportedSchemaError("Workspace migration history is inconsistent")
        try:
            return _canonical_uuid(metadata["workspace_id"])
        except ValueError as exc:
            raise UnsupportedSchemaError("Workspace UUID metadata is invalid") from exc

    @staticmethod
    def _validated_migrations() -> tuple[Migration, ...]:
        migrations = tuple(MIGRATIONS)
        versions = [migration.version for migration in migrations]
        if versions != list(range(1, CURRENT_SCHEMA_VERSION + 1)):
            raise UnsupportedSchemaError("Workspace migration sequence is invalid")
        return migrations

    def _create_backup(self, connection: sqlite3.Connection) -> Path:
        backup_path = self.database_path.with_name(
            f"{self.database_path.name}.backup-{uuid.uuid4().hex}"
        )
        backup_connection: sqlite3.Connection | None = None
        try:
            backup_connection = sqlite3.connect(backup_path)
            connection.backup(backup_connection)
            backup_connection.close()
            backup_connection = None
            return backup_path
        except sqlite3.Error as exc:
            if backup_connection is not None:
                backup_connection.close()
            backup_path.unlink(missing_ok=True)
            raise MigrationError("Could not back up workspace database before migration") from exc
