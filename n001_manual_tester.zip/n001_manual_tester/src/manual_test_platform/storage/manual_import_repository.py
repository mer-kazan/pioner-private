"""Persistence for source-grounded DOCX imports."""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
from contextlib import closing
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

from manual_test_platform.application.ports.manual_import import (
    ManualImportRecord,
    ManualItemRecord,
    ManualItemSourceEvidence,
)
from manual_test_platform.docx_parser import (
    DocxImportError,
    ImportedManual,
    ImportLimits,
    ManualLoader,
    ParagraphBlock,
    SourceRef,
)
from manual_test_platform.manual_model.contracts import SourceEvidence
from manual_test_platform.storage.sqlite_workspace import WorkspaceStorage, WorkspaceStorageError

_CONTENT_SCHEMA_VERSION = 1
_UNHEADED_QUALITY_FLAG = "UNHEADED_BOUNDARY_REVIEW"
_SOURCE_COPY_CHUNK_SIZE = 64 * 1024


class _SourceReadError(Exception):
    def __init__(self, original_error: OSError) -> None:
        self.original_error = original_error


@dataclass
class _ItemDraft:
    id: str
    parent_item_id: str | None
    position: int
    heading: str | None
    heading_level: int | None
    quality_flags: tuple[str, ...] = ()
    block_indexes: list[int] = field(default_factory=list)


class ManualImportRepository:
    """Store validated DOCX revisions and a fresh manual index per import."""

    def __init__(self, storage: WorkspaceStorage) -> None:
        self.storage = storage

    def import_docx(
        self,
        source_path: Path,
        *,
        recheck_of_import_id: str | None = None,
    ) -> ManualImportRecord:
        """Import one DOCX, retaining its exact original bytes and extracted content."""
        source_path = Path(source_path)
        if recheck_of_import_id is not None:
            self._require_existing_import(recheck_of_import_id)

        source_directory = self.storage.workspace_path / "source_documents"
        source_directory.mkdir(parents=True, exist_ok=True)
        try:
            staged_path, source_sha256 = self._stage_source(
                source_path,
                source_directory,
                source_path.suffix,
            )
        except _SourceReadError as error:
            self._persist_failed_import(
                recheck_of_import_id,
                "SOURCE_READ_ERROR",
                "The selected source file could not be read.",
            )
            raise error.original_error from None
        except DocxImportError:
            self._persist_failed_import(
                recheck_of_import_id,
                "DOCX_IMPORT_ERROR",
                "The selected DOCX file could not be imported.",
            )
            raise
        try:
            try:
                imported = ManualLoader(staged_path).load()
            except DocxImportError:
                self._persist_failed_import(
                    recheck_of_import_id,
                    "DOCX_IMPORT_ERROR",
                    "The selected DOCX file could not be imported.",
                )
                raise
            except OSError:
                self._persist_failed_import(
                    recheck_of_import_id,
                    "SOURCE_READ_ERROR",
                    "The selected source file could not be read.",
                )
                raise
            if imported.revision.sha256 != source_sha256:
                raise WorkspaceStorageError("Staged DOCX bytes do not match the loaded revision")

            source_target = source_directory / f"{source_sha256}.docx"
            return self._persist_import(
                imported,
                source_path.name,
                source_target,
                staged_path,
                recheck_of_import_id,
            )
        finally:
            staged_path.unlink(missing_ok=True)

    def get_import(self, import_id: str) -> ManualImportRecord:
        """Load an import and its items from this workspace."""
        with closing(self.storage.connect()) as connection:
            row = connection.execute(
                """
                SELECT
                    imports.id,
                    imports.created_at,
                    imports.status,
                    imports.source_revision_id,
                    imports.recheck_of_import_id,
                    imports.error_code,
                    imports.error_message,
                    revisions.original_name AS source_name,
                    revisions.sha256 AS source_sha256,
                    revisions.relative_path,
                    indexes.id AS manual_index_id
                FROM manual_imports AS imports
                LEFT JOIN source_revisions AS revisions
                    ON revisions.id = imports.source_revision_id
                LEFT JOIN manual_indexes AS indexes
                    ON indexes.manual_import_id = imports.id
                WHERE imports.id = ?
                """,
                (import_id,),
            ).fetchone()
            if row is None:
                raise KeyError(f"Manual import not found: {import_id}")

            items_by_parent: dict[str | None, list[ManualItemRecord]] = {}
            if row["manual_index_id"] is not None:
                source_refs_by_item: dict[str, list[ManualItemSourceEvidence]] = {}
                source_ref_rows = connection.execute(
                    """
                    SELECT
                        items.id AS manual_item_id,
                        item_refs.content_pointer,
                        source_refs.id,
                        source_refs.source_revision_id,
                        source_refs.part_uri,
                        source_refs.xpath,
                        source_refs.block_index,
                        source_refs.paragraph_index,
                        source_refs.table_index,
                        source_refs.row_index,
                        source_refs.cell_index,
                        source_refs.quoted_text,
                        source_refs.quoted_text_sha256
                    FROM manual_items AS items
                    JOIN item_content_source_refs AS item_refs
                        ON item_refs.manual_item_id = items.id
                    JOIN source_refs ON source_refs.id = item_refs.source_ref_id
                    WHERE items.manual_index_id = ?
                    ORDER BY items.position, items.id, item_refs.content_pointer, source_refs.id
                    """,
                    (row["manual_index_id"],),
                ).fetchall()
                for source_ref_row in source_ref_rows:
                    source_ref = ManualItemSourceEvidence(
                        content_pointer=source_ref_row["content_pointer"],
                        evidence=SourceEvidence(
                            id=source_ref_row["id"],
                            source_revision_id=source_ref_row["source_revision_id"],
                            part_uri=source_ref_row["part_uri"],
                            xpath=source_ref_row["xpath"],
                            block_index=source_ref_row["block_index"],
                            paragraph_index=source_ref_row["paragraph_index"],
                            table_index=source_ref_row["table_index"],
                            row_index=source_ref_row["row_index"],
                            cell_index=source_ref_row["cell_index"],
                            quoted_text=source_ref_row["quoted_text"],
                            quoted_text_sha256=source_ref_row["quoted_text_sha256"],
                        ),
                    )
                    source_refs_by_item.setdefault(source_ref_row["manual_item_id"], []).append(
                        source_ref
                    )

                item_rows = connection.execute(
                    """
                    SELECT
                        id, parent_item_id, position, heading, heading_level,
                        content_path, content_sha256, quality_flags_json
                    FROM manual_items
                    WHERE manual_index_id = ?
                    ORDER BY position
                    """,
                    (row["manual_index_id"],),
                ).fetchall()
                for item_row in item_rows:
                    quality_flags = json.loads(item_row["quality_flags_json"])
                    item = ManualItemRecord(
                        id=item_row["id"],
                        parent_item_id=item_row["parent_item_id"],
                        position=item_row["position"],
                        heading=item_row["heading"],
                        heading_level=item_row["heading_level"],
                        content_path=item_row["content_path"],
                        content_sha256=item_row["content_sha256"],
                        quality_flags=tuple(quality_flags),
                        source_refs=tuple(source_refs_by_item.get(item_row["id"], ())),
                    )
                    items_by_parent.setdefault(item.parent_item_id, []).append(item)

        items = _tree_order_items(items_by_parent)
        stored_source_path = (
            self._workspace_file(row["relative_path"]) if row["relative_path"] is not None else None
        )
        if row["status"] == "IMPORTED":
            if stored_source_path is None or row["source_sha256"] is None:
                raise WorkspaceStorageError("Imported record is missing its original source")
            try:
                stored_source_sha256 = _sha256_file(stored_source_path)
            except OSError as exc:
                raise WorkspaceStorageError(
                    "Stored original source is missing or cannot be read"
                ) from exc
            if stored_source_sha256 != row["source_sha256"]:
                raise WorkspaceStorageError("Stored original source integrity check failed")
        return ManualImportRecord(
            id=row["id"],
            created_at=datetime.fromisoformat(row["created_at"]),
            status=row["status"],
            source_revision_id=row["source_revision_id"],
            manual_index_id=row["manual_index_id"],
            recheck_of_import_id=row["recheck_of_import_id"],
            source_name=row["source_name"],
            source_sha256=row["source_sha256"],
            source_path=stored_source_path,
            items=tuple(items),
            error_code=row["error_code"],
            error_message=row["error_message"],
        )

    def get_latest_import(self) -> ManualImportRecord | None:
        """Return the most recent successful import, if this workspace has one."""
        with closing(self.storage.connect()) as connection:
            row = connection.execute(
                """
                SELECT id
                FROM manual_imports
                WHERE status = 'IMPORTED'
                ORDER BY created_at DESC, rowid DESC
                LIMIT 1
                """
            ).fetchone()
        return self.get_import(row["id"]) if row is not None else None

    def _require_existing_import(self, import_id: str) -> None:
        with closing(self.storage.connect()) as connection:
            row = connection.execute(
                "SELECT 1 FROM manual_imports WHERE id = ?",
                (import_id,),
            ).fetchone()
        if row is None:
            raise ValueError("Recheck import must reference an import in this workspace")

    def _persist_failed_import(
        self,
        recheck_of_import_id: str | None,
        error_code: str,
        error_message: str,
    ) -> None:
        import_id = str(uuid4())
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """
                INSERT INTO manual_imports (
                    id, source_revision_id, recheck_of_import_id, created_at,
                    status, error_code, error_message
                ) VALUES (?, NULL, ?, ?, 'FAILED', ?, ?)
                """,
                (
                    import_id,
                    recheck_of_import_id,
                    _utc_timestamp(),
                    error_code,
                    error_message,
                ),
            )
            connection.commit()
        finally:
            if connection.in_transaction:
                connection.rollback()
            connection.close()

    def _persist_import(
        self,
        imported: ImportedManual,
        original_name: str,
        source_target: Path,
        staged_source_path: Path,
        recheck_of_import_id: str | None,
    ) -> ManualImportRecord:
        source_revision_id = str(imported.revision.id)
        source_sha256 = imported.revision.sha256
        relative_source_path = source_target.relative_to(self.storage.workspace_path).as_posix()
        manual_import_id = str(uuid4())
        manual_index_id = str(uuid4())
        drafts = _make_item_drafts(imported)

        prepared_items: list[tuple[_ItemDraft, str, str, bytes, list[tuple[str, SourceRef]]]] = []
        for draft in drafts:
            content, source_locations = _item_content(imported, draft.block_indexes)
            content_bytes = json.dumps(
                content,
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            ).encode("utf-8")
            content_path = (
                Path("manual_content") / manual_index_id / f"{draft.id}.json"
            ).as_posix()
            content_sha256 = hashlib.sha256(content_bytes).hexdigest()
            prepared_items.append(
                (draft, content_path, content_sha256, content_bytes, source_locations)
            )

        written_paths: list[Path] = []
        created_source_path: Path | None = None
        committed = False
        try:
            for _, content_path, _, content_bytes, _ in prepared_items:
                absolute_path = self._workspace_file(content_path)
                _write_atomic(absolute_path, content_bytes)
                written_paths.append(absolute_path)

            connection = self.storage.connect()
            try:
                connection.execute("BEGIN IMMEDIATE")
                existing_revision = connection.execute(
                    """
                    SELECT id, relative_path
                    FROM source_revisions
                    WHERE format = 'docx' AND sha256 = ?
                    """,
                    (source_sha256,),
                ).fetchone()
                if existing_revision is None:
                    created_source_path = _ensure_source_copy(
                        source_target,
                        staged_source_path,
                        source_sha256,
                    )
                    connection.execute(
                        """
                        INSERT INTO source_revisions (
                            id, format, original_name, relative_path, sha256, imported_at
                        ) VALUES (?, 'docx', ?, ?, ?, ?)
                        """,
                        (
                            source_revision_id,
                            original_name,
                            relative_source_path,
                            source_sha256,
                            imported.revision.imported_at.isoformat(),
                        ),
                    )
                else:
                    source_revision_id = existing_revision["id"]
                    relative_source_path = existing_revision["relative_path"]
                    stored_source = self._workspace_file(relative_source_path)
                    _ensure_existing_source(stored_source, source_sha256)

                connection.execute(
                    """
                    INSERT INTO manual_imports (
                        id, source_revision_id, recheck_of_import_id, created_at,
                        status, error_code, error_message
                    ) VALUES (?, ?, ?, ?, 'IMPORTED', NULL, NULL)
                    """,
                    (
                        manual_import_id,
                        source_revision_id,
                        recheck_of_import_id,
                        _utc_timestamp(),
                    ),
                )
                connection.execute(
                    """
                    INSERT INTO manual_indexes (
                        id, manual_import_id, schema_version, current_compiled_version_id
                    ) VALUES (?, ?, ?, NULL)
                    """,
                    (manual_index_id, manual_import_id, self.storage.schema_version),
                )

                for draft, content_path, content_sha256, _, source_locations in prepared_items:
                    connection.execute(
                        """
                        INSERT INTO manual_items (
                            id, manual_index_id, parent_item_id, position, heading,
                            heading_level, content_path, content_sha256,
                            quality_flags_json, review_cycle_id
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
                        """,
                        (
                            draft.id,
                            manual_index_id,
                            draft.parent_item_id,
                            draft.position,
                            draft.heading,
                            draft.heading_level,
                            content_path,
                            content_sha256,
                            json.dumps(draft.quality_flags, separators=(",", ":")),
                        ),
                    )
                    for content_pointer, source_ref in source_locations:
                        source_ref_id = str(uuid4())
                        connection.execute(
                            """
                            INSERT INTO source_refs (
                                id, source_revision_id, part_uri, xpath, block_index,
                                paragraph_index, table_index, row_index, cell_index,
                                quoted_text, quoted_text_sha256
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                            """,
                            (
                                source_ref_id,
                                source_revision_id,
                                source_ref.part_uri,
                                source_ref.xpath,
                                source_ref.block_index,
                                source_ref.paragraph_index,
                                source_ref.table_index,
                                source_ref.row_index,
                                source_ref.cell_index,
                                source_ref.quoted_text,
                                source_ref.quoted_text_sha256,
                            ),
                        )
                        connection.execute(
                            """
                            INSERT INTO item_content_source_refs (
                                manual_item_id, content_pointer, source_ref_id
                            ) VALUES (?, ?, ?)
                            """,
                            (draft.id, content_pointer, source_ref_id),
                        )

                connection.commit()
                committed = True
            finally:
                if connection.in_transaction:
                    connection.rollback()
                connection.close()
        finally:
            if not committed:
                for written_path in written_paths:
                    written_path.unlink(missing_ok=True)
                if created_source_path is not None and not self._source_path_is_registered(
                    created_source_path,
                ):
                    created_source_path.unlink(missing_ok=True)

        return self.get_import(manual_import_id)

    def _stage_source(
        self,
        source_path: Path,
        directory: Path,
        suffix: str,
    ) -> tuple[Path, str]:
        descriptor, name = tempfile.mkstemp(
            prefix=".manual-import-",
            suffix=suffix,
            dir=directory,
        )
        staged_path = Path(name)
        digest = hashlib.sha256()
        size = 0
        max_source_bytes = ImportLimits().max_compressed_bytes
        try:
            with os.fdopen(descriptor, "wb") as staged_file:
                try:
                    source_file = source_path.open("rb")
                except OSError as exc:
                    raise _SourceReadError(exc) from exc
                with source_file:
                    while True:
                        try:
                            chunk = source_file.read(_SOURCE_COPY_CHUNK_SIZE)
                        except OSError as exc:
                            raise _SourceReadError(exc) from exc
                        if not chunk:
                            break
                        size += len(chunk)
                        if size > max_source_bytes:
                            raise DocxImportError("Compressed DOCX file exceeds the size limit")
                        digest.update(chunk)
                        staged_file.write(chunk)
                staged_file.flush()
                os.fsync(staged_file.fileno())
        except BaseException:
            staged_path.unlink(missing_ok=True)
            raise
        return staged_path, digest.hexdigest()

    def _source_path_is_registered(self, path: Path) -> bool:
        relative_path = path.relative_to(self.storage.workspace_path).as_posix()
        with closing(self.storage.connect()) as connection:
            row = connection.execute(
                "SELECT 1 FROM source_revisions WHERE relative_path = ?",
                (relative_path,),
            ).fetchone()
        return row is not None

    def _workspace_file(self, relative_path: str) -> Path:
        path = Path(relative_path)
        if path.is_absolute():
            raise WorkspaceStorageError("Stored workspace path must be relative")
        absolute_path = (self.storage.workspace_path / path).resolve()
        if not absolute_path.is_relative_to(self.storage.workspace_path):
            raise WorkspaceStorageError("Stored workspace path escapes the workspace")
        return absolute_path


def _make_item_drafts(imported: ImportedManual) -> list[_ItemDraft]:
    heading_blocks = [
        (index, block)
        for index, block in enumerate(imported.blocks)
        if isinstance(block, ParagraphBlock) and block.heading_level is not None
    ]
    heading_ids = {block.id for _, block in heading_blocks}
    unheaded_indexes = [
        index
        for index, block in enumerate(imported.blocks)
        if block.id not in heading_ids and block.parent_heading_id is None
    ]
    unheaded_id = str(uuid4()) if unheaded_indexes else None
    item_ids_by_heading: dict[UUID, str] = {}
    for _, block in heading_blocks:
        item_ids_by_heading[block.id] = str(uuid4())

    drafts: list[_ItemDraft] = []
    drafts_by_heading: dict[UUID, _ItemDraft] = {}
    if unheaded_id is not None:
        drafts.append(
            _ItemDraft(
                id=unheaded_id,
                parent_item_id=None,
                position=0,
                heading="Unheaded content",
                heading_level=None,
                quality_flags=(_UNHEADED_QUALITY_FLAG,),
            )
        )

    sibling_positions: dict[str | None, int] = {}
    for block_index, block in heading_blocks:
        parent_item_id = (
            item_ids_by_heading.get(block.parent_heading_id)
            if block.parent_heading_id is not None
            else None
        )
        if block.parent_heading_id is not None and parent_item_id is None:
            raise WorkspaceStorageError("DOCX heading references an unknown parent heading")
        position = sibling_positions.get(parent_item_id, 0)
        if parent_item_id is None and unheaded_id is not None:
            position = max(position, 1)
        sibling_positions[parent_item_id] = position + 1
        draft = _ItemDraft(
            id=item_ids_by_heading[block.id],
            parent_item_id=parent_item_id,
            position=position,
            heading=block.text,
            heading_level=block.heading_level,
            block_indexes=[block_index],
        )
        drafts.append(draft)
        drafts_by_heading[block.id] = draft
    for block_index, block in enumerate(imported.blocks):
        if block.id in heading_ids:
            continue
        owner = (
            drafts_by_heading.get(block.parent_heading_id)
            if block.parent_heading_id is not None
            else None
        )
        if block.parent_heading_id is not None and owner is None:
            raise WorkspaceStorageError("DOCX content references an unknown parent heading")
        if owner is not None:
            owner.block_indexes.append(block_index)
        elif unheaded_id is not None:
            drafts[0].block_indexes.append(block_index)
        else:
            raise WorkspaceStorageError("DOCX content could not be assigned to a manual item")
    return drafts


def _tree_order_items(
    items_by_parent: dict[str | None, list[ManualItemRecord]],
) -> tuple[ManualItemRecord, ...]:
    ordered: list[ManualItemRecord] = []

    def append_subtree(parent_item_id: str | None) -> None:
        for item in sorted(
            items_by_parent.get(parent_item_id, []),
            key=lambda candidate: candidate.position,
        ):
            ordered.append(item)
            append_subtree(item.id)

    append_subtree(None)
    if sum(len(items) for items in items_by_parent.values()) != len(ordered):
        raise WorkspaceStorageError("Stored manual index contains unreachable items")
    return tuple(ordered)


def _item_content(
    imported: ImportedManual,
    block_indexes: list[int],
) -> tuple[dict[str, object], list[tuple[str, SourceRef]]]:
    blocks = [imported.blocks[index].model_dump(mode="json") for index in sorted(block_indexes)]
    content: dict[str, object] = {
        "schema_version": _CONTENT_SCHEMA_VERSION,
        "blocks": blocks,
    }
    source_locations: list[tuple[str, SourceRef]] = []
    for block_index, block in enumerate(blocks):
        source_locations.extend(_find_source_refs(block, f"/blocks/{block_index}"))
    return content, source_locations


def _find_source_refs(value: object, pointer: str) -> list[tuple[str, SourceRef]]:
    found: list[tuple[str, SourceRef]] = []
    if isinstance(value, dict):
        for key, child in value.items():
            child_pointer = f"{pointer}/{_pointer_escape(str(key))}"
            if key == "source" and isinstance(child, dict):
                found.append((child_pointer, SourceRef.model_validate(child)))
            else:
                found.extend(_find_source_refs(child, child_pointer))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            found.extend(_find_source_refs(child, f"{pointer}/{index}"))
    return found


def _pointer_escape(token: str) -> str:
    return token.replace("~", "~0").replace("/", "~1")


def _write_atomic(path: Path, contents: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as temporary_file:
            temporary_file.write(contents)
            temporary_file.flush()
            os.fsync(temporary_file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _ensure_source_copy(
    path: Path,
    staged_source_path: Path,
    expected_sha256: str,
) -> Path | None:
    if path.exists():
        _ensure_existing_source(path, expected_sha256)
        return None

    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    temporary_path = Path(temporary_name)
    digest = hashlib.sha256()
    try:
        with os.fdopen(descriptor, "wb") as temporary_file:
            with staged_source_path.open("rb") as source_file:
                while chunk := source_file.read(_SOURCE_COPY_CHUNK_SIZE):
                    digest.update(chunk)
                    temporary_file.write(chunk)
            temporary_file.flush()
            os.fsync(temporary_file.fileno())
        if digest.hexdigest() != expected_sha256:
            raise WorkspaceStorageError("Staged DOCX bytes changed before source persistence")

        try:
            os.link(temporary_path, path)
        except FileExistsError:
            _ensure_existing_source(path, expected_sha256)
            return None
        return path
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise
    finally:
        temporary_path.unlink(missing_ok=True)


def _ensure_existing_source(path: Path, expected_sha256: str) -> None:
    try:
        actual_sha256 = _sha256_file(path)
    except OSError as exc:
        raise WorkspaceStorageError("Stored original source is missing or cannot be read") from exc
    if actual_sha256 != expected_sha256:
        raise WorkspaceStorageError("Stored original source integrity check failed")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source_file:
        while chunk := source_file.read(_SOURCE_COPY_CHUNK_SIZE):
            digest.update(chunk)
    return digest.hexdigest()


def _utc_timestamp() -> str:
    return datetime.now(UTC).isoformat()
