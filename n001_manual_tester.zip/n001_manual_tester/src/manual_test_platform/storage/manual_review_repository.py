"""Workspace-local persistence for approved manual handoffs and operator observations."""

from __future__ import annotations

import sqlite3
from uuid import UUID

from manual_test_platform.application.ports.manual_review import (
    ManualReviewPersistenceError,
    ManualReviewRevisionError,
    ManualReviewStepMismatchError,
)
from manual_test_platform.manual_model.contracts import TestCaseRevision
from manual_test_platform.manual_model.ports import ManualStepHandoff, OperatorObservation
from manual_test_platform.storage.sqlite_workspace import WorkspaceStorage


class ManualReviewRepositoryError(ManualReviewPersistenceError):
    """Base error raised by manual-review persistence."""


class UnknownManualCaseRevisionError(ManualReviewRevisionError, ManualReviewRepositoryError):
    """The requested test-case revision is not stored in this workspace."""


class SupersededManualCaseRevisionError(ManualReviewRevisionError, ManualReviewRepositoryError):
    """The test-case revision is no longer the current revision."""


class ManualStepMismatchError(ManualReviewStepMismatchError, ManualReviewRepositoryError):
    """The approved handoff does not match its stored revision and source evidence."""


class DuplicateManualHandoffError(ManualReviewRepositoryError):
    """The handoff has already been registered."""


class UnknownManualHandoffError(ManualReviewRepositoryError):
    """The observation refers to a handoff that was not registered in this workspace."""


class DuplicateOperatorObservationError(ManualReviewRepositoryError):
    """An observation has already been recorded for this handoff."""


class ManualReviewRepository:
    """Persist append-only manual handoffs and observations in one workspace."""

    def __init__(self, storage: WorkspaceStorage) -> None:
        self.storage = storage

    def save_handoff(
        self,
        handoff: ManualStepHandoff,
        revision: TestCaseRevision,
    ) -> ManualStepHandoff:
        """Validate a handoff against its persisted revision and store it atomically."""
        handoff = ManualStepHandoff.model_validate(handoff.model_dump(mode="python"))
        revision = TestCaseRevision.model_validate(revision.model_dump(mode="python"))
        if handoff.test_case_revision_id != revision.id or handoff.profile != revision.profile:
            raise ManualStepMismatchError("Handoff does not match its test-case revision")
        matching_steps = [step for step in revision.steps if step.id == handoff.step.id]
        if len(matching_steps) != 1 or matching_steps[0] != handoff.step:
            raise ManualStepMismatchError("Handoff step does not match its stored revision")
        revision_refs = {source_ref.id: source_ref for source_ref in revision.source_refs}
        handoff_refs = {source_ref.id: source_ref for source_ref in handoff.source_refs}
        if len(handoff_refs) != len(handoff.source_refs) or handoff_refs != {
            ref_id: revision_refs.get(ref_id) for ref_id in handoff_refs
        }:
            raise ManualStepMismatchError("Handoff sources do not match its stored revision")

        connection = self.storage.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            revision_row = connection.execute(
                "SELECT test_case_id FROM test_case_revisions WHERE id = ?",
                (str(revision.id),),
            ).fetchone()
            if revision_row is None:
                raise UnknownManualCaseRevisionError(f"Test-case revision not found: {revision.id}")
            case_row = connection.execute(
                "SELECT current_revision_id FROM test_cases WHERE id = ?",
                (revision_row["test_case_id"],),
            ).fetchone()
            if case_row is None or case_row["current_revision_id"] != str(revision.id):
                raise SupersededManualCaseRevisionError(
                    f"Test-case revision is superseded: {revision.id}"
                )
            existing = connection.execute(
                "SELECT 1 FROM manual_step_handoffs WHERE id = ?",
                (str(handoff.id),),
            ).fetchone()
            if existing is not None:
                raise DuplicateManualHandoffError(f"Handoff already exists: {handoff.id}")
            connection.execute(
                """
                INSERT INTO manual_step_handoffs (
                    id, revision_id, target_id, snapshot_sha256, content_json
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (
                    str(handoff.id),
                    str(handoff.test_case_revision_id),
                    handoff.target_id,
                    handoff.approval.snapshot_sha256,
                    handoff.model_dump_json(),
                ),
            )
            persisted = self._load_handoff(connection, handoff.id)
            connection.commit()
            return persisted
        except ManualReviewRepositoryError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise ManualReviewRepositoryError("Could not persist manual handoff") from exc
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def get_handoff(self, handoff_id: UUID) -> ManualStepHandoff:
        """Load one previously registered handoff."""
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN")
            handoff = self._load_handoff(connection, handoff_id)
            connection.commit()
            return handoff
        except ManualReviewRepositoryError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise ManualReviewRepositoryError("Could not load manual handoff") from exc
        finally:
            connection.close()

    def save_observation(self, observation: OperatorObservation) -> OperatorObservation:
        """Append one explicit operator observation for a known handoff."""
        observation = OperatorObservation.model_validate(observation.model_dump(mode="python"))
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            handoff_row = connection.execute(
                "SELECT 1 FROM manual_step_handoffs WHERE id = ?",
                (str(observation.handoff_id),),
            ).fetchone()
            if handoff_row is None:
                raise UnknownManualHandoffError(f"Handoff not found: {observation.handoff_id}")
            existing = connection.execute(
                "SELECT 1 FROM operator_observations WHERE handoff_id = ?",
                (str(observation.handoff_id),),
            ).fetchone()
            if existing is not None:
                raise DuplicateOperatorObservationError(
                    f"Observation already exists for handoff {observation.handoff_id}"
                )
            connection.execute(
                """
                INSERT INTO operator_observations (
                    handoff_id, outcome, occurred_at, author_display_name, observation,
                    content_json
                ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    str(observation.handoff_id),
                    observation.outcome.value,
                    observation.occurred_at.isoformat(),
                    observation.author_display_name,
                    observation.observation,
                    observation.model_dump_json(),
                ),
            )
            persisted = self._load_observation(connection, observation.handoff_id)
            connection.commit()
            return persisted
        except ManualReviewRepositoryError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise ManualReviewRepositoryError("Could not persist operator observation") from exc
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def get_observation(self, handoff_id: UUID) -> OperatorObservation:
        """Load the explicit observation recorded for one handoff."""
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN")
            observation = self._load_observation(connection, handoff_id)
            connection.commit()
            return observation
        except ManualReviewRepositoryError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise ManualReviewRepositoryError("Could not load operator observation") from exc
        finally:
            connection.close()

    @staticmethod
    def _load_handoff(connection: sqlite3.Connection, handoff_id: UUID) -> ManualStepHandoff:
        row = connection.execute(
            "SELECT content_json FROM manual_step_handoffs WHERE id = ?",
            (str(handoff_id),),
        ).fetchone()
        if row is None:
            raise UnknownManualHandoffError(f"Handoff not found: {handoff_id}")
        return ManualStepHandoff.model_validate_json(row["content_json"])

    @staticmethod
    def _load_observation(connection: sqlite3.Connection, handoff_id: UUID) -> OperatorObservation:
        row = connection.execute(
            "SELECT content_json FROM operator_observations WHERE handoff_id = ?",
            (str(handoff_id),),
        ).fetchone()
        if row is None:
            raise ManualReviewRepositoryError(
                f"Operator observation not found for handoff {handoff_id}"
            )
        return OperatorObservation.model_validate_json(row["content_json"])
