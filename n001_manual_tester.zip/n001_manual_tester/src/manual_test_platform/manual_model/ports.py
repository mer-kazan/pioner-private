"""Typed boundaries for product profiles and application adapters."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Literal, Protocol
from uuid import uuid4

from pydantic import Field, model_validator

from manual_test_platform.docx_parser.models import ImportedManual
from manual_test_platform.manual_model.contracts import (
    CommandSpec,
    DomainModel,
    EntityId,
    ExecutionMode,
    ProductProfileRef,
    Sha256,
    SourceEvidence,
    StepReadiness,
    TestStep,
    UtcTimestamp,
)


class ProfileFinding(DomainModel):
    """A profile-specific validation finding; profiles cannot grant permission."""

    code: str = Field(min_length=1)
    message: str = Field(min_length=1)
    blocking: bool


class ProductProfile(Protocol):
    """Versioned terminology and additional, restrictive validation rules."""

    @property
    def ref(self) -> ProductProfileRef: ...

    @property
    def terms(self) -> Mapping[str, str]: ...

    def validate_step(self, step: TestStep) -> tuple[ProfileFinding, ...]: ...


class DocumentAdapter(Protocol):
    """Registered adapter for one supported source-document format."""

    @property
    def format_id(self) -> Literal["docx"]: ...

    def load(self, source_path: Path) -> ImportedManual: ...


class OperatorOutcome(StrEnum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"


class ManualHandoffApproval(DomainModel):
    """Operator confirmation bound to one manual-step snapshot and target."""

    target_id: str = Field(min_length=1)
    snapshot_sha256: Sha256
    approved_by_display_name: str = Field(min_length=1)
    approved_at: UtcTimestamp


class ManualStepHandoff(DomainModel):
    """Exact approved step presented for execution outside the app."""

    id: EntityId = Field(default_factory=uuid4)
    test_case_revision_id: EntityId
    profile: ProductProfileRef
    target_id: str = Field(min_length=1)
    step: TestStep
    source_refs: tuple[SourceEvidence, ...]
    approval: ManualHandoffApproval

    @staticmethod
    def calculate_snapshot_sha256(
        *,
        test_case_revision_id: EntityId,
        profile: ProductProfileRef,
        target_id: str,
        step: TestStep,
        source_refs: tuple[SourceEvidence, ...],
    ) -> str:
        snapshot = {
            "test_case_revision_id": str(test_case_revision_id),
            "profile": profile.model_dump(mode="json"),
            "target_id": target_id,
            "step": step.model_dump(mode="json"),
            "source_refs": [source_ref.model_dump(mode="json") for source_ref in source_refs],
        }
        serialized = json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(serialized.encode("utf-8")).hexdigest()

    @model_validator(mode="after")
    def validate_step_sources(self) -> ManualStepHandoff:
        if self.step.readiness is not StepReadiness.READY:
            raise ValueError("Only READY steps can be handed to the operator")
        if self.step.execution_mode is not ExecutionMode.MANUAL_ONLY:
            raise ValueError("Only manual-only steps can use the manual handoff")
        refs_by_id = {source_ref.id: source_ref for source_ref in self.source_refs}
        if len(refs_by_id) != len(self.source_refs):
            raise ValueError("Handoff source reference IDs must be unique")
        if set(refs_by_id) != set(self.step.source_ref_ids):
            raise ValueError("Handoff source references must match the step references")
        source_revision_ids = {source_ref.source_revision_id for source_ref in self.source_refs}
        if len(source_revision_ids) != 1:
            raise ValueError("Handoff source references must belong to one source revision")
        if self.step.command is not None and not set(self.step.command.source_ref_ids).issubset(
            refs_by_id
        ):
            raise ValueError("Every command source reference must resolve in the handoff")
        if not set(self.step.expected_result.source_ref_ids).issubset(refs_by_id):
            raise ValueError("Every expected-result source reference must resolve in the handoff")
        if self.approval.target_id != self.target_id:
            raise ValueError("Manual handoff approval must target the presented target")
        expected_snapshot_hash = self.calculate_snapshot_sha256(
            test_case_revision_id=self.test_case_revision_id,
            profile=self.profile,
            target_id=self.target_id,
            step=self.step,
            source_refs=self.source_refs,
        )
        if self.approval.snapshot_sha256 != expected_snapshot_hash:
            raise ValueError("Manual handoff approval does not match the exact step snapshot")
        return self


class OperatorObservation(DomainModel):
    """An observation explicitly entered by the operator, not inferred by an adapter."""

    handoff_id: EntityId
    outcome: OperatorOutcome
    observation: str = Field(min_length=1)
    author_display_name: str = Field(min_length=1)
    occurred_at: datetime

    @model_validator(mode="after")
    def validate_timestamp(self) -> OperatorObservation:
        if self.occurred_at.tzinfo is None or self.occurred_at.utcoffset() != UTC.utcoffset(
            self.occurred_at
        ):
            raise ValueError("Observation timestamp must be timezone-aware UTC")
        return self


class ManualExecutionAdapter(Protocol):
    """Manual-only adapter: it presents a step and records operator-entered evidence."""

    def present(self, handoff: ManualStepHandoff) -> None: ...

    def record_observation(self, observation: OperatorObservation) -> None: ...


class CommandReviewRequest(DomainModel):
    """Minimum source-grounded context required for a non-authoritative LLM review."""

    id: EntityId = Field(default_factory=uuid4)
    profile: ProductProfileRef
    command: CommandSpec
    source_context: tuple[SourceEvidence, ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_source_context(self) -> CommandReviewRequest:
        refs_by_id = {source_ref.id: source_ref for source_ref in self.source_context}
        if len(refs_by_id) != len(self.source_context):
            raise ValueError("Command review source reference IDs must be unique")
        if not set(self.command.source_ref_ids).issubset(refs_by_id):
            raise ValueError("Every command source reference must be included in its context")
        source_revision_ids = {source_ref.source_revision_id for source_ref in self.source_context}
        if len(source_revision_ids) != 1:
            raise ValueError("Command review context must belong to one source revision")
        return self

    def validate_advice(self, advice: CommandReviewAdvice) -> CommandReviewAdvice:
        """Reject advice that is uncorrelated or cites sources absent from the request."""
        if advice.request_id != self.id:
            raise ValueError("Command review advice does not match its request")
        context_ids = {source_ref.id for source_ref in self.source_context}
        cited_ids = advice.cited_source_ref_ids
        if len(set(cited_ids)) != len(cited_ids):
            raise ValueError("Command review source citations must be unique")
        if not cited_ids or not set(cited_ids).issubset(context_ids):
            raise ValueError("Command review advice cites a source outside its request context")
        return advice


class CommandReviewAdvice(DomainModel):
    """Advisory text only; it cannot change a command, risk, or readiness."""

    request_id: EntityId
    purpose: str = Field(min_length=1)
    documented_risks: tuple[str, ...] = ()
    syntax_notes: tuple[str, ...] = ()
    possible_failure_causes: tuple[str, ...] = ()
    suggestions: tuple[str, ...] = ()
    cited_source_ref_ids: tuple[EntityId, ...] = Field(min_length=1)


class LLMProvider(Protocol):
    """Provider for command-review advice; no execution or approval capability."""

    def review_command(self, request: CommandReviewRequest) -> CommandReviewAdvice: ...


__all__ = [
    "CommandReviewAdvice",
    "CommandReviewRequest",
    "DocumentAdapter",
    "LLMProvider",
    "ManualHandoffApproval",
    "ManualExecutionAdapter",
    "ManualStepHandoff",
    "OperatorObservation",
    "OperatorOutcome",
    "ProductProfile",
    "ProfileFinding",
]
