"""Public test-case contract."""

from manual_test_platform.manual_model.contracts import TestCase

__all__ = ["TestCase"]
