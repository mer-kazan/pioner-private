from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from manual_test_platform.manual_model.section import ManualSection


@dataclass
class ManualDocument:
    title: str = ""
    source_path: str | Path | None = None
    sections: list[ManualSection] = field(default_factory=list)

    def add_section(self, section: ManualSection) -> None:
        self.sections.append(section)
