from __future__ import annotations

import sqlite3
from pathlib import Path

from PySide6.QtCore import QEvent
from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QInputDialog,
    QMainWindow,
    QMessageBox,
    QTextEdit,
    QWidget,
)

from manual_test_platform.app.i18n import SUPPORTED_LANGUAGES, LanguageManager
from manual_test_platform.app.ui.navigation_panel import NavigationPanel
from manual_test_platform.application.ports.manual_import import ImportedManualResult
from manual_test_platform.application.services.manual_import import ManualImportService
from manual_test_platform.docx_parser import DocxImportError
from manual_test_platform.storage.manual_import_repository import ManualImportRepository
from manual_test_platform.storage.sqlite_workspace import (
    WORKSPACE_DATABASE_NAME,
    WorkspaceStorage,
    WorkspaceStorageError,
)


class MainWindow(QMainWindow):
    def __init__(
        self,
        language_manager: LanguageManager,
        storage: WorkspaceStorage | None = None,
    ) -> None:
        super().__init__()
        self._language_manager = language_manager
        self._storage: WorkspaceStorage | None = None
        self._import_service: ManualImportService | None = None
        self._last_import: ImportedManualResult | None = None
        self._last_import_name: str | None = None
        self.resize(1400, 900)

        self.navigation = NavigationPanel(self)

        self.content = QWidget(self)
        self.content_layout = QHBoxLayout(self.content)
        self.content_layout.addWidget(self.navigation)

        self.preview = QTextEdit(self)
        self.preview.setReadOnly(True)
        self.content_layout.addWidget(self.preview)

        self.setCentralWidget(self.content)

        self.workspace_menu = self.menuBar().addMenu("")
        self.change_workspace_action = QAction(self)
        self.change_workspace_action.triggered.connect(self._change_workspace)
        self.workspace_menu.addAction(self.change_workspace_action)

        self.manual_menu = self.menuBar().addMenu("")
        self.import_docx_action = QAction(self)
        self.import_docx_action.triggered.connect(self._import_docx)
        self.manual_menu.addAction(self.import_docx_action)
        self.recheck_import_action = QAction(self)
        self.recheck_import_action.triggered.connect(self._recheck_latest_import)
        self.manual_menu.addAction(self.recheck_import_action)

        self.language_menu = self.menuBar().addMenu("")
        self.language_actions: dict[str, QAction] = {}
        self.language_action_group = QActionGroup(self)
        self.language_action_group.setExclusive(True)
        for code, display_name in SUPPORTED_LANGUAGES.items():
            action = QAction(display_name, self)
            action.setCheckable(True)

            def select_language(checked: bool = False, *, language: str = code) -> None:
                if checked:
                    self._select_language(language)

            action.triggered.connect(select_language)
            self.language_action_group.addAction(action)
            self.language_menu.addAction(action)
            self.language_actions[code] = action

        self.retranslate_ui()
        if storage is not None:
            self.set_workspace(storage)

    def changeEvent(self, event: QEvent) -> None:
        super().changeEvent(event)
        if event.type() == QEvent.Type.LanguageChange:
            self.retranslate_ui()

    def retranslate_ui(self) -> None:
        self.setWindowTitle(self.tr("Manual Test Platform"))
        self.workspace_menu.setTitle(self.tr("Workspace"))
        self.change_workspace_action.setText(self.tr("Open or create workspace..."))
        self.manual_menu.setTitle(self.tr("Manual"))
        self.import_docx_action.setText(self.tr("Import DOCX..."))
        self.import_docx_action.setEnabled(self._import_service is not None)
        self.recheck_import_action.setText(self.tr("Recheck latest import..."))
        self.recheck_import_action.setEnabled(self._last_import is not None)
        self.language_menu.setTitle(self.tr("Language"))
        for code, action in self.language_actions.items():
            action.setChecked(code == self._language_manager.language)
        self.navigation.retranslate_ui()
        self._refresh_preview()
        self.statusBar().showMessage(
            self.tr("Workspace ready") if self._storage is not None else self.tr("Ready")
        )

    def select_workspace(self) -> WorkspaceStorage | None:
        choice = QMessageBox(self)
        choice.setWindowTitle(self.tr("Select workspace"))
        choice.setText(self.tr("Open an existing workspace or create a new one."))
        open_button = choice.addButton(
            self.tr("Open workspace"),
            QMessageBox.ButtonRole.AcceptRole,
        )
        create_button = choice.addButton(
            self.tr("Create workspace"),
            QMessageBox.ButtonRole.ActionRole,
        )
        choice.addButton(QMessageBox.StandardButton.Cancel)
        choice.exec()

        if choice.clickedButton() == open_button:
            return self._open_workspace()
        if choice.clickedButton() == create_button:
            return self._create_workspace()
        return None

    def set_workspace(self, storage: WorkspaceStorage) -> None:
        self._storage = storage
        self._import_service = ManualImportService(ManualImportRepository(storage))
        try:
            self._last_import = self._import_service.get_latest_import()
        except (OSError, sqlite3.Error, WorkspaceStorageError) as error:
            self._last_import = None
            QMessageBox.warning(
                self,
                self.tr("Previous import unavailable"),
                str(error),
            )
        self._last_import_name = (
            self._last_import.source_name if self._last_import is not None else None
        )
        self.import_docx_action.setEnabled(True)
        self.recheck_import_action.setEnabled(self._last_import is not None)
        self._refresh_preview()
        self.statusBar().showMessage(self.tr("Workspace ready"))

    def _open_workspace(self) -> WorkspaceStorage | None:
        directory = QFileDialog.getExistingDirectory(
            self,
            self.tr("Open workspace"),
            str(Path.home()),
        )
        if not directory:
            return None
        workspace_path = Path(directory)
        if not (workspace_path / WORKSPACE_DATABASE_NAME).is_file():
            QMessageBox.warning(
                self,
                self.tr("Not a workspace"),
                self.tr("The selected folder does not contain a workspace database."),
            )
            return None
        return self._initialize_workspace(workspace_path)

    def _create_workspace(self) -> WorkspaceStorage | None:
        parent_directory = QFileDialog.getExistingDirectory(
            self,
            self.tr("Choose where to create the workspace"),
            str(Path.home()),
        )
        if not parent_directory:
            return None
        workspace_name, accepted = QInputDialog.getText(
            self,
            self.tr("Create workspace"),
            self.tr("Workspace folder name:"),
        )
        if not accepted:
            return None
        if (
            not workspace_name.strip()
            or workspace_name != workspace_name.strip()
            or workspace_name in {".", ".."}
            or workspace_name.endswith((".", " "))
            or any(ord(character) < 32 or character in '<>:"/\\|?*' for character in workspace_name)
        ):
            QMessageBox.warning(
                self,
                self.tr("Invalid workspace name"),
                self.tr("Enter a single folder name without path separators."),
            )
            return None

        workspace_path = Path(parent_directory) / workspace_name
        try:
            workspace_path.mkdir()
        except FileExistsError:
            QMessageBox.warning(
                self,
                self.tr("Workspace already exists"),
                self.tr("Choose a name that does not already exist in this folder."),
            )
            return None
        except OSError as error:
            QMessageBox.critical(
                self,
                self.tr("Could not create workspace"),
                str(error),
            )
            return None
        return self._initialize_workspace(workspace_path)

    def _initialize_workspace(self, workspace_path: Path) -> WorkspaceStorage | None:
        try:
            storage = WorkspaceStorage(workspace_path)
            storage.initialize()
        except (OSError, sqlite3.Error, WorkspaceStorageError) as error:
            QMessageBox.critical(
                self,
                self.tr("Could not open workspace"),
                str(error),
            )
            return None
        return storage

    def _change_workspace(self) -> None:
        storage = self.select_workspace()
        if storage is not None:
            self.set_workspace(storage)

    def _import_docx(self) -> None:
        if self._storage is None or self._import_service is None:
            return
        self._import_selected_docx()

    def _recheck_latest_import(self) -> None:
        if self._last_import is None:
            return
        self._import_selected_docx(recheck_of_import_id=str(self._last_import.manual_import.id))

    def _import_selected_docx(self, *, recheck_of_import_id: str | None = None) -> None:
        if self._storage is None or self._import_service is None:
            return
        selected_path, _ = QFileDialog.getOpenFileName(
            self,
            self.tr("Import DOCX manual"),
            str(self._storage.workspace_path),
            self.tr("Word documents (*.docx)"),
        )
        if not selected_path:
            return

        source_path = Path(selected_path)
        try:
            imported = self._import_service.import_docx(
                source_path,
                recheck_of_import_id=recheck_of_import_id,
            )
        except (DocxImportError, OSError, sqlite3.Error, WorkspaceStorageError) as error:
            QMessageBox.critical(
                self,
                self.tr("DOCX import failed"),
                str(error),
            )
            self.statusBar().showMessage(self.tr("DOCX import failed"))
            return

        self._last_import = imported
        self._last_import_name = imported.source_name or source_path.name
        self.recheck_import_action.setEnabled(True)
        self._refresh_preview()
        self.statusBar().showMessage(self.tr("DOCX import completed"))

    def _refresh_preview(self) -> None:
        lines = [self.tr("Manual Test Platform")]
        if self._storage is None:
            lines.append(self.tr("Select or create a workspace to begin."))
        else:
            lines.append(self.tr("Workspace: {path}").format(path=self._storage.workspace_path))

        imported = self._last_import
        if imported is not None:
            lines.extend(
                [
                    self.tr("Imported document: {name}").format(name=self._last_import_name or ""),
                    self.tr("Source SHA-256: {sha256}").format(sha256=imported.source_sha256 or ""),
                    self.tr("Manual items: {count}").format(
                        count=len(imported.manual_index.items) if imported.manual_index else 0
                    ),
                ]
            )
            item_depths = _item_depths(imported)
            lines.extend(
                f"{'  ' * item_depths[item.id]}{item.heading or self.tr('Untitled item')}"
                for item in (imported.manual_index.items if imported.manual_index else ())
            )
        preview_text = "\n\n".join(lines[:2])
        if len(lines) > 2:
            preview_text += "\n\n" + "\n".join(lines[2:])
        self.preview.setPlainText(preview_text)

    def _select_language(self, language: str) -> None:
        try:
            self._language_manager.set_language(language)
        except OSError as error:
            QMessageBox.warning(
                self,
                self.tr("Language preference was not saved"),
                str(error),
            )


def _item_depths(imported: ImportedManualResult) -> dict[object, int]:
    depths: dict[object, int] = {}
    if imported.manual_index is None:
        return depths
    for item in imported.manual_index.items:
        if item.parent_item_id is None:
            depths[item.id] = 0
            continue
        parent_depth = depths.get(item.parent_item_id)
        if parent_depth is None:
            raise WorkspaceStorageError("Manual item references an unknown parent")
        depths[item.id] = parent_depth + 1
    return depths
