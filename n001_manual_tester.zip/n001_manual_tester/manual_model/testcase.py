"""Public test-case contract."""

from manual_model.contracts import TestCase

__all__ = ["TestCase"]
