from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ManualSection:
    number: str
    title: str
    text: str = ""
    children: list[ManualSection] = field(default_factory=list)

    def add_child(self, child: ManualSection) -> None:
        self.children.append(child)
