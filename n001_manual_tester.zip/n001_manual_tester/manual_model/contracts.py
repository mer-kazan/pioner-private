"""Typed domain contracts for manual imports and human review."""

from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import PurePosixPath
from typing import Annotated
from uuid import UUID, uuid4

from pydantic import AfterValidator, BaseModel, ConfigDict, Field, model_validator


def _require_uuid4(value: UUID) -> UUID:
    if value.version != 4:
        raise ValueError("Entity IDs must be UUIDv4")
    return value


def _require_utc(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() != UTC.utcoffset(value):
        raise ValueError("Timestamps must be timezone-aware UTC")
    return value


def _require_sha256(value: str) -> str:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError("sha256 must be a lowercase hexadecimal SHA-256 digest")
    return value


EntityId = Annotated[UUID, AfterValidator(_require_uuid4)]
UtcTimestamp = Annotated[datetime, AfterValidator(_require_utc)]
Sha256 = Annotated[str, AfterValidator(_require_sha256)]


class DomainModel(BaseModel):
    """Immutable, strictly validated base for persisted domain contracts."""

    model_config = ConfigDict(frozen=True, extra="forbid")


class ManualImportStatus(StrEnum):
    IMPORTED = "IMPORTED"
    FAILED = "FAILED"


class ReviewStatus(StrEnum):
    IN_REVIEW = "IN_REVIEW"
    CONFIRMED = "CONFIRMED"


class AmendmentStatus(StrEnum):
    PROPOSED = "PROPOSED"
    CONFIRMED = "CONFIRMED"
    REJECTED = "REJECTED"


class RiskLevel(StrEnum):
    READ_ONLY = "READ_ONLY"
    CONFIG_CHANGE = "CONFIG_CHANGE"
    DISRUPTIVE = "DISRUPTIVE"
    DESTRUCTIVE = "DESTRUCTIVE"
    UNKNOWN = "UNKNOWN"


class StepReadiness(StrEnum):
    DRAFT = "DRAFT"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    READY = "READY"
    BLOCKED = "BLOCKED"


class ExecutionMode(StrEnum):
    MANUAL_ONLY = "MANUAL_ONLY"
    ADAPTER = "ADAPTER"


class ExpectedResultStatus(StrEnum):
    DOCUMENTED = "DOCUMENTED"
    NOT_SPECIFIED = "NOT_SPECIFIED"


class CommandVerificationStatus(StrEnum):
    UNVERIFIED = "UNVERIFIED"
    VERIFIED = "VERIFIED"


class TestCasePreparationStatus(StrEnum):
    DRAFT = "DRAFT"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    READY = "READY"


class ProductProfileRef(DomainModel):
    """Stable identity of a built-in, versioned product profile."""

    profile_id: str = Field(min_length=1)
    version: str = Field(min_length=1)


class SourceEvidence(DomainModel):
    """Persisted, revision-scoped locator for an exact source excerpt."""

    id: EntityId = Field(default_factory=uuid4)
    source_revision_id: EntityId
    part_uri: str = Field(min_length=1)
    xpath: str = Field(min_length=1)
    block_index: int | None = Field(default=None, ge=0)
    paragraph_index: int | None = Field(default=None, ge=0)
    table_index: int | None = Field(default=None, ge=0)
    row_index: int | None = Field(default=None, ge=0)
    cell_index: int | None = Field(default=None, ge=0)
    quoted_text: str | None = None
    quoted_text_sha256: Sha256 | None = None

    @model_validator(mode="after")
    def validate_quote_digest(self) -> SourceEvidence:
        if (self.quoted_text is None) != (self.quoted_text_sha256 is None):
            raise ValueError("quoted_text and quoted_text_sha256 must be provided together")
        if (
            self.quoted_text is not None
            and self.quoted_text_sha256
            != hashlib.sha256(self.quoted_text.encode("utf-8")).hexdigest()
        ):
            raise ValueError("quoted_text_sha256 does not match quoted_text")
        return self


class ManualImport(DomainModel):
    """One import or explicitly requested recheck; never the source revision itself."""

    id: EntityId = Field(default_factory=uuid4)
    source_revision_id: EntityId | None
    created_at: UtcTimestamp
    status: ManualImportStatus
    recheck_of_import_id: EntityId | None = None
    manual_index_id: EntityId | None = None
    error_code: str | None = None
    error_message: str | None = None

    @model_validator(mode="after")
    def validate_result(self) -> ManualImport:
        if self.status is ManualImportStatus.IMPORTED:
            if self.source_revision_id is None or self.manual_index_id is None:
                raise ValueError("Imported records require a source revision and manual index")
            if self.error_code is not None or self.error_message is not None:
                raise ValueError("Imported records cannot contain error details")
        else:
            if self.manual_index_id is not None:
                raise ValueError("Failed imports cannot have a manual index")
            if not self.error_code or not self.error_message:
                raise ValueError("Failed imports require an error code and message")
        return self


class ManualItem(DomainModel):
    """One node in an import-specific manual index."""

    id: EntityId = Field(default_factory=uuid4)
    parent_item_id: EntityId | None = None
    position: int = Field(ge=0)
    heading: str | None = None
    heading_level: int | None = Field(default=None, ge=1, le=9)
    content_path: str = Field(min_length=1)
    content_format_version: int = Field(default=1, ge=1)
    content_sha256: Sha256
    quality_flags: tuple[str, ...] = ()
    active_review_cycle_id: EntityId | None = None

    @model_validator(mode="after")
    def validate_content_path(self) -> ManualItem:
        path = PurePosixPath(self.content_path)
        if (
            path.is_absolute()
            or "\\" in self.content_path
            or any(part in {"", ".", ".."} for part in self.content_path.split("/"))
        ):
            raise ValueError("content_path must be a normalized workspace-relative POSIX path")
        if (self.heading is None) != (self.heading_level is None):
            raise ValueError("heading and heading_level must be provided together")
        return self


class ManualIndex(DomainModel):
    """Navigation and review state for exactly one import."""

    id: EntityId = Field(default_factory=uuid4)
    manual_import_id: EntityId
    schema_version: int = Field(ge=1)
    items: tuple[ManualItem, ...]
    current_compiled_version_id: EntityId | None = None

    @model_validator(mode="after")
    def validate_item_tree(self) -> ManualIndex:
        items_by_id = {item.id: item for item in self.items}
        if len(items_by_id) != len(self.items):
            raise ValueError("Manual item IDs must be unique within an index")

        sibling_positions: set[tuple[EntityId | None, int]] = set()
        for item in self.items:
            if item.parent_item_id == item.id:
                raise ValueError("A manual item cannot be its own parent")
            if item.parent_item_id is not None and item.parent_item_id not in items_by_id:
                raise ValueError("Every parent item must belong to the same index")
            sibling_position = (item.parent_item_id, item.position)
            if sibling_position in sibling_positions:
                raise ValueError("Sibling item positions must be unique")
            sibling_positions.add(sibling_position)

            visited: set[EntityId] = {item.id}
            parent_id = item.parent_item_id
            while parent_id is not None:
                if parent_id in visited:
                    raise ValueError("Manual item hierarchy cannot contain cycles")
                visited.add(parent_id)
                parent_id = items_by_id[parent_id].parent_item_id
        return self


class ItemReviewEvent(DomainModel):
    """Append-only review decision tied to the exact content hash displayed."""

    id: EntityId = Field(default_factory=uuid4)
    cycle_id: EntityId
    status: ReviewStatus
    content_sha256: Sha256
    author_display_name: str = Field(min_length=1)
    occurred_at: UtcTimestamp


class ItemReviewCycle(DomainModel):
    """A review cycle; reopening creates a new cycle instead of rewriting history."""

    id: EntityId = Field(default_factory=uuid4)
    manual_item_id: EntityId
    sequence: int = Field(ge=1)
    events: tuple[ItemReviewEvent, ...] = ()

    @model_validator(mode="after")
    def validate_event_history(self) -> ItemReviewCycle:
        if not self.events:
            return self
        if self.events[0].status is not ReviewStatus.IN_REVIEW:
            raise ValueError("A review cycle must begin with IN_REVIEW")
        if any(event.cycle_id != self.id for event in self.events):
            raise ValueError("Review events must belong to their containing cycle")
        if len({event.content_sha256 for event in self.events}) > 1:
            raise ValueError("Reviewed content cannot change within a review cycle")
        if any(
            earlier.occurred_at > later.occurred_at
            for earlier, later in zip(self.events, self.events[1:], strict=False)
        ):
            raise ValueError("Review events must be ordered by occurrence time")
        if any(event.status is not ReviewStatus.CONFIRMED for event in self.events[1:]):
            raise ValueError("A review cycle can only be confirmed once")
        if len(self.events) > 2:
            raise ValueError("Confirmed review cycles are terminal")
        return self

    @property
    def status(self) -> ReviewStatus | None:
        return self.events[-1].status if self.events else None


class ManualAmendment(DomainModel):
    """Proposed change to a reviewed item, with a terminal operator decision."""

    id: EntityId = Field(default_factory=uuid4)
    manual_item_id: EntityId
    source_ref_ids: tuple[EntityId, ...] = ()
    replaces_amendment_id: EntityId | None = None
    content: str = Field(min_length=1)
    status: AmendmentStatus
    author_display_name: str = Field(min_length=1)
    created_at: UtcTimestamp
    decided_by_display_name: str | None = None
    decided_at: UtcTimestamp | None = None

    @model_validator(mode="after")
    def validate_decision(self) -> ManualAmendment:
        has_decision = self.decided_by_display_name is not None and self.decided_at is not None
        if self.status is AmendmentStatus.PROPOSED and (
            self.decided_by_display_name is not None or self.decided_at is not None
        ):
            raise ValueError("Proposed amendments cannot contain a decision")
        if self.status is not AmendmentStatus.PROPOSED and not has_decision:
            raise ValueError("Confirmed or rejected amendments require a decision")
        if self.decided_by_display_name == "":
            raise ValueError("Decision author must not be empty")
        if self.replaces_amendment_id == self.id:
            raise ValueError("An amendment cannot replace itself")
        return self


class ExpectedResult(DomainModel):
    """Source-grounded result text and operator-checkable success conditions."""

    status: ExpectedResultStatus
    text: str = Field(min_length=1)
    source_ref_ids: tuple[EntityId, ...] = ()
    observable_checks: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_documentation(self) -> ExpectedResult:
        if self.status is ExpectedResultStatus.DOCUMENTED:
            if not self.source_ref_ids:
                raise ValueError("Documented expected results require source references")
            if not self.observable_checks:
                raise ValueError("Documented expected results require observable checks")
        elif self.text != "НЕ УКАЗАНО В МАНУАЛЕ":
            raise ValueError("Unspecified expected results must use the explicit unknown marker")
        return self


class TestPrecondition(DomainModel):
    """A source-grounded condition that must hold before the case starts."""

    text: str = Field(min_length=1)
    source_ref_ids: tuple[EntityId, ...] = Field(min_length=1)


class CommandSpec(DomainModel):
    """A literal command excerpt; parameters are never invented by this contract."""

    exact_text: str = Field(min_length=1)
    source_ref_ids: tuple[EntityId, ...] = Field(min_length=1)
    verification_status: CommandVerificationStatus = CommandVerificationStatus.UNVERIFIED
    unresolved_parameters: tuple[str, ...] = ()

    @model_validator(mode="after")
    def validate_verification(self) -> CommandSpec:
        if self.verification_status is CommandVerificationStatus.VERIFIED:
            if self.unresolved_parameters:
                raise ValueError("Commands with unresolved parameters cannot be verified")
        return self


class TestStep(DomainModel):
    """One ordered, source-grounded review or execution instruction."""

    id: EntityId = Field(default_factory=uuid4)
    position: int = Field(ge=0)
    instruction: str = Field(min_length=1)
    source_ref_ids: tuple[EntityId, ...] = Field(min_length=1)
    command: CommandSpec | None = None
    expected_result: ExpectedResult = Field(
        default_factory=lambda: ExpectedResult(
            status=ExpectedResultStatus.NOT_SPECIFIED,
            text="НЕ УКАЗАНО В МАНУАЛЕ",
        )
    )
    risk: RiskLevel = RiskLevel.UNKNOWN
    execution_mode: ExecutionMode = ExecutionMode.MANUAL_ONLY
    readiness: StepReadiness = StepReadiness.NEEDS_REVIEW

    @model_validator(mode="after")
    def validate_readiness(self) -> TestStep:
        if self.command is not None and not set(self.command.source_ref_ids).issubset(
            self.source_ref_ids
        ):
            raise ValueError("Command source references must belong to the containing step")
        if not set(self.expected_result.source_ref_ids).issubset(self.source_ref_ids):
            raise ValueError("Expected-result source references must belong to the containing step")
        if (
            self.risk in {RiskLevel.CONFIG_CHANGE, RiskLevel.DISRUPTIVE, RiskLevel.DESTRUCTIVE}
            and self.execution_mode is not ExecutionMode.MANUAL_ONLY
        ):
            raise ValueError("Risky steps must use manual-only execution")
        if self.risk is RiskLevel.UNKNOWN and self.execution_mode is ExecutionMode.ADAPTER:
            raise ValueError("Steps with unknown risk cannot use an execution adapter")
        if self.readiness is StepReadiness.READY:
            if not self.source_ref_ids:
                raise ValueError("Ready steps require source references")
            if self.risk is RiskLevel.UNKNOWN:
                raise ValueError("Steps with unknown risk cannot be READY")
            if self.expected_result.status is not ExpectedResultStatus.DOCUMENTED:
                raise ValueError("Steps without a documented expected result cannot be READY")
            if self.command is not None:
                if self.command.verification_status is not CommandVerificationStatus.VERIFIED:
                    raise ValueError("Unverified commands cannot be READY")
                if self.command.unresolved_parameters:
                    raise ValueError("Commands with unresolved parameters cannot be READY")
        return self


class TestCase(DomainModel):
    """Stable test-case identity pointing to its current immutable revision."""

    id: EntityId = Field(default_factory=uuid4)
    current_revision_id: EntityId


class TestCaseRevision(DomainModel):
    """Immutable content snapshot for one test-case revision."""

    id: EntityId = Field(default_factory=uuid4)
    test_case_id: EntityId
    revision_number: int = Field(ge=1)
    manual_import_id: EntityId
    source_revision_id: EntityId
    profile: ProductProfileRef
    title: str = Field(min_length=1)
    preconditions: tuple[TestPrecondition, ...] = ()
    steps: tuple[TestStep, ...] = Field(min_length=1)
    source_refs: tuple[SourceEvidence, ...] = ()

    @model_validator(mode="after")
    def validate_step_order(self) -> TestCaseRevision:
        step_ids = [step.id for step in self.steps]
        if len(set(step_ids)) != len(step_ids):
            raise ValueError("Test step IDs must be unique within a revision")
        positions = [step.position for step in self.steps]
        if positions != list(range(len(self.steps))):
            raise ValueError("Test step positions must be contiguous and ordered from zero")
        refs_by_id = {source_ref.id: source_ref for source_ref in self.source_refs}
        if len(refs_by_id) != len(self.source_refs):
            raise ValueError("Source reference IDs must be unique within a revision")
        if any(
            source_ref.source_revision_id != self.source_revision_id
            for source_ref in self.source_refs
        ):
            raise ValueError("All source references must belong to the revision source")
        referenced_ids = {
            source_ref_id
            for precondition in self.preconditions
            for source_ref_id in precondition.source_ref_ids
        }
        for step in self.steps:
            referenced_ids.update(step.source_ref_ids)
            if step.command is not None:
                referenced_ids.update(step.command.source_ref_ids)
            referenced_ids.update(step.expected_result.source_ref_ids)
        if not referenced_ids.issubset(refs_by_id):
            raise ValueError("Every referenced source ID must resolve within the revision")
        return self


class TestCaseReviewEvent(DomainModel):
    """Append-only preparation status event pinned to one immutable revision."""

    id: EntityId = Field(default_factory=uuid4)
    revision_id: EntityId
    status: TestCasePreparationStatus
    author_display_name: str = Field(min_length=1)
    occurred_at: UtcTimestamp


class TestCaseReviewHistory(DomainModel):
    """Status history for a revision, kept separate from its immutable content."""

    revision: TestCaseRevision
    events: tuple[TestCaseReviewEvent, ...] = ()

    @model_validator(mode="after")
    def validate_status_transitions(self) -> TestCaseReviewHistory:
        if not self.events:
            return self
        if self.events[0].status is not TestCasePreparationStatus.DRAFT:
            raise ValueError("Test-case review history must begin with DRAFT")
        allowed_transitions = {
            TestCasePreparationStatus.DRAFT: TestCasePreparationStatus.NEEDS_REVIEW,
            TestCasePreparationStatus.NEEDS_REVIEW: TestCasePreparationStatus.READY,
        }
        if any(event.revision_id != self.revision.id for event in self.events):
            raise ValueError("Review events must reference the containing revision")
        for earlier, later in zip(self.events, self.events[1:], strict=False):
            if earlier.occurred_at > later.occurred_at:
                raise ValueError("Review events must be ordered by occurrence time")
            if allowed_transitions.get(earlier.status) is not later.status:
                raise ValueError("Test-case preparation status transition is not allowed")
        if self.events[-1].status is TestCasePreparationStatus.READY and any(
            step.readiness is not StepReadiness.READY for step in self.revision.steps
        ):
            raise ValueError("A test case cannot be READY while any step needs review")
        return self

    @property
    def status(self) -> TestCasePreparationStatus | None:
        return self.events[-1].status if self.events else None
