"""Application service for source-bound manual step review."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime, timedelta

from application.ports.manual_review import (
    ManualReviewRevisionError,
    ManualReviewStepMismatchError,
    ManualReviewStore,
    TestCaseReviewStore,
)
from manual_model.contracts import TestCasePreparationStatus
from manual_model.ports import (
    ManualExecutionAdapter,
    ManualStepHandoff,
    OperatorObservation,
)

MANUAL_APPROVAL_TTL = timedelta(minutes=5)


class ManualReviewRejectedError(RuntimeError):
    """A handoff could not be verified against this workspace's stored revision."""


class ManualReviewService:
    """Present only approved manual steps and persist only explicit observations."""

    def __init__(
        self,
        case_repository: TestCaseReviewStore,
        review_repository: ManualReviewStore,
        adapter: ManualExecutionAdapter,
        *,
        now_utc: Callable[[], datetime] | None = None,
    ) -> None:
        self._case_repository = case_repository
        self._review_repository = review_repository
        self._adapter = adapter
        self._now_utc = now_utc or (lambda: datetime.now(UTC))

    def present(self, handoff: ManualStepHandoff) -> ManualStepHandoff:
        """Persist and present a READY MANUAL_ONLY step after exact snapshot approval."""
        validated_handoff = ManualStepHandoff.model_validate(handoff.model_dump(mode="python"))
        now = self._now_utc()
        if now.tzinfo is None or now.utcoffset() != UTC.utcoffset(now):
            raise ManualReviewRejectedError("Manual approval clock must return a UTC timestamp")
        approved_at = validated_handoff.approval.approved_at
        if approved_at > now:
            raise ManualReviewRejectedError("Manual handoff approval is future-dated")
        if now > approved_at + MANUAL_APPROVAL_TTL:
            raise ManualReviewRejectedError("Manual handoff approval has expired")

        try:
            history = self._case_repository.get_history(validated_handoff.test_case_revision_id)
            revision = history.revision
            case = self._case_repository.get_case(revision.test_case_id)
        except KeyError as exc:
            raise ManualReviewRejectedError(
                "Manual handoff references an unknown test-case revision or case"
            ) from exc

        if history.status is not TestCasePreparationStatus.READY:
            raise ManualReviewRejectedError(
                "Manual handoff requires READY test-case preparation history"
            )
        if case.current_revision_id != revision.id:
            raise ManualReviewRejectedError(
                "Manual handoff references a superseded test-case revision"
            )

        try:
            persisted_handoff = self._review_repository.save_handoff(
                validated_handoff,
                revision,
            )
        except (ManualReviewStepMismatchError, ManualReviewRevisionError) as exc:
            raise ManualReviewRejectedError(str(exc)) from exc

        self._adapter.present(persisted_handoff)
        return persisted_handoff

    def record_observation(self, observation: OperatorObservation) -> OperatorObservation:
        """Persist and forward one explicit, UTC-timestamped operator observation."""
        validated_observation = OperatorObservation.model_validate(
            observation.model_dump(mode="python")
        )
        persisted_observation = self._review_repository.save_observation(validated_observation)
        self._adapter.record_observation(persisted_observation)
        return persisted_observation
