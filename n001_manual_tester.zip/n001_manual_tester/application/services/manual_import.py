"""Application use case for importing or rechecking one DOCX manual."""

from __future__ import annotations

from pathlib import Path
from uuid import UUID

from application.ports.manual_import import (
    ImportedManualResult,
    ManualImportRecord,
    ManualImportStore,
)
from manual_model.contracts import ManualImport, ManualImportStatus, ManualIndex, ManualItem


class ManualImportService:
    """Keep UI orchestration independent from the workspace implementation."""

    def __init__(self, store: ManualImportStore) -> None:
        self._store = store

    def import_docx(
        self,
        source_path: Path,
        *,
        recheck_of_import_id: str | None = None,
    ) -> ImportedManualResult:
        record = self._store.import_docx(source_path, recheck_of_import_id=recheck_of_import_id)
        return _to_result(record)

    def get_latest_import(self) -> ImportedManualResult | None:
        record = self._store.get_latest_import()
        return _to_result(record) if record is not None else None


def _to_result(record: ManualImportRecord) -> ImportedManualResult:
    manual_import = ManualImport(
        id=UUID(record.id),
        source_revision_id=_uuid_or_none(record.source_revision_id),
        created_at=record.created_at,
        status=ManualImportStatus(record.status),
        recheck_of_import_id=_uuid_or_none(record.recheck_of_import_id),
        manual_index_id=_uuid_or_none(record.manual_index_id),
        error_code=record.error_code,
        error_message=record.error_message,
    )
    manual_index = None
    if record.manual_index_id is not None:
        manual_index = ManualIndex(
            id=UUID(record.manual_index_id),
            manual_import_id=manual_import.id,
            schema_version=1,
            items=tuple(
                ManualItem(
                    id=UUID(item.id),
                    parent_item_id=_uuid_or_none(item.parent_item_id),
                    position=item.position,
                    heading=item.heading,
                    heading_level=item.heading_level,
                    content_path=item.content_path,
                    content_sha256=item.content_sha256,
                    quality_flags=item.quality_flags,
                )
                for item in record.items
            ),
        )
    return ImportedManualResult(
        manual_import=manual_import,
        manual_index=manual_index,
        source_name=record.source_name,
        source_sha256=record.source_sha256,
        source_path=record.source_path,
    )


def _uuid_or_none(value: str | None) -> UUID | None:
    return UUID(value) if value is not None else None
