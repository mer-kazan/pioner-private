"""Application service for review of normalized manual items."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from application.ports.manual_item_review import (
    ManualItemReviewPersistenceError,
    ManualItemReviewStore,
)
from manual_model.contracts import ItemReviewCycle, ItemReviewEvent, ReviewStatus


class ManualItemReviewRejectedError(RuntimeError):
    """The requested item-review transition is not valid for stored history."""


class ManualItemReviewService:
    """Start and confirm append-only review cycles pinned to an item's content hash."""

    def __init__(self, store: ManualItemReviewStore) -> None:
        self._store = store

    def start_review(
        self,
        item_id: UUID,
        *,
        author_display_name: str,
        occurred_at: datetime,
    ) -> ItemReviewCycle:
        """Open a new cycle using the exact normalized content currently stored."""
        item = self._store.get_item(item_id)
        sequence = 1
        if item.active_review_cycle_id is not None:
            active_cycle = self._store.get_cycle(item.active_review_cycle_id)
            if active_cycle.status is ReviewStatus.IN_REVIEW:
                raise ManualItemReviewRejectedError(
                    "The manual item already has an active review cycle"
                )
            sequence = active_cycle.sequence + 1

        cycle = ItemReviewCycle(manual_item_id=item.id, sequence=sequence)
        opened = ItemReviewCycle(
            id=cycle.id,
            manual_item_id=cycle.manual_item_id,
            sequence=cycle.sequence,
            events=(
                ItemReviewEvent(
                    cycle_id=cycle.id,
                    status=ReviewStatus.IN_REVIEW,
                    content_sha256=item.content_sha256,
                    author_display_name=author_display_name,
                    occurred_at=occurred_at,
                ),
            ),
        )
        return self._save(opened)

    def confirm_review(
        self,
        cycle_id: UUID,
        *,
        author_display_name: str,
        occurred_at: datetime,
    ) -> ItemReviewCycle:
        """Confirm the content hash already pinned when this cycle was opened."""
        cycle = self._store.get_cycle(cycle_id)
        if cycle.status is not ReviewStatus.IN_REVIEW:
            raise ManualItemReviewRejectedError("Only an active review cycle can be confirmed")
        opened_event = cycle.events[0]
        confirmed = ItemReviewCycle(
            id=cycle.id,
            manual_item_id=cycle.manual_item_id,
            sequence=cycle.sequence,
            events=(
                *cycle.events,
                ItemReviewEvent(
                    cycle_id=cycle.id,
                    status=ReviewStatus.CONFIRMED,
                    content_sha256=opened_event.content_sha256,
                    author_display_name=author_display_name,
                    occurred_at=occurred_at,
                ),
            ),
        )
        return self._save(confirmed)

    def _save(self, cycle: ItemReviewCycle) -> ItemReviewCycle:
        try:
            return self._store.save_cycle(cycle)
        except ManualItemReviewPersistenceError as exc:
            raise ManualItemReviewRejectedError(str(exc)) from exc
