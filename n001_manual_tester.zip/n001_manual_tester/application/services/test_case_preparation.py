"""Application service for append-only test-case preparation states."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID

from application.ports.test_case_preparation import (
    TestCasePreparationPersistenceError,
    TestCasePreparationStore,
)
from manual_model.contracts import (
    TestCasePreparationStatus,
    TestCaseReviewEvent,
    TestCaseReviewHistory,
    TestCaseRevision,
)


class TestCasePreparationRejectedError(RuntimeError):
    """The requested preparation state cannot follow its stored history."""


class TestCasePreparationService:
    """Create and advance immutable test-case preparation histories."""

    def __init__(self, store: TestCasePreparationStore) -> None:
        self._store = store

    def create_draft(
        self,
        revision: TestCaseRevision,
        *,
        author_display_name: str,
        occurred_at: datetime,
    ) -> TestCaseReviewHistory:
        """Persist a newly prepared immutable revision with its initial DRAFT event."""
        history = TestCaseReviewHistory(
            revision=revision,
            events=(
                TestCaseReviewEvent(
                    revision_id=revision.id,
                    status=TestCasePreparationStatus.DRAFT,
                    author_display_name=author_display_name,
                    occurred_at=occurred_at,
                ),
            ),
        )
        return self._save(history)

    def request_review(
        self,
        revision_id: UUID,
        *,
        author_display_name: str,
        occurred_at: datetime,
    ) -> TestCaseReviewHistory:
        """Move a DRAFT history to NEEDS_REVIEW."""
        return self._append(
            revision_id,
            TestCasePreparationStatus.DRAFT,
            TestCasePreparationStatus.NEEDS_REVIEW,
            author_display_name,
            occurred_at,
        )

    def mark_ready(
        self,
        revision_id: UUID,
        *,
        author_display_name: str,
        occurred_at: datetime,
    ) -> TestCaseReviewHistory:
        """Move a reviewed history to READY only when the domain contract permits it."""
        return self._append(
            revision_id,
            TestCasePreparationStatus.NEEDS_REVIEW,
            TestCasePreparationStatus.READY,
            author_display_name,
            occurred_at,
        )

    def _append(
        self,
        revision_id: UUID,
        expected_status: TestCasePreparationStatus,
        status: TestCasePreparationStatus,
        author_display_name: str,
        occurred_at: datetime,
    ) -> TestCaseReviewHistory:
        history = self._store.get_history(revision_id)
        if history.status is not expected_status:
            raise TestCasePreparationRejectedError(
                f"Expected preparation status {expected_status}, found {history.status}"
            )
        try:
            updated = TestCaseReviewHistory(
                revision=history.revision,
                events=(
                    *history.events,
                    TestCaseReviewEvent(
                        revision_id=history.revision.id,
                        status=status,
                        author_display_name=author_display_name,
                        occurred_at=occurred_at,
                    ),
                ),
            )
            return self._save(updated)
        except ValueError as exc:
            raise TestCasePreparationRejectedError(str(exc)) from exc

    def _save(self, history: TestCaseReviewHistory) -> TestCaseReviewHistory:
        try:
            return self._store.save_history(history)
        except TestCasePreparationPersistenceError as exc:
            raise TestCasePreparationRejectedError(str(exc)) from exc
