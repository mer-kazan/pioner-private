"""Ports used by application services to access external capabilities."""
