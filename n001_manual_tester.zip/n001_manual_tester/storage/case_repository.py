"""Persistence for immutable test-case revisions and preparation history."""

from __future__ import annotations

import json
import sqlite3
from contextlib import closing
from typing import Any, Literal
from uuid import UUID

from manual_model.contracts import (
    SourceEvidence,
    TestCase,
    TestCasePreparationStatus,
    TestCaseReviewEvent,
    TestCaseReviewHistory,
    TestCaseRevision,
    TestPrecondition,
    TestStep,
)
from storage.sqlite_workspace import WorkspaceStorage

_StepReferencePurpose = Literal["INSTRUCTION", "COMMAND", "EXPECTED_RESULT"]


class CaseRepositoryError(RuntimeError):
    """Base error for test-case repository operations."""


class ManualImportNotFoundError(CaseRepositoryError):
    """The referenced manual import is missing or unusable."""


class CaseOwnershipError(CaseRepositoryError):
    """A test case or revision does not belong to the requested import."""


class SourceReferenceError(CaseRepositoryError):
    """A source evidence ID is missing or outside the case's import and source revision."""


class AppendOnlyError(CaseRepositoryError):
    """A write would alter immutable revision or review history."""


class TestCaseRepository:
    """Atomically store immutable case revisions and append-only review events."""

    __test__ = False

    def __init__(self, storage: WorkspaceStorage) -> None:
        self.storage = storage

    def save_history(self, history: TestCaseReviewHistory) -> TestCaseReviewHistory:
        """Persist a revision and its complete event history in one transaction.

        Existing history must be supplied as an unchanged prefix; only new events
        may be appended. A new revision must be the next revision for its case.
        """
        history = TestCaseReviewHistory.model_validate(history.model_dump())
        revision = history.revision
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            self._validate_import(connection, revision)
            self._validate_source_refs(connection, revision)

            case_row = connection.execute(
                "SELECT manual_import_id, current_revision_id FROM test_cases WHERE id = ?",
                (str(revision.test_case_id),),
            ).fetchone()
            if case_row is None:
                if revision.revision_number != 1:
                    raise AppendOnlyError("The first test-case revision must be revision 1")
                connection.execute(
                    """
                    INSERT INTO test_cases (id, manual_import_id, current_revision_id)
                    VALUES (?, ?, NULL)
                    """,
                    (str(revision.test_case_id), str(revision.manual_import_id)),
                )
                is_new_revision = True
            else:
                if case_row["manual_import_id"] != str(revision.manual_import_id):
                    raise CaseOwnershipError(
                        f"Test case {revision.test_case_id} belongs to another manual import"
                    )
                stored_revision = connection.execute(
                    "SELECT id FROM test_case_revisions WHERE id = ?",
                    (str(revision.id),),
                ).fetchone()
                if stored_revision is not None:
                    if case_row["current_revision_id"] != str(revision.id):
                        raise AppendOnlyError(
                            "Preparation history cannot be appended to a superseded revision"
                        )
                    stored = self._load_revision(connection, revision.id)
                    if stored != revision:
                        raise AppendOnlyError("Stored test-case revisions are immutable")
                    is_new_revision = False
                else:
                    current_number = 0
                    if case_row["current_revision_id"] is not None:
                        current_row = connection.execute(
                            "SELECT revision_number FROM test_case_revisions WHERE id = ?",
                            (case_row["current_revision_id"],),
                        ).fetchone()
                        if current_row is None:
                            raise CaseRepositoryError(
                                "The current test-case revision does not exist"
                            )
                        current_number = int(current_row["revision_number"])
                    if revision.revision_number != current_number + 1:
                        raise AppendOnlyError(
                            "A new test-case revision must follow the current revision"
                        )
                    is_new_revision = True

            if is_new_revision:
                self._insert_revision(connection, revision)
                connection.execute(
                    "UPDATE test_cases SET current_revision_id = ? WHERE id = ?",
                    (str(revision.id), str(revision.test_case_id)),
                )

            existing_events = self._load_events(connection, revision.id)
            if (
                len(history.events) < len(existing_events)
                or history.events[: len(existing_events)] != existing_events
            ):
                raise AppendOnlyError(
                    "Preparation history must preserve every stored event in order"
                )
            for position, event in enumerate(
                history.events[len(existing_events) :], start=len(existing_events)
            ):
                self._insert_event(connection, event, position)

            persisted = self._load_history(connection, revision.id)
            connection.commit()
            return persisted
        except CaseRepositoryError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise CaseRepositoryError("Could not persist test-case history") from exc
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def get_history(self, revision_id: UUID) -> TestCaseReviewHistory:
        """Load and validate one revision together with all preparation events."""
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN")
            history = self._load_history(connection, revision_id)
            connection.commit()
            return history
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def get_case(self, test_case_id: UUID) -> TestCase:
        """Load the stable test-case identity and its current revision pointer."""
        with closing(self.storage.connect()) as connection:
            row = connection.execute(
                "SELECT id, current_revision_id FROM test_cases WHERE id = ?",
                (str(test_case_id),),
            ).fetchone()
            if row is None:
                raise KeyError(f"Test case not found: {test_case_id}")
            if row["current_revision_id"] is None:
                raise CaseRepositoryError("The test case has no current revision")
            return TestCase(
                id=UUID(row["id"]),
                current_revision_id=UUID(row["current_revision_id"]),
            )

    @staticmethod
    def _validate_import(connection: sqlite3.Connection, revision: TestCaseRevision) -> None:
        row = connection.execute(
            "SELECT source_revision_id, status FROM manual_imports WHERE id = ?",
            (str(revision.manual_import_id),),
        ).fetchone()
        if row is None or row["status"] != "IMPORTED" or row["source_revision_id"] is None:
            raise ManualImportNotFoundError(
                f"Imported manual import not found: {revision.manual_import_id}"
            )
        if row["source_revision_id"] != str(revision.source_revision_id):
            raise SourceReferenceError(
                f"Revision source {revision.source_revision_id} does not match manual import "
                f"{revision.manual_import_id} source {row['source_revision_id']}"
            )

    @staticmethod
    def _revision_source_ids(revision: TestCaseRevision) -> tuple[UUID, ...]:
        ids: list[UUID] = [source_ref.id for source_ref in revision.source_refs]
        for precondition in revision.preconditions:
            ids.extend(precondition.source_ref_ids)
        for step in revision.steps:
            ids.extend(step.source_ref_ids)
            if step.command is not None:
                ids.extend(step.command.source_ref_ids)
            ids.extend(step.expected_result.source_ref_ids)
        return tuple(dict.fromkeys(ids))

    @classmethod
    def _validate_source_refs(
        cls, connection: sqlite3.Connection, revision: TestCaseRevision
    ) -> None:
        for source_ref_id in cls._revision_source_ids(revision):
            row = connection.execute(
                "SELECT source_revision_id FROM source_refs WHERE id = ?",
                (str(source_ref_id),),
            ).fetchone()
            if row is None:
                raise SourceReferenceError(
                    f"Source evidence {source_ref_id} does not exist in source_refs"
                )
            if row["source_revision_id"] != str(revision.source_revision_id):
                raise SourceReferenceError(
                    f"Source evidence {source_ref_id} belongs to source revision "
                    f"{row['source_revision_id']}, expected {revision.source_revision_id}"
                )
            linked_to_import = connection.execute(
                """
                SELECT 1
                FROM item_content_source_refs AS item_refs
                JOIN manual_items AS items ON items.id = item_refs.manual_item_id
                JOIN manual_indexes AS indexes ON indexes.id = items.manual_index_id
                WHERE item_refs.source_ref_id = ?
                  AND indexes.manual_import_id = ?
                LIMIT 1
                """,
                (str(source_ref_id), str(revision.manual_import_id)),
            ).fetchone()
            if linked_to_import is None:
                raise SourceReferenceError(
                    f"Source evidence {source_ref_id} is not linked to manual import "
                    f"{revision.manual_import_id}"
                )
        for evidence in revision.source_refs:
            stored_evidence = cls._load_source_evidence(
                connection, str(evidence.id), revision.source_revision_id
            )
            if stored_evidence != evidence:
                raise SourceReferenceError(
                    f"Source evidence {evidence.id} does not match its persisted source reference"
                )

    @staticmethod
    def _insert_revision(connection: sqlite3.Connection, revision: TestCaseRevision) -> None:
        connection.execute(
            """
            INSERT INTO test_case_revisions (
                id, test_case_id, revision_number, manual_import_id, source_revision_id,
                profile_json, title
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                str(revision.id),
                str(revision.test_case_id),
                revision.revision_number,
                str(revision.manual_import_id),
                str(revision.source_revision_id),
                revision.profile.model_dump_json(),
                revision.title,
            ),
        )
        for position, evidence in enumerate(revision.source_refs):
            connection.execute(
                """
                INSERT INTO test_revision_source_refs (
                    revision_id, source_revision_id, source_ref_id, position
                ) VALUES (?, ?, ?, ?)
                """,
                (
                    str(revision.id),
                    str(revision.source_revision_id),
                    str(evidence.id),
                    position,
                ),
            )
        for position, precondition in enumerate(revision.preconditions):
            connection.execute(
                """
                INSERT INTO test_preconditions (revision_id, position, text)
                VALUES (?, ?, ?)
                """,
                (str(revision.id), position, precondition.text),
            )
            for ref_position, source_ref_id in enumerate(precondition.source_ref_ids):
                connection.execute(
                    """
                    INSERT INTO test_precondition_source_refs (
                        revision_id, precondition_position, source_revision_id,
                        source_ref_id, position
                    ) VALUES (?, ?, ?, ?, ?)
                    """,
                    (
                        str(revision.id),
                        position,
                        str(revision.source_revision_id),
                        str(source_ref_id),
                        ref_position,
                    ),
                )
        for step in revision.steps:
            connection.execute(
                """
                INSERT INTO test_steps (revision_id, step_id, position, content_json)
                VALUES (?, ?, ?, ?)
                """,
                (
                    str(revision.id),
                    str(step.id),
                    step.position,
                    step.model_dump_json(),
                ),
            )
            refs: list[tuple[_StepReferencePurpose, tuple[UUID, ...]]] = [
                ("INSTRUCTION", step.source_ref_ids),
                (
                    "COMMAND",
                    step.command.source_ref_ids if step.command is not None else (),
                ),
                ("EXPECTED_RESULT", step.expected_result.source_ref_ids),
            ]
            for purpose, source_ref_ids in refs:
                for position, source_ref_id in enumerate(source_ref_ids):
                    connection.execute(
                        """
                        INSERT INTO test_step_source_refs (
                            revision_id, step_id, purpose, position, source_revision_id,
                            source_ref_id
                        ) VALUES (?, ?, ?, ?, ?, ?)
                        """,
                        (
                            str(revision.id),
                            str(step.id),
                            purpose,
                            position,
                            str(revision.source_revision_id),
                            str(source_ref_id),
                        ),
                    )

    @staticmethod
    def _insert_event(
        connection: sqlite3.Connection, event: TestCaseReviewEvent, position: int
    ) -> None:
        connection.execute(
            """
            INSERT INTO test_case_review_events (
                id, revision_id, position, status, author_display_name, occurred_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                str(event.id),
                str(event.revision_id),
                position,
                event.status.value,
                event.author_display_name,
                event.occurred_at.isoformat(),
            ),
        )

    @staticmethod
    def _load_events(
        connection: sqlite3.Connection, revision_id: UUID
    ) -> tuple[TestCaseReviewEvent, ...]:
        rows = connection.execute(
            """
            SELECT id, revision_id, position, status, author_display_name, occurred_at
            FROM test_case_review_events
            WHERE revision_id = ?
            ORDER BY position
            """,
            (str(revision_id),),
        ).fetchall()
        events: list[TestCaseReviewEvent] = []
        for position, row in enumerate(rows):
            if row["position"] != position:
                raise CaseRepositoryError("Stored preparation event positions are not contiguous")
            events.append(
                TestCaseReviewEvent(
                    id=UUID(row["id"]),
                    revision_id=UUID(row["revision_id"]),
                    status=TestCasePreparationStatus(row["status"]),
                    author_display_name=row["author_display_name"],
                    occurred_at=row["occurred_at"],
                )
            )
        return tuple(events)

    @classmethod
    def _load_history(
        cls, connection: sqlite3.Connection, revision_id: UUID
    ) -> TestCaseReviewHistory:
        revision = cls._load_revision(connection, revision_id)
        events = cls._load_events(connection, revision_id)
        return TestCaseReviewHistory(revision=revision, events=events)

    @classmethod
    def _load_revision(cls, connection: sqlite3.Connection, revision_id: UUID) -> TestCaseRevision:
        row = connection.execute(
            """
            SELECT id, test_case_id, revision_number, manual_import_id, source_revision_id,
                   profile_json, title
            FROM test_case_revisions
            WHERE id = ?
            """,
            (str(revision_id),),
        ).fetchone()
        if row is None:
            raise KeyError(f"Test-case revision not found: {revision_id}")
        case_row = connection.execute(
            "SELECT manual_import_id FROM test_cases WHERE id = ?",
            (row["test_case_id"],),
        ).fetchone()
        if case_row is None or case_row["manual_import_id"] != row["manual_import_id"]:
            raise CaseOwnershipError(
                f"Test-case revision {revision_id} is not stored under its manual import"
            )
        source_revision_id = UUID(row["source_revision_id"])
        revision_refs = connection.execute(
            """
            SELECT source_ref_id, position
            FROM test_revision_source_refs
            WHERE revision_id = ?
            ORDER BY position
            """,
            (str(revision_id),),
        ).fetchall()
        source_refs: list[SourceEvidence] = []
        for position, ref_row in enumerate(revision_refs):
            if ref_row["position"] != position:
                raise CaseRepositoryError("Stored revision source-reference positions are invalid")
            source_refs.append(
                cls._load_source_evidence(connection, ref_row["source_ref_id"], source_revision_id)
            )

        preconditions: list[TestPrecondition] = []
        precondition_rows = connection.execute(
            """
            SELECT position, text
            FROM test_preconditions
            WHERE revision_id = ?
            ORDER BY position
            """,
            (str(revision_id),),
        ).fetchall()
        for position, precondition_row in enumerate(precondition_rows):
            if precondition_row["position"] != position:
                raise CaseRepositoryError("Stored precondition positions are not contiguous")
            ref_rows = connection.execute(
                """
                SELECT source_ref_id, position
                FROM test_precondition_source_refs
                WHERE revision_id = ? AND precondition_position = ?
                ORDER BY position
                """,
                (str(revision_id), position),
            ).fetchall()
            ref_ids = cls._ordered_ids(ref_rows, "precondition source-reference")
            preconditions.append(
                TestPrecondition(text=precondition_row["text"], source_ref_ids=ref_ids)
            )

        steps: list[TestStep] = []
        step_rows = connection.execute(
            """
            SELECT step_id, position, content_json
            FROM test_steps
            WHERE revision_id = ?
            ORDER BY position
            """,
            (str(revision_id),),
        ).fetchall()
        for position, step_row in enumerate(step_rows):
            if step_row["position"] != position:
                raise CaseRepositoryError("Stored test-step positions are not contiguous")
            step = TestStep.model_validate_json(step_row["content_json"])
            if str(step.id) != step_row["step_id"] or step.position != position:
                raise CaseRepositoryError("Stored test-step content does not match its index")
            cls._validate_step_provenance(connection, revision_id, step)
            steps.append(step)

        revision = TestCaseRevision(
            id=UUID(row["id"]),
            test_case_id=UUID(row["test_case_id"]),
            revision_number=row["revision_number"],
            manual_import_id=UUID(row["manual_import_id"]),
            source_revision_id=source_revision_id,
            profile=json.loads(row["profile_json"]),
            title=row["title"],
            preconditions=tuple(preconditions),
            steps=tuple(steps),
            source_refs=tuple(source_refs),
        )
        cls._validate_import(connection, revision)
        cls._validate_source_refs(connection, revision)
        return revision

    @staticmethod
    def _ordered_ids(rows: list[sqlite3.Row], description: str) -> tuple[UUID, ...]:
        ids: list[UUID] = []
        for position, row in enumerate(rows):
            if row["position"] != position:
                raise CaseRepositoryError(f"Stored {description} positions are invalid")
            ids.append(UUID(row["source_ref_id"]))
        return tuple(ids)

    @classmethod
    def _validate_step_provenance(
        cls, connection: sqlite3.Connection, revision_id: UUID, step: TestStep
    ) -> None:
        actual_rows = connection.execute(
            """
            SELECT purpose, position, source_ref_id
            FROM test_step_source_refs
            WHERE revision_id = ? AND step_id = ?
            ORDER BY purpose, position
            """,
            (str(revision_id), str(step.id)),
        ).fetchall()
        actual: dict[str, list[UUID]] = {}
        for row in actual_rows:
            refs = actual.setdefault(row["purpose"], [])
            if row["position"] != len(refs):
                raise CaseRepositoryError("Stored test-step provenance positions are invalid")
            refs.append(UUID(row["source_ref_id"]))
        expected: dict[str, tuple[UUID, ...]] = {
            "INSTRUCTION": step.source_ref_ids,
            "COMMAND": step.command.source_ref_ids if step.command is not None else (),
            "EXPECTED_RESULT": step.expected_result.source_ref_ids,
        }
        if actual != {purpose: list(refs) for purpose, refs in expected.items() if refs}:
            raise CaseRepositoryError(
                f"Stored provenance for test step {step.id} does not match its content"
            )
        source_ref_ids = (source_ref_id for refs in expected.values() for source_ref_id in refs)
        for source_ref_id in source_ref_ids:
            source_row = connection.execute(
                "SELECT source_revision_id FROM source_refs WHERE id = ?",
                (str(source_ref_id),),
            ).fetchone()
            if source_row is None:
                raise SourceReferenceError(
                    f"Source evidence {source_ref_id} does not exist in source_refs"
                )

    @staticmethod
    def _load_source_evidence(
        connection: sqlite3.Connection, source_ref_id: str, source_revision_id: UUID
    ) -> SourceEvidence:
        row: Any = connection.execute(
            """
            SELECT id, source_revision_id, part_uri, xpath, block_index, paragraph_index,
                   table_index, row_index, cell_index, quoted_text, quoted_text_sha256
            FROM source_refs
            WHERE id = ?
            """,
            (source_ref_id,),
        ).fetchone()
        if row is None:
            raise SourceReferenceError(
                f"Source evidence {source_ref_id} does not exist in source_refs"
            )
        if row["source_revision_id"] != str(source_revision_id):
            raise SourceReferenceError(
                f"Source evidence {source_ref_id} belongs to source revision "
                f"{row['source_revision_id']}, expected {source_revision_id}"
            )
        return SourceEvidence(
            id=UUID(row["id"]),
            source_revision_id=UUID(row["source_revision_id"]),
            part_uri=row["part_uri"],
            xpath=row["xpath"],
            block_index=row["block_index"],
            paragraph_index=row["paragraph_index"],
            table_index=row["table_index"],
            row_index=row["row_index"],
            cell_index=row["cell_index"],
            quoted_text=row["quoted_text"],
            quoted_text_sha256=row["quoted_text_sha256"],
        )
