﻿"""Desktop application package for Manual Test Platform."""
