﻿"""SQLite persistence for append-only item-review cycles."""

from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime
from uuid import UUID

from manual_test_platform.application.ports.manual_item_review import (
    ManualItemReviewPersistenceError,
    ManualItemReviewStore,
)
from manual_test_platform.manual_model.contracts import (
    ItemReviewCycle,
    ItemReviewEvent,
    ManualItem,
    ReviewStatus,
)
from manual_test_platform.storage.sqlite_workspace import WorkspaceStorage


class SqliteManualItemReviewRepository:
    """Persist item-review cycles and events in the workspace SQLite database."""

    def __init__(self, storage: WorkspaceStorage) -> None:
        self.storage = storage

    def get_item(self, item_id: UUID) -> ManualItem:
        """Load a manual item by its id; raise ``KeyError`` when missing."""
        connection = self.storage.connect()
        try:
            row = connection.execute(
                """
                SELECT id, parent_item_id, position, heading, heading_level,
                       content_path, content_sha256, quality_flags_json,
                       review_cycle_id
                FROM manual_items
                WHERE id = ?
                """,
                (str(item_id),),
            ).fetchone()
        except sqlite3.Error as exc:
            raise ManualItemReviewPersistenceError(
                f"Could not load manual item {item_id}"
            ) from exc
        finally:
            connection.close()
        if row is None:
            raise KeyError(f"Manual item {item_id} not found")
        return _row_to_manual_item(row)

    def get_cycle(self, cycle_id: UUID) -> ItemReviewCycle:
        """Load a review cycle and its append-only events; raise ``KeyError`` when missing."""
        connection = self.storage.connect()
        try:
            cycle_row = connection.execute(
                """
                SELECT id, manual_item_id, sequence
                FROM item_review_cycles
                WHERE id = ?
                """,
                (str(cycle_id),),
            ).fetchone()
            if cycle_row is None:
                raise KeyError(f"Review cycle {cycle_id} not found")
            event_rows = connection.execute(
                """
                SELECT id, cycle_id, position, status, content_sha256,
                       author_display_name, occurred_at
                FROM item_review_events
                WHERE cycle_id = ?
                ORDER BY position
                """,
                (str(cycle_id),),
            ).fetchall()
        except sqlite3.Error as exc:
            raise ManualItemReviewPersistenceError(
                f"Could not load review cycle {cycle_id}"
            ) from exc
        finally:
            connection.close()
        events = tuple(_row_to_event(row) for row in event_rows)
        return ItemReviewCycle(
            id=UUID(cycle_row["id"]),
            manual_item_id=UUID(cycle_row["manual_item_id"]),
            sequence=cycle_row["sequence"],
            events=events,
        )

    def save_cycle(self, cycle: ItemReviewCycle) -> ItemReviewCycle:
        """Atomically append new events and link the cycle to its item.

        Existing events must remain an unchanged prefix of the new history;
        only events that are not yet stored may be inserted.
        """
        connection = self.storage.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            stored_row = connection.execute(
                "SELECT id, sequence FROM item_review_cycles WHERE id = ?",
                (str(cycle.id),),
            ).fetchone()
            if stored_row is not None:
                stored_events = connection.execute(
                    """
                    SELECT position, status, content_sha256, author_display_name, occurred_at
                    FROM item_review_events
                    WHERE cycle_id = ?
                    ORDER BY position
                    """,
                    (str(cycle.id),),
                ).fetchall()
                stored_prefix = tuple(
                    _row_to_event_from_stored(row) for row in stored_events
                )
                new_prefix = cycle.events[: len(stored_prefix)]
                if new_prefix != stored_prefix:
                    connection.rollback()
                    raise ManualItemReviewPersistenceError(
                        "Review history must keep its stored prefix"
                    )
            else:
                connection.execute(
                    """
                    INSERT INTO item_review_cycles (id, manual_item_id, sequence)
                    VALUES (?, ?, ?)
                    """,
                    (
                        str(cycle.id),
                        str(cycle.manual_item_id),
                        cycle.sequence,
                    ),
                )

            existing_count = 0
            if stored_row is not None:
                existing_count = connection.execute(
                    "SELECT COUNT(*) FROM item_review_events WHERE cycle_id = ?",
                    (str(cycle.id),),
                ).fetchone()[0]

            new_events = cycle.events[existing_count:]
            for position, event in enumerate(new_events, start=existing_count):
                connection.execute(
                    """
                    INSERT INTO item_review_events
                        (id, cycle_id, position, status, content_sha256,
                         author_display_name, occurred_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        str(event.id),
                        str(cycle.id),
                        position,
                        event.status.value,
                        event.content_sha256,
                        event.author_display_name,
                        event.occurred_at.isoformat(),
                    ),
                )

            connection.execute(
                """
                UPDATE manual_items
                SET review_cycle_id = ?
                WHERE id = ?
                """,
                (str(cycle.id), str(cycle.manual_item_id)),
            )
            connection.commit()
        except ManualItemReviewPersistenceError:
            connection.rollback()
            raise
        except sqlite3.Error as exc:
            connection.rollback()
            raise ManualItemReviewPersistenceError(
                f"Could not save review cycle {cycle.id}"
            ) from exc
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()
        return cycle


def _row_to_manual_item(row: sqlite3.Row) -> ManualItem:
    return ManualItem(
        id=UUID(row["id"]),
        parent_item_id=UUID(row["parent_item_id"]) if row["parent_item_id"] else None,
        position=row["position"],
        heading=row["heading"],
        heading_level=row["heading_level"],
        content_path=row["content_path"],
        content_sha256=row["content_sha256"],
        quality_flags=tuple(json.loads(row["quality_flags_json"])),
        active_review_cycle_id=(
            UUID(row["review_cycle_id"]) if row["review_cycle_id"] else None
        ),
    )


def _row_to_event(row: sqlite3.Row) -> ItemReviewEvent:
    return ItemReviewEvent(
        id=UUID(row["id"]),
        cycle_id=UUID(row["cycle_id"]),
        status=ReviewStatus(row["status"]),
        content_sha256=row["content_sha256"],
        author_display_name=row["author_display_name"],
        occurred_at=datetime.fromisoformat(row["occurred_at"]),
    )


def _row_to_event_from_stored(row: sqlite3.Row) -> ItemReviewEvent:
    return ItemReviewEvent(
        id=UUID(row["id"]),
        cycle_id=UUID(row["cycle_id"]),
        status=ReviewStatus(row["status"]),
        content_sha256=row["content_sha256"],
        author_display_name=row["author_display_name"],
        occurred_at=datetime.fromisoformat(row["occurred_at"]),
    )
