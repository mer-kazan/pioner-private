﻿"""Document-import boundary used by the import application service."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Literal, Protocol

from manual_test_platform.manual_model.contracts import DomainModel, ManualImport, ManualIndex, SourceEvidence


@dataclass(frozen=True)
class ManualItemSourceEvidence:
    """A source citation linked to a JSON pointer in persisted item content."""

    content_pointer: str
    evidence: SourceEvidence


@dataclass(frozen=True)
class ManualItemRecord:
    """Persisted manual item with metadata and a pointer to its stored content file."""

    id: str
    parent_item_id: str | None
    position: int
    heading: str | None
    heading_level: int | None
    content_path: str
    content_sha256: str
    quality_flags: tuple[str, ...]
    source_refs: tuple[ManualItemSourceEvidence, ...] = ()


@dataclass(frozen=True)
class ManualImportRecord:
    """A successful or failed DOCX import stored in a workspace."""

    id: str
    created_at: datetime
    status: Literal["IMPORTED", "FAILED"]
    source_revision_id: str | None
    manual_index_id: str | None
    recheck_of_import_id: str | None
    source_name: str | None
    source_sha256: str | None
    source_path: Path | None
    items: tuple[ManualItemRecord, ...]
    error_code: str | None
    error_message: str | None


class ImportedManualResult(DomainModel):
    """Typed import result exposed by the application layer."""

    manual_import: ManualImport
    manual_index: ManualIndex | None = None
    source_name: str | None = None
    source_sha256: str | None = None
    source_path: Path | None = None


class ManualImportStore(Protocol):
    """Persist a DOCX import and retrieve the latest successful import."""

    def import_docx(
        self,
        source_path: Path,
        *,
        recheck_of_import_id: str | None = None,
    ) -> ManualImportRecord: ...

    def get_latest_import(self) -> ManualImportRecord | None: ...


__all__ = [
    "ManualImportRecord",
    "ImportedManualResult",
    "ManualImportStore",
    "ManualItemRecord",
    "ManualItemSourceEvidence",
]
